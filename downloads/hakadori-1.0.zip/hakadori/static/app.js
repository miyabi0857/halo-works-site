window.currentChatTab = 'team';

window.switchChatTab = function(tab) {
    window.currentChatTab = tab;
    
    const tTeam = document.getElementById('tabTeamChat');
    const tBoss = document.getElementById('tabBossChat');
    
    if (tab === 'team') {
        tTeam.style.background = 'var(--accent-primary)';
        tTeam.style.color = 'white';
        tTeam.style.fontWeight = 'bold';
        tTeam.style.border = '2px solid var(--accent-primary)';
        tTeam.style.opacity = '1';
        
        tBoss.style.background = '#f1f5f9';
        tBoss.style.color = '#64748b';
        tBoss.style.fontWeight = 'bold';
        tBoss.style.border = '2px solid #e2e8f0';
        tBoss.style.opacity = '1';
    } else {
        tBoss.style.background = '#ef4444'; // distinctive red for SOS/Boss
        tBoss.style.color = 'white';
        tBoss.style.fontWeight = 'bold';
        tBoss.style.border = '2px solid #ef4444';
        tBoss.style.opacity = '1';
        
        tTeam.style.background = '#f1f5f9';
        tTeam.style.color = '#64748b';
        tTeam.style.fontWeight = 'bold';
        tTeam.style.border = '2px solid #e2e8f0';
        tTeam.style.opacity = '1';
    }
    
    if (currentOpenTaskId) {
        fetch(`${API_BASE}/tasks/${currentOpenTaskId}/comments`).then(res => res.json()).then(comments => {
            const list = document.getElementById('commentsList');
            list.innerHTML = '';
            comments.filter(c => (c.chat_type || 'team') === window.currentChatTab).forEach(appendCommentToModal);
        });
    }
};


function getDueDateColorClass(dueDate) {
    if (!dueDate) return '';
    const due = new Date(dueDate);
    due.setHours(0,0,0,0);
    const today = new Date();
    today.setHours(0,0,0,0);
    
    // Calculate working days diff
    let diffDays = 0;
    
    if (due < today) {
        return 'row-due-passed';
    } else {
        let tempDate = new Date(today);
        while (tempDate < due) {
            const yyyy = tempDate.getFullYear();
            const mm = String(tempDate.getMonth() + 1).padStart(2, '0');
            const dd = String(tempDate.getDate()).padStart(2, '0');
            const dateStr = `${yyyy}-${mm}-${dd}`;
            
            const isWeekend = tempDate.getDay() === 0 || tempDate.getDay() === 6;
            // holidays array holds strings like "YYYY-MM-DD"
            if (!holidays.includes(dateStr) && !isWeekend) {
                diffDays++;
            }
            tempDate.setDate(tempDate.getDate() + 1);
        }
    }
    
    if (diffDays === 0 && due.getTime() === today.getTime()) {
        return 'row-due-today';
    } else if (diffDays <= 5) { // 5 working days = 1 week
        return 'row-due-soon';
    }
    return '';
}
(function() {
    function logToScreen(msg, isError) {
        const logger = document.getElementById('debug-logger');
        if (!logger) return;
        const d = document.createElement('div');
        d.textContent = msg;
        if (isError) d.style.color = '#f00';
        logger.appendChild(d);
        logger.scrollTop = logger.scrollHeight;
    }
    const origLog = console.log;
    console.log = function(...args) {
        origLog.apply(console, args);
        logToScreen('LOG: ' + args.join(' '));
    };
    const origError = console.error;
    console.error = function(...args) {
        origError.apply(console, args);
        logToScreen('ERR: ' + args.join(' '), true);
    };
    window.addEventListener('error', function(e) {
        logToScreen('WINERR: ' + e.message + ' at ' + e.filename + ':' + e.lineno, true);
    });
    window.addEventListener('unhandledrejection', function(e) {
        logToScreen('PROMISE_ERR: ' + e.reason, true);
    });
})();



const API_BASE = '/api';

// State
let tasks = [];
let statuses = [];
let projects = [];
let businessCategories = [];
let users = [];
let holidays = [];
let currentUserId = localStorage.getItem('currentUserId'); // Retrieve from localStorage
let allNotifications = [];
let editingTaskId = null;
window.isEditingInline = false;


function getBadgesHtml(taskId) {
    let unreadComments = 0;
    let unreadEdits = 0;
    allNotifications.forEach(n => {
        if(!n.is_read && String(n.task_id) === String(taskId)) {
            if(n.message && n.message.includes('コメント')) unreadComments++;
            else if(n.message && (n.message.includes('編集') || n.message.includes('修正') || n.message.includes('追加'))) unreadEdits++;
        }
    });
    
    let html = '';
    if(unreadComments > 0) {
        html += `<div class="badge-red">${unreadComments}</div>`;
    }
    if (unreadEdits > 0) {
        html += `<div class="badge-blue"></div>`;
    }
    return `<span class="badge-container" data-task-id="${taskId}">${html}</span>`;
}

function updateBadgesUI() {
    document.querySelectorAll('.badge-container').forEach(el => {
        const taskId = parseInt(el.getAttribute('data-task-id'));
        let unreadComments = 0;
        let unreadEdits = 0;
        allNotifications.forEach(n => {
            if(String(n.task_id) === String(taskId) && n.is_read === 0) {
                if(n.message && n.message.includes('コメント')) {
                    unreadComments++;
                } else if(n.message && (n.message.includes('編集') || n.message.includes('追加') || n.message.includes('修正'))) {
                    unreadEdits++;
                }
            }
        });
        
        let html = '';
        if(unreadComments > 0) {
            html += `<div class="badge-red">${unreadComments}</div>`;
        }
        if (unreadEdits > 0) {
            html += `<div class="badge-blue"></div>`;
        }
        el.innerHTML = html;
    });
}

// DOM Elements
const viewToggles = document.querySelectorAll('.toggle-btn');
const viewSections = document.querySelectorAll('.view-section');
const listBody = document.getElementById('listBody');
const filterType = document.getElementById('filterType');
const filterAssignee = document.getElementById('filterAssignee');

// Navigation & UI Elements
const navItems = document.querySelectorAll('.nav-item');
const pageTitle = document.getElementById('pageTitle');
const headerActionBtn = document.getElementById('headerActionBtn');
const dashboardToggles = document.getElementById('dashboardToggles');
const viewContainers = {
    analytics: document.getElementById('nav-analytics'),
    dashboard: document.querySelector('.view-container:not([id^="nav-"])'),
    projects: document.getElementById('nav-projects'),
    completed_projects: document.getElementById('nav-completed_projects'),
    members: document.getElementById('nav-members'),
    settings: document.getElementById('nav-settings'),
    feedback_list: document.getElementById('nav-feedback_list')
};
let currentNav = 'dashboard';

// Generic Modal Elements
const userModal = document.getElementById('userModal');
const userModalTitle = document.getElementById('userModalTitle');
const userModalName = document.getElementById('userModalName');
const userModalSaveBtn = document.getElementById('userModalSaveBtn');
let userModalId = null;

const projectModal = document.getElementById('projectModal');
const projectModalTitle = document.getElementById('projectModalTitle');
const projectModalName = document.getElementById('projectModalName');
const projectModalDesc = document.getElementById('projectModalDesc');
const projectModalStart = document.getElementById('projectModalStart');
const projectModalDue = document.getElementById('projectModalDue');
const projectModalOwner = document.getElementById('projectModalOwner');
const projectModalStatus = document.getElementById('projectModalStatus');
const projectModalSaveBtn = document.getElementById('projectModalSaveBtn');
let projectModalId = null;

const taskCreateModal = document.getElementById('taskCreateModal');
const taskCreateTitle = document.getElementById('taskCreateTitle');
const taskCreateDesc = document.getElementById('taskCreateDesc');
const taskCreateProject = document.getElementById('taskCreateProject');
let taskCreateAssignee = document.getElementById('taskCreateAssignee');
if (taskCreateAssignee && taskCreateAssignee.tagName === 'SELECT') {
    const newDiv = document.createElement('div');
    newDiv.id = 'taskCreateAssignee';
    newDiv.className = 'input-field multi-select-container';
    newDiv.style = 'width: 100%; height: 80px; overflow-y: auto; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; padding: 8px; display: flex; flex-direction: column; gap: 4px;';
    taskCreateAssignee.parentNode.replaceChild(newDiv, taskCreateAssignee);
    taskCreateAssignee = newDiv;
}
const taskCreateType = document.getElementById('taskCreateType');
const taskCreateStatus = document.getElementById('taskCreateStatus');
const taskCreateStart = document.getElementById('taskCreateStart');
const taskCreateDue = document.getElementById('taskCreateDue');
const taskCreateImportance = document.getElementById('taskCreateImportance');
const taskCreateSaveBtn = document.getElementById('taskCreateSaveBtn');

// ---- Importance slider (drag-follow tooltip + range highlight) ----
window.setImportanceSlider = function(value) {
    if (!taskCreateImportance) return;
    const v = Math.max(1, Math.min(100, parseInt(value, 10) || 50));
    taskCreateImportance.value = v;
    window.updateImportanceTooltipPosition();
    window.updateImportanceBandHighlight(v);
};

window.updateImportanceTooltipPosition = function() {
    const slider = taskCreateImportance;
    const tooltip = document.getElementById('taskCreateImportanceTooltip');
    if (!slider || !tooltip) return;
    const min = parseInt(slider.min, 10), max = parseInt(slider.max, 10);
    const val = parseInt(slider.value, 10);
    const pct = (val - min) / (max - min);
    const trackWidth = slider.offsetWidth;
    const thumbSize = 22;
    const leftPx = thumbSize / 2 + pct * (trackWidth - thumbSize);
    tooltip.style.left = `${leftPx}px`;
    tooltip.textContent = val;
};

window.updateImportanceBandHighlight = function(value) {
    document.querySelectorAll('.importance-band').forEach(el => {
        const min = parseInt(el.dataset.min, 10), max = parseInt(el.dataset.max, 10);
        el.classList.toggle('active', value >= min && value <= max);
    });
};

if (taskCreateImportance) {
    const tooltip = document.getElementById('taskCreateImportanceTooltip');
    const showTooltip = () => { if (tooltip) tooltip.style.display = 'block'; };
    const hideTooltip = () => { if (tooltip) tooltip.style.display = 'none'; };
    taskCreateImportance.addEventListener('mousedown', showTooltip);
    taskCreateImportance.addEventListener('touchstart', showTooltip);
    taskCreateImportance.addEventListener('input', () => {
        window.updateImportanceTooltipPosition();
        window.updateImportanceBandHighlight(parseInt(taskCreateImportance.value, 10));
    });
    taskCreateImportance.addEventListener('mouseup', hideTooltip);
    taskCreateImportance.addEventListener('touchend', hideTooltip);
    taskCreateImportance.addEventListener('blur', hideTooltip);
}

// Modal Elements
const modal = document.getElementById('taskModal');
const closeModalBtn = document.getElementById('closeModal');
const modalStatus = document.getElementById('modalStatus');
const sendCommentBtn = document.getElementById('sendComment');
const newCommentInput = document.getElementById('newComment');
let currentOpenTaskId = null;

// Initialize
async function init() {
    try {
    await fetchData();
    populateFilters();
    populateLoginUsers();
    renderBusinessCategories();
    populateCategorySelects();
    setupEventListeners();
    checkLoginStatus();
    
    if (currentUserId) {
        // Tell backend so the notifier can start
        try {
            await fetch(`${API_BASE}/notifier/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ user_id: parseInt(currentUserId) })
            });
        } catch(e) {}
        
        renderAllViews();
        await fetchNotifications();
        
        // Start background auto-refresh
        setInterval(async () => {
            if (!currentUserId) return;
            // Prevent refresh if modal is open or dragging
            if (document.getElementById('taskModal').style.display === 'flex') return;
            if (document.querySelector('.is-dragging')) return;
            
            const oldTasksStr = JSON.stringify(tasks);
            await fetchData();
            const newTasksStr = JSON.stringify(tasks);
            if (oldTasksStr !== newTasksStr) {
                renderAllViews();
            }
        }, 30000);
        
        const urlParams = new URLSearchParams(window.location.search);
        const qTitle = urlParams.get('quickadd_title');
        const qDesc = urlParams.get('quickadd_desc');
        if (qTitle || qDesc) {
            window.openTaskCreateModal(null, qTitle || '', qDesc || '');
            window.history.replaceState({}, document.title, window.location.pathname);
        }
    }
    
    let lastTasksJson = '';
    let lastNotifsJson = '';
    
    setInterval(async () => {
        if (!currentUserId) return;
        try {
            // Poll Notifications
            const resN = await fetch(`${API_BASE}/notifications/${currentUserId}`);
            if (resN.ok) {
                const notifs = await resN.json();
                const notifsJson = JSON.stringify(notifs);
                if (notifsJson !== lastNotifsJson) {
                    lastNotifsJson = notifsJson;
                    await fetchNotifications(); // This updates the dropdown and bell
                    updateBadgesUI();
                }
            }
            
            // Poll Tasks
            const resT = await fetch(`${API_BASE}/tasks`);
            if (resT.ok) {
                const polledTasks = await resT.json();
                const tasksJson = JSON.stringify(polledTasks);
                if (tasksJson !== lastTasksJson) {
                    tasks = polledTasks;
                    lastTasksJson = tasksJson;
                    
                    // Only re-render list views if user is NOT editing
                    const isAnyModalOpen = document.querySelector('.modal.show') !== null;
                    if (!window.isEditingInline && !isAnyModalOpen && !editingTaskId) {
                        renderAllViews();
                    }
                    
                    // Update task detail modal if open
                    if (currentOpenTaskId) {
                        const t = tasks.find(x => x.id == currentOpenTaskId);
                        if (t) {
                            document.getElementById('modalTitle').textContent = t.title;
                            document.getElementById('modalAssignee').innerHTML = renderAssignees(t.assignees);
                            if(document.getElementById('modalStatus').value !== t.status) document.getElementById('modalStatus').value = t.status;
                            const typeBadge = document.getElementById('modalType');
                            typeBadge.textContent = t.task_type;
                            typeBadge.className = 'value badge ' + (t.task_type === '突発' ? 'type-sudden' : t.task_type === 'プロジェクト' ? 'type-long' : 'type-routine');
                            document.getElementById('modalDates').textContent = `${t.start_date || '-'} ~ ${t.due_date || '-'}`;
                            document.getElementById('modalDesc').textContent = t.description || '詳細はなし。';
                            document.getElementById('modalProject').textContent = t.project_name || 'No Project';
                        }
                    }
                }
            }
            
            // Poll Comments if modal is open
            if (currentOpenTaskId) {
                const resComments = await fetch(`${API_BASE}/tasks/${currentOpenTaskId}/comments`);
                const comments = await resComments.json();
                const list = document.getElementById('commentsList');
                if (list && list.children.length !== comments.length) {
                    list.innerHTML = '';
                    comments.filter(c => (c.chat_type || 'team') === window.currentChatTab).forEach(appendCommentToModal);
                }
            }
        } catch (err) {}
    }, 3000);

    } catch(e) {
        alert('Init error: ' + e.message + '\n' + e.stack);
        console.error(e);
    }
}



async function fetchData() {
    try {
        const [tasksRes, projectsRes, usersRes, statusesRes, holRes, bcRes] = await Promise.all([
            fetch(`${API_BASE}/tasks`),
            fetch(`${API_BASE}/projects`),
            fetch(`${API_BASE}/users`),
            fetch(`${API_BASE}/statuses`),
            fetch(`${API_BASE}/holidays`),
            fetch(`${API_BASE}/business_categories`)
        ]);
        tasks = await tasksRes.json();
        projects = await projectsRes.json();
        users = await usersRes.json();
        statuses = await statusesRes.json();
        const holData = await holRes.json();
        holidays = holData.map(h => h.holiday_date);
        businessCategories = await bcRes.json();
    } catch (err) {
        console.error("Failed to fetch data", err);
    }
}

function populateProjectFilter() {
    const filterProject = document.getElementById('filterProject');
    if (!filterProject) return;
    const currentVal = filterProject.value;
    filterProject.innerHTML = '<option value="all">すべてのプロジェクト</option>';
    const projects = [...new Set(tasks.map(t => t.project_name).filter(Boolean))].sort();
    projects.forEach(p => {
        const opt = document.createElement('option');
        opt.value = p;
        opt.textContent = p;
        filterProject.appendChild(opt);
    });
    if (projects.includes(currentVal)) {
        filterProject.value = currentVal;
    }
}

function populateFilters() {
    populateProjectFilter();
    if (filterStatus) {
        filterStatus.innerHTML = '<option value="all">すべてのステータス</option>';
        statuses.forEach(s => {
            const opt = document.createElement('option');
            opt.value = s.name;
            opt.textContent = s.name;
            filterStatus.appendChild(opt);
        });
    }

    if (filterAssignee) {
        filterAssignee.innerHTML = '<option value="all">担当者で絞り込み</option>';
        users.forEach(u => {
            const opt = document.createElement('option');
            opt.value = u.id;
            opt.textContent = u.name;
            filterAssignee.appendChild(opt);
        });
    }
}

function setupEventListeners() {
    try {
    // View Toggles
    viewToggles.forEach(btn => {
        if (btn) btn.addEventListener('click', () => {
            viewToggles.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const view = btn.dataset.view;
            viewSections.forEach(sec => sec.style.display = 'none');
            document.getElementById(`view-${view}`).style.display = 'block';
            const kanbanControls = document.getElementById('kanbanControls');
            if (kanbanControls) kanbanControls.style.display = (view === 'kanban') ? 'flex' : 'none';
            const listControls = document.getElementById('listControls');
            if (listControls) listControls.style.display = (view === 'list') ? 'flex' : 'none';
            if(view === 'gantt') renderGantt(); // Render on show to ensure proper sizing
            if(view === 'priority_map') renderPriorityMap(); // Render on show to ensure proper sizing
        });
    });

    // Filters
    const filterStatus = document.getElementById('filterStatus');
    const filterKeyword = document.getElementById('filterKeyword');
if (filterKeyword) filterKeyword.addEventListener('keyup', () => { renderList(); renderKanban(); renderGantt(); renderPriorityMap(); });
if (filterStatus) filterStatus.addEventListener('change', () => { renderList(); renderKanban(); renderGantt(); renderPriorityMap(); });
    if (filterType) filterType.addEventListener('change', () => { renderList(); renderKanban(); renderGantt(); renderPriorityMap(); });
    if (filterAssignee) filterAssignee.addEventListener('change', () => { updateRoleFilterState(); renderList(); renderKanban(); renderGantt(); renderPriorityMap(); });
    const filterAssigneeRole = document.getElementById('filterAssigneeRole');
    if (filterAssigneeRole) filterAssigneeRole.addEventListener('change', () => { renderList(); renderKanban(); renderGantt(); renderPriorityMap(); });
    const filterProject = document.getElementById('filterProject');
    if (filterProject) filterProject.addEventListener('change', () => { renderList(); renderKanban(); renderGantt(); renderPriorityMap(); });

    // Completed Projects Filters
    const cfStart = document.getElementById('filterCompletedStartYear');
    if (cfStart) cfStart.addEventListener('change', renderCompletedProjects);
    const cfEnd = document.getElementById('filterCompletedEndYear');
    if (cfEnd) cfEnd.addEventListener('change', renderCompletedProjects);
    const cfOwner = document.getElementById('filterCompletedOwner');
    if (cfOwner) cfOwner.addEventListener('change', renderCompletedProjects);
    const cfKeyword = document.getElementById('filterCompletedKeyword');
    if (cfKeyword) cfKeyword.addEventListener('input', renderCompletedProjects);
    // Kanban Sort
    const kbSort = document.getElementById('kanbanSort'); if(kbSort) kbSort.addEventListener('change', renderKanban);

    // Default Header Action (Dashboard)
    if (headerActionBtn) {
        headerActionBtn.onclick = () => { editingTaskId = null; openTaskCreateModal(); };
    }

    // Sidebar Navigation
    navItems.forEach(item => {
        if (item) item.addEventListener('click', (e) => {
            e.preventDefault();
            navItems.forEach(n => n.classList.remove('active'));
            item.classList.add('active');
            
            const nav = item.dataset.nav;
            currentNav = nav;
            
            // Hide all nav containers
            Object.values(viewContainers).forEach(c => {
                if(c) c.style.display = 'none';
            });
            
            // Show target
            if(viewContainers[nav]) viewContainers[nav].style.display = 'block';
            
            // Update Header
            pageTitle.textContent = item.textContent;
            
            if(nav === 'analytics') {
            dashboardToggles.style.display = 'none';
            headerActionBtn.style.display = 'none';
            renderDashboard();
        } else if(nav === 'dashboard') {
                dashboardToggles.style.display = 'flex';
                headerActionBtn.style.display = 'block';
            headerActionBtn.textContent = '+ 新規タスク';
                headerActionBtn.onclick = () => { editingTaskId = null; openTaskCreateModal(); };
            } else if (nav === 'projects') {
                dashboardToggles.style.display = 'none';
                headerActionBtn.style.display = 'block';
            headerActionBtn.textContent = '+ 新規プロジェクト';
                headerActionBtn.onclick = () => openProjectModal('新規プロジェクト追加');
            } else if (nav === 'completed_projects') {
                dashboardToggles.style.display = 'none';
                headerActionBtn.style.display = 'none';
                window.populateCompletedFilters();
                window.renderCompletedProjects();
            } else if (nav === 'members') {
                dashboardToggles.style.display = 'none';
                headerActionBtn.textContent = '+ 新規メンバー';
                headerActionBtn.onclick = () => openUserModal('新規メンバー追加');
            } else if (nav === 'feedback_list') {
                dashboardToggles.style.display = 'none';
                headerActionBtn.style.display = 'none';
                window.renderFeedbackList();
            } else {
                dashboardToggles.style.display = 'none';
                headerActionBtn.style.display = 'none';
            }
            
            if(nav !== 'settings') headerActionBtn.style.display = 'block';
        });
    });

    // Save Buttons
    const saveProgressBtn = document.getElementById('saveProgressBtn');
    if (saveProgressBtn) saveProgressBtn.addEventListener('click', async () => {
        const memo = document.getElementById('modalProgressMemo').value;
        const verbatimEl = document.getElementById('modalProgressMemoVerbatim');
        const verbatim = verbatimEl ? verbatimEl.checked : false;
        try {
            const res = await fetch(`${API_BASE}/tasks/${currentOpenTaskId}`, {
                method: 'PUT',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ progress_memo: memo, progress_memo_verbatim: verbatim })
            });
            if (res.ok) {
                const t = tasks.find(x => String(x.id) === String(currentOpenTaskId));
                if (t) { t.progress_memo = memo; t.progress_memo_verbatim = verbatim; }
                const statusSpan = document.getElementById('saveProgressStatus');
                statusSpan.style.display = 'inline';
                setTimeout(() => statusSpan.style.display = 'none', 3000);
            } else {
                alert('エラーが発生しました。');
            }
        } catch (err) {
            console.error(err);
        }
    });

    const closeWeeklyReportModal = document.getElementById('closeWeeklyReportModal');
    if (closeWeeklyReportModal) {
        closeWeeklyReportModal.addEventListener('click', () => {
            const m = document.getElementById('weeklyReportModal');
            m.classList.remove('show');
            setTimeout(() => m.style.display = 'none', 300);
        });
    }
    const copyWeeklyReportBtn = document.getElementById('copyWeeklyReportBtn');
    if (copyWeeklyReportBtn) {
        copyWeeklyReportBtn.addEventListener('click', () => {
            const text = document.getElementById('weeklyReportContent').value;
            navigator.clipboard.writeText(text).then(() => {
                const s = document.getElementById('copyReportStatus');
                s.style.display = 'inline';
                setTimeout(() => s.style.display = 'none', 3000);
            }).catch(err => console.error(err));
        });
    }

    if (userModalSaveBtn) userModalSaveBtn.addEventListener('click', async () => {
        const val = userModalName.value.trim();
        if(!val) return;
        if(userModalId) await updateUser(userModalId, val);
        else await createUser(val);
        userModal.classList.remove('show');
        await fetchData();
        populateLoginUsers();
        renderAllViews();
    });

    if (projectModalSaveBtn) projectModalSaveBtn.addEventListener('click', async () => {
        try {
            const name = projectModalName.value.trim();
            if(!name) return;
            const weeklyMemoEl = document.getElementById('projectModalWeeklyMemo');
            const weeklyMemoVerbatimEl = document.getElementById('projectModalWeeklyMemoVerbatim');
            const data = {
                name,
                description: projectModalDesc.value.trim(),
                weekly_memo: weeklyMemoEl ? weeklyMemoEl.value : '',
                weekly_memo_verbatim: weeklyMemoVerbatimEl ? weeklyMemoVerbatimEl.checked : false,
                start_date: projectModalStart.value,
                due_date: projectModalDue.value,
                owner_id: (projectModalOwner && projectModalOwner.value) ? parseInt(projectModalOwner.value, 10) : null,
                status: (projectModalStatus && projectModalStatus.value) ? projectModalStatus.value : '進行中',
                business_category_id: (document.getElementById('projectModalCategory') && document.getElementById('projectModalCategory').value) ? parseInt(document.getElementById('projectModalCategory').value, 10) : null
            };
            if(projectModalId) {
                const res = await fetch(`${API_BASE}/projects/${projectModalId}`, { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify(data) });
                if(!res.ok) throw new Error(await res.text());
            } else {
                const res = await fetch(`${API_BASE}/projects`, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(data) });
                if(!res.ok) throw new Error(await res.text());
            }
            projectModal.classList.remove('show');
            await fetchData();
            renderAllViews();
        } catch (err) {
            console.error(err);
            alert("プロジェクト保存中にエラーが発生しました: " + err.message);
        }
    });

    const taskDeleteBtn = document.getElementById('taskDeleteBtn');
    if (taskDeleteBtn) taskDeleteBtn.addEventListener('click', async () => {
        if (!editingTaskId) return;
        if (!confirm('タスクを削除しますか？')) return;
        try {
            await fetch(`${API_BASE}/tasks/${editingTaskId}`, { method: 'DELETE' });
            await fetchData();
            renderAllViews();
            taskCreateModal.classList.remove('show');
        } catch(e) { console.error(e); }
    });

    if (taskCreateSaveBtn) taskCreateSaveBtn.addEventListener('click', async () => {
        const title = taskCreateTitle.value.trim();
        if(!title) return;
        
        const assigneesPayload = window.currentModalAssignees.map((a, i) => ({
            user_id: a.id,
            role: a.role,
            order_index: i + 1
        }));
        
        let finalProjectId = taskCreateProject.value || null;
        if (finalProjectId === 'NEW_PROJECT') {
            const newProjName = document.getElementById('newTaskProjectName').value.trim();
            if (newProjName) {
                const res = await fetch(`${API_BASE}/projects`, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ name: newProjName })
                });
                const resData = await res.json();
                if (resData && resData.id) {
                    finalProjectId = resData.id;
                } else {
                    finalProjectId = null;
                }
            } else {
                finalProjectId = null;
            }
        }

        const data = {
            title,
            description: taskCreateDesc.value.trim(),
            project_id: finalProjectId,
            business_category_id: document.getElementById('taskCreateCategory') ? document.getElementById('taskCreateCategory').value || null : null,
            assignees: assigneesPayload,
            task_type: taskCreateType.value,
            status: taskCreateStatus.value,
            start_date: taskCreateStart.value,
            due_date: taskCreateDue.value,
            importance: taskCreateImportance ? parseInt(taskCreateImportance.value, 10) : 50,
            user_id: currentUserId
        };
        if(editingTaskId) {
            await fetch(`${API_BASE}/tasks/${editingTaskId}`, { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify(data) });
            await fetchNotifications(); 
        } else {
            await createTask(data);
        }
        taskCreateModal.classList.remove('show');
        await fetchData();
        renderAllViews();
        
        if (editingTaskId && currentOpenTaskId === editingTaskId) {
            openModalById(editingTaskId);
        }
    });

    const editTaskBtn = document.getElementById('editTaskBtn');
    if (editTaskBtn) {
        editTaskBtn.addEventListener('click', () => {
            if(currentOpenTaskId) openTaskEditModal(currentOpenTaskId);
        });
    }

    const deleteTaskBtn = document.getElementById('deleteTaskBtn');
    if (deleteTaskBtn) {
        deleteTaskBtn.addEventListener('click', async () => {
            if (!currentOpenTaskId) return;
            if (!confirm('タスクを削除しますか？')) return;
            try {
                await fetch(`${API_BASE}/tasks/${currentOpenTaskId}`, { method: 'DELETE' });
                await fetchData();
                renderAllViews();
                document.getElementById('taskModal').classList.remove('show');
            } catch(e) { console.error(e); }
        });
    }

    // Theme Toggle
    const themeToggle = document.getElementById('themeToggle');
    const themeSlider = document.getElementById('themeSlider');
    
    if (themeToggle) themeToggle.addEventListener('change', (e) => {
        if(e.target.checked) {
            document.body.classList.add('dark-mode');
            themeSlider.style.backgroundColor = '#4f46e5';
    // localStorage.setItem('theme', 'dark');
        } else {
            document.body.classList.remove('dark-mode');
            themeSlider.style.backgroundColor = '#ccc';
    // localStorage.setItem('theme', 'light');
        }
    });

    // Check saved theme (Logic moved to appConfig loader)

    // Modal
    if (closeModalBtn) closeModalBtn.addEventListener('click', closeModal);
    if (modalStatus) modalStatus.addEventListener('change', async (e) => {
        const newStatus = e.target.value;
        await updateTaskStatus(currentOpenTaskId, newStatus);
    });

    if (newCommentInput) {
        newCommentInput.addEventListener('input', (e) => {
            const text = e.target.value;
            const cursorPos = e.target.selectionStart;
            const textBeforeCursor = text.substring(0, cursorPos);
            
            const match = textBeforeCursor.match(/@(\S*)$/);
            const popup = document.getElementById('mentionPopup');
            if (match && popup) {
                const search = match[1].toLowerCase();
                const extendedUsers = [...users, {name: '上司'}];
                const matchedUsers = extendedUsers.filter(u => u.name.toLowerCase().includes(search));
                
                if (matchedUsers.length > 0) {
                    popup.innerHTML = matchedUsers.map(u => `<div class="mention-item" data-name="${u.name}" style="padding: 8px; cursor: pointer; border-bottom: 1px solid rgba(255,255,255,0.1);">${u.name}</div>`).join('');
                    popup.style.display = 'block';
                    
                    popup.querySelectorAll('.mention-item').forEach(item => {
                        item.addEventListener('click', (ev) => {
                            const name = ev.target.dataset.name;
                            const newText = text.substring(0, match.index) + `@${name} ` + text.substring(cursorPos);
                            newCommentInput.value = newText;
                            popup.style.display = 'none';
                            newCommentInput.focus();
                        });
                    });
                } else {
                    popup.style.display = 'none';
                }
            } else if (popup) {
                popup.style.display = 'none';
            }
        });
    }

    if (sendCommentBtn) sendCommentBtn.addEventListener('click', async () => {
        const text = newCommentInput.value.trim();
        if(!text) return;
        
        const mentions = [];
        users.forEach(u => {
            if (text.includes(`@${u.name}`)) {
                mentions.push(u.id);
            }
        });
        
        await addComment(currentOpenTaskId, text, mentions);
        newCommentInput.value = '';
        
        // Hide mention dropdown if exists
        const popup = document.getElementById('mentionPopup');
        if (popup) popup.style.display = 'none';
    });

    // Kanban Drag & Drop
    window.initDragAndDrop = function() {
        const dropZones = document.querySelectorAll('.drop-zone');
        dropZones.forEach(zone => {
            if (zone) zone.addEventListener('dragover', e => {
                e.preventDefault();
                zone.classList.add('drag-over');
            });
            if (zone) zone.addEventListener('dragleave', e => {
                zone.classList.remove('drag-over');
            });
            if (zone) zone.addEventListener('drop', async e => {
                e.preventDefault();
                zone.classList.remove('drag-over');
                const taskId = e.dataTransfer.getData('text/plain');
                const col = zone.closest('.kanban-column');
                if(!col) return;
                const cards = col.querySelector('.kanban-cards');
                if(!cards) return;
                const newStatus = cards.dataset.status;
                if(!newStatus) return;
                await updateTaskStatus(taskId, newStatus);
            });
        });
    };
    initDragAndDrop();

    // Notifications toggle
    const notifBtn = document.getElementById('notifBtn');
    const notifDropdown = document.getElementById('notifDropdown');
    if (notifBtn) notifBtn.addEventListener('click', () => {
        notifDropdown.style.display = notifDropdown.style.display === 'none' ? 'block' : 'none';
    });
    if (document) document.addEventListener('click', (e) => {
        if(!notifBtn.contains(e.target) && !notifDropdown.contains(e.target)) {
            notifDropdown.style.display = 'none';
        }
    });

    // File Upload
    const uploadFile = document.getElementById('uploadFile');
    if (uploadFile) uploadFile.addEventListener('change', async (e) => {
        if(!currentOpenTaskId || e.target.files.length === 0) return;
        const file = e.target.files[0];
        const formData = new FormData();
        formData.append('file', file);
        formData.append('user_id', currentUserId);

        try {
            const res = await fetch(`${API_BASE}/tasks/${currentOpenTaskId}/attachments`, {
                method: 'POST',
                body: formData
            });
            if(res.ok) {
                const att = await res.json();
                appendAttachmentToModal(att);
            }
        } catch (err) {
            console.error('File upload failed', err);
        }
        e.target.value = ''; // reset
        document.getElementById('attachmentForm').style.display = 'none';
    });

    // Link Upload
    const uploadLinkBtn = document.getElementById('uploadLinkBtn');
    if (uploadLinkBtn) {
        uploadLinkBtn.addEventListener('click', async () => {
            const linkName = document.getElementById('attLinkName').value.trim();
            const linkPath = document.getElementById('attLinkPath').value.trim();
            if (!linkPath) {
                alert('パスを入力してください');
                return;
            }
            if (!currentOpenTaskId) return;

            const formData = new FormData();
            formData.append('user_id', currentUserId);
            formData.append('is_link', 'true');
            formData.append('filename', linkName);
            formData.append('filepath', linkPath);

            try {
                const res = await fetch(`${API_BASE}/tasks/${currentOpenTaskId}/attachments`, {
                    method: 'POST',
                    body: formData
                });
                if(res.ok) {
                    const att = await res.json();
                    appendAttachmentToModal(att);
                    document.getElementById('attLinkName').value = '';
                    document.getElementById('attLinkPath').value = '';
                    document.getElementById('attachmentForm').style.display = 'none';
                }
            } catch (err) {
                console.error('Link upload failed', err);
            }
        });
    }

    // Login Events
    const loginBtn = document.getElementById('loginBtn');
    const loginUserSelect = document.getElementById('loginUserSelect');
    const logoutBtn = document.getElementById('logoutBtn');

    if (loginBtn) loginBtn.addEventListener('click', async () => {
        const uid = loginUserSelect.value;
        if(!uid) return;
        
        currentUserId = uid;
        localStorage.setItem('currentUserId', uid);
        
        // Notify the backend so the notifier app can start
        try {
            await fetch(`${API_BASE}/notifier/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ user_id: parseInt(uid) })
            });
        } catch(e) {}
        
        const loginModal = document.getElementById('loginModal');
        loginModal.style.display = 'none';
        loginModal.style.opacity = '0';
        loginModal.style.pointerEvents = 'none';
        
        updateHeaderUser();
        
            const fAssignee = document.getElementById('filterAssignee');
    if (fAssignee) { fAssignee.value = uid; }

    renderAllViews();
        await fetchNotifications();
    });

    if (logoutBtn) logoutBtn.addEventListener('click', () => {
        currentUserId = null;
        localStorage.removeItem('currentUserId');
        
        const loginModal = document.getElementById('loginModal');
        loginModal.style.display = 'flex';
        loginModal.classList.add('show');
        loginModal.style.opacity = '1';
        loginModal.style.pointerEvents = 'auto';
        
        document.getElementById('headerUserName').textContent = '未ログイン';
        document.getElementById('headerUserAvatar').textContent = '-';
        document.getElementById('notifBadge').style.display = 'none';
    });

    } catch(e) {
        alert('Setup error: ' + e.message + '\n' + e.stack);
        console.error(e);
    }
}

function checkLoginStatus() {
    const loginModal = document.getElementById('loginModal');
    let validUser = false;
    
    if (currentUserId) {
        const user = users.find(u => String(u.id) === String(currentUserId));
        if (user) validUser = true;
    }
    
    if (!validUser) {
        localStorage.removeItem('currentUserId');
        localStorage.removeItem('nexus_user_id');
        currentUserId = null;
        loginModal.style.display = 'flex';
        loginModal.classList.add('show');
        loginModal.style.opacity = '1';
        loginModal.style.pointerEvents = 'auto';
        const headerUserName = document.getElementById('headerUserName');
        if(headerUserName) headerUserName.textContent = '未ログイン';
    } else {
        loginModal.style.display = 'none';
        loginModal.style.opacity = '0';
        loginModal.style.pointerEvents = 'none';
        updateHeaderUser();
    }
}

function updateHeaderUser() {
    if (!currentUserId) return;
    const user = users.find(u => String(u.id) === String(currentUserId));
    if (user) {
        document.getElementById('headerUserName').textContent = user.name;
        const headerAvatar = document.getElementById('headerUserAvatar');
        if (user.avatar_url) {
            headerAvatar.innerHTML = `<img src="${user.avatar_url}" style="width:100%; height:100%; border-radius:50%; object-fit:cover;">`;
            headerAvatar.style.background = 'transparent';
        } else {
            headerAvatar.innerHTML = '';
            headerAvatar.textContent = user.name.substring(0, 2);
            headerAvatar.style.background = 'var(--bg-surface)';
        }
    }
}

function populateLoginUsers() {
    const loginUserSelect = document.getElementById('loginUserSelect');
    // Clear existing options except the first one
    while (loginUserSelect.options.length > 1) {
        loginUserSelect.remove(1);
    }
    users.forEach(u => {
        const opt = document.createElement('option');
        opt.value = u.id;
        opt.textContent = u.name;
        loginUserSelect.appendChild(opt);
    });
    
    // Select last logged in user if available
    const lastUserId = localStorage.getItem('currentUserId');
    if (lastUserId) {
        loginUserSelect.value = lastUserId;
    }
}

function renderAllViews() {
    if (!currentUserId) return; // Don't render if not logged in
    renderList();
    renderKanban();
    renderSettingsStatuses();
    populateTaskStatusDropdown();
    try { renderGantt(); } catch(e) { console.error('Gantt Error', e); }
    try { renderPriorityMap(); } catch(e) { console.error('Priority Map Error', e); }
    try { renderProjects(); } catch(e) { console.error('Projects Error', e); }
    try { renderMembers(); } catch(e) { console.error('Members Error', e); }
}

// ---- Projects View ----
window.toggleProjectTasks = function(projectId) {
    const row = document.getElementById(`project-tasks-${projectId}`);
    if(row.style.display === 'none') {
        row.style.display = 'table-row';
    } else {
        row.style.display = 'none';
    }
}

function renderProjects() {
    const table = document.getElementById('projectsTable');
    if(!table) return;

    const showCompletedTasksCb = document.getElementById('showCompletedTasksInProjects');

    const bulkOwnerSel = document.getElementById('bulkSelectOwner');
    if (bulkOwnerSel && bulkOwnerSel.options.length <= 1) {
        bulkOwnerSel.innerHTML = '<option value="all">選択してください</option>';
        users.forEach(u => {
            bulkOwnerSel.innerHTML += `<option value="${u.id}">${u.name}</option>`;
        });
    }

    // Remember open accordions
    const openProjectIds = new Set();
    const openRows = table.querySelectorAll('.tasks-row[style*="display: table-row"]');
    openRows.forEach(row => {
        const pId = row.id.replace('project-tasks-', '');
        openProjectIds.add(pId);
    });

    while(table.tBodies.length > 0) { table.tBodies[0].remove(); }
    
    const allProjects = [...projects];
    const unassignedTasks = tasks.filter(t => !t.project_id);
    const unassignedByBc = new Map();
    unassignedTasks.forEach(t => {
        const bcId = t.business_category_id ? String(t.business_category_id) : 'null';
        if (!unassignedByBc.has(bcId)) {
            unassignedByBc.set(bcId, []);
        }
        unassignedByBc.get(bcId).push(t);
    });

    unassignedByBc.forEach((uList, bcId) => {
        allProjects.push({
            id: 'unassigned_' + bcId,
            name: 'プロジェクト外業務',
            task_count: uList.length,
            is_unassigned: true,
            business_category_id: bcId === 'null' ? null : parseInt(bcId)
        });
    });

    const categoriesMap = new Map();
    categoriesMap.set('null', { name: '(分類なし)', projects: [] });
    businessCategories.forEach(bc => {
        categoriesMap.set(String(bc.id), { name: bc.name, projects: [] });
    });
    
    allProjects.forEach(p => {
        const bcId = p.business_category_id ? String(p.business_category_id) : 'null';
        if (categoriesMap.has(bcId)) {
            categoriesMap.get(bcId).projects.push(p);
        } else {
            categoriesMap.get('null').projects.push(p);
        }
    });

    categoriesMap.forEach((catData, catId) => {
        if (catData.projects.length === 0) return;
        
        const catTbody = document.createElement('tbody');
        catTbody.innerHTML = `
            <tr style="background: rgba(255,255,255,0.08);">
                <td colspan="5" style="font-weight:bold; padding:12px 16px; font-size:1.05rem; border-bottom: 2px solid var(--border-color);">
                    <i class="fas fa-layer-group"></i> 業務分類: ${catData.name}
                </td>
            </tr>
        `;
        table.appendChild(catTbody);

        catData.projects.forEach(p => {
            const showCompletedTasks = showCompletedTasksCb ? showCompletedTasksCb.checked : true;
            let pTasks = p.is_unassigned ? tasks.filter(t => !t.project_id && (t.business_category_id ? String(t.business_category_id) : 'null') === String(p.business_category_id || 'null')) : tasks.filter(t => t.project_id == p.id);
            if (!showCompletedTasks) {
                pTasks = pTasks.filter(t => t.status !== '完了');
            }
            const todayStr = new Date().toISOString().split('T')[0];
            const urgentCount = pTasks.filter(t => t.due_date && t.due_date <= todayStr && t.status !== '完了').length;
            
            const tr = document.createElement('tr');
            tr.style.cursor = 'pointer';
            tr.setAttribute('data-project-id', p.id);
            /* removed global row click for inline edit */
            tr.className = 'project-row';
            tr.innerHTML = `
                <td style="text-align:center;">
                    <input type="checkbox" class="project-select-cb" value="${p.id}" style="transform: scale(1.5); cursor: pointer;" />
                </td>
                ${p.is_unassigned ? `<td>-</td>` : `<td class="drag-handle" style="cursor:grab;"><span style="color:#ccc; margin-right:5px; font-size:16px;">☰</span> ${p.id}</td>`}
                <td style="font-weight: 500;">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <span onclick="toggleProjectTasks('${p.id}')" style="cursor:pointer; display:inline-flex; align-items:center; gap:8px;">
                            ${p.name}
                            <span class="badge" style="background:var(--primary-color); color:white; font-size:12px;">タスク ${p.task_count || 0}</span>
                            ${urgentCount > 0 ? `<span class="badge" style="background:#ef4444; color:white; font-size:12px;">期限超過/本日迄: ${urgentCount}件</span>` : ''}
                        </span>
                        ${p.is_unassigned ? '' : `<button class="btn-sm" style="background:#10b981; color:white; border:none; border-radius:4px; padding:2px 6px;" onclick="event.stopPropagation(); editingTaskId = null; openTaskCreateModal(${p.id})">+ タスク追加</button>`}
                        ${p.is_unassigned ? '' : `<button class="btn-sm" style="background:#3b82f6; color:white; border:none; border-radius:4px; padding:2px 6px;" onclick="event.stopPropagation(); downloadProjectCsv(${p.id})">CSV出力</button>`}
                    </div>
                </td>
                <td>${p.task_count || 0}</td>
                <td class="crud-actions">
                    ${p.is_unassigned ? '' : `<button class="btn-primary btn-sm" onclick="openProjectModal('プロジェクト編集', ${p.id}, '${p.name}', '${p.description||''}', '${p.start_date||''}', '${p.due_date||''}', '${p.status||'進行中'}', '${p.owner_id||''}', '${p.business_category_id||''}')">編集</button>
                    <button class="btn-secondary btn-sm" onclick="duplicateProject(${p.id})">流用</button>
                    <button class="btn-danger btn-sm" onclick="deleteProject(${p.id})">削除</button>`}
                </td>
            `;
            const groupTbody = document.createElement('tbody');
            groupTbody.className = 'project-group';
            groupTbody.setAttribute('data-project-id', p.id);
            groupTbody.appendChild(tr);

            // Accordion Row
            const tasksRow = document.createElement('tr');
            tasksRow.className = 'tasks-row';
            tasksRow.id = `project-tasks-${p.id}`;
            if (openProjectIds.has(String(p.id))) {
                tasksRow.style.display = 'table-row';
            } else {
                tasksRow.style.display = 'none';
            }

            if(pTasks.length === 0) {
                tasksRow.innerHTML = `<td colspan="4" style="padding: 0; background: #f8fafc; border-bottom:2px solid var(--primary-color);">
                    <div style="padding: 16px 16px 16px 60px; border-left: 4px solid var(--primary-color); color:var(--text-secondary); font-size:0.875rem;">
                        <div style="background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); padding: 16px;">タスクなし</div>
                    </div>
                </td>`;
            } else {
                let tasksHtml = `<table style="width:100%; border-collapse: collapse;"><tbody>`;
                pTasks.forEach(t => {
                    const dateColorClass = getDueDateColorClass(t.due_date);
                    const trClass = t.status === '完了' ? '' : (dateColorClass || '');
                    
                    let statusClass = 'status-todo';
                    if(t.status === '処理中') statusClass = 'status-inprogress';
                    if(t.status === '完了') statusClass = 'status-done';
                    
                    let typeClass = 'type-routine';
                    if(t.task_type === 'HELP！') typeClass = 'type-sudden';
                    if(t.task_type === '大（数日以上）') typeClass = 'type-long';
                    if(t.task_type === '中（数時間）') typeClass = 'type-routine';
                    if(t.task_type === '小（すぐ終わる）') typeClass = 'status-done';

                    tasksHtml += `
                    <tr class="${trClass}" data-task-id="${t.id}">
                        <td style="padding-left:12px;" onclick="startInlineEdit(event, ${t.id}, 'status')">
                        <div style="display:flex; align-items:center;">
                            <span class="drag-handle" onclick="event.stopPropagation()" style="display:inline-block; user-select:none; -webkit-user-select:none; color:#ccc; margin-right:8px; cursor:grab; font-size:16px; padding:4px;">☰</span>
                            <div class="inline-text inline-edit-trigger" style="flex:1;">
                                <span class="badge ${statusClass}" style="cursor:pointer;">${t.status}</span>
                            </div>
                            <div class="inline-input" style="display:none; flex:1;">
                                <select class="inline-edit-input" onchange="saveInlineEdit(${t.id}, 'status', this.value)" onblur="cancelInlineEdit(event)" onclick="event.stopPropagation()">
                                    <option value="未対応" ${t.status==='未対応'?'selected':''}>未対応</option>
                                    <option value="処理中" ${t.status==='処理中'?'selected':''}>処理中</option>
                                    <option value="依頼中" ${t.status==='依頼中'?'selected':''}>依頼中</option>
                                    <option value="完了" ${t.status==='完了'?'selected':''}>完了</option>
                                </select>
                            </div>
                        </div>
                    </td>
                        <td style="font-weight: 500; cursor:pointer;" onclick="openModalById(${t.id})">${getBadgesHtml(t.id)}${t.subtasks_total > 0 ? `<span style='font-size:0.8rem; color:var(--text-secondary); background:rgba(255,255,255,0.1); padding:2px 4px; border-radius:4px; margin-right:4px;'>&#9745; ${t.subtasks_completed}/${t.subtasks_total}</span>` : ''}${t.title}</td>
                        <td onclick="showAssigneePopup(event, ${t.id})">
                    <div class="inline-edit-trigger" style="display: flex; align-items: center; gap: 4px; flex-wrap: wrap; width: 100%; height: 100%;">
                        ${renderAssignees(t.assignees) || '<span style="color:#aaa;">未設定</span>'}
                    </div>
                </td>
                        <td onclick="startInlineEdit(event, ${t.id}, 'start_date')">
                            <div class="inline-text inline-edit-trigger">${t.start_date || '<span style="color:#aaa;">未設定</span>'}</div>
                            <div class="inline-input" style="display:none;">
                                <input type="date" class="inline-edit-input" value="${t.start_date||''}" onchange="saveInlineEdit(${t.id}, 'start_date', this.value)" onblur="cancelInlineEdit(event)" onclick="event.stopPropagation()">
                            </div>
                        </td>
                        <td onclick="startInlineEdit(event, ${t.id}, 'due_date')">
                            <div class="inline-text inline-edit-trigger">${t.due_date || '<span style="color:#aaa;">未設定</span>'}</div>
                            <div class="inline-input" style="display:none;">
                                <input type="date" class="inline-edit-input" value="${t.due_date||''}" onchange="saveInlineEdit(${t.id}, 'due_date', this.value)" onblur="cancelInlineEdit(event)" onclick="event.stopPropagation()">
                            </div>
                        </td>

                        <td onclick="startInlineEdit(event, ${t.id}, 'task_type')">
                            <div class="inline-text inline-edit-trigger">
                                <span class="badge ${typeClass}">${t.task_type}</span>
                            </div>
                            <div class="inline-input" style="display:none;">
                                <select class="inline-edit-input" onchange="saveInlineEdit(${t.id}, 'task_type', this.value)" onblur="cancelInlineEdit(event)" onclick="event.stopPropagation()">
                                    <option value="HELP！" ${t.task_type==='HELP！'?'selected':''}>HELP！</option>
                                    <option value="大（数日以上）" ${t.task_type==='大（数日以上）'?'selected':''}>大（数日以上）</option>
                                    <option value="中（数時間）" ${t.task_type==='中（数時間）'?'selected':''}>中（数時間）</option>
                                    <option value="小（すぐ終わる）" ${t.task_type==='小（すぐ終わる）'?'selected':''}>小（すぐ終わる）</option>
                                </select>
                            </div>
                        </td>
                    </tr>`;
                });
                tasksHtml += `</tbody></table>`;
                
                tasksRow.innerHTML = `<td colspan="4" style="padding: 0; background: #f8fafc; border-bottom:2px solid var(--primary-color);">
                    <div style="padding: 8px 16px 16px 60px; border-left: 4px solid var(--primary-color);">
                        <div style="background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden;">
                            ${tasksHtml}
                        </div>
                    </div>
                </td>`;
            }
            groupTbody.appendChild(tasksRow);
            table.appendChild(groupTbody);
        });
    });
    initSortable();
}

window.getAssigneesText = function(assignees) {
    if(!assignees || !assignees.length) return '';
    return assignees.map(a => {
        let rolePrefix = '';
        if(a.role === '主担当') rolePrefix = '主 ';
        else if(a.role === '副担当') rolePrefix = '副 ';
        return `${rolePrefix}${a.name}`;
    }).join(', ');
}

window.exportProjectCsv = function(projectId, projectName) {
    const projectTasks = tasks.filter(t => t.project_id == projectId);
    if (projectTasks.length === 0) {
        alert("このプロジェクトにはタスクがありません。");
        return;
    }
    let csvContent = "\uFEFFタスクID,タスク名,説明,ステータス,担当者,開始日,期日,タスク種別,進捗メモ,前週ステータス,前週進捗メモ,進捗あり\n";
    projectTasks.forEach(t => {
        const hasProgress = (t.status !== t.last_status || t.progress_memo !== t.last_progress_memo) ? "あり" : "なし";
        const row = [
            t.id,
            `"${(t.title || '').replace(/"/g, '""')}"`,
            `"${(t.description || '').replace(/"/g, '""')}"`,
            `"${(t.status || '').replace(/"/g, '""')}"`,
            `"${getAssigneesText(t.assignees).replace(/"/g, '""')}"`,
            `"${(t.start_date || '').replace(/"/g, '""')}"`,
            `"${(t.due_date || '').replace(/"/g, '""')}"`,
            `"${(t.task_type || '').replace(/"/g, '""')}"`,
            `"${(t.progress_memo || '').replace(/"/g, '""')}"`,
            `"${(t.last_status || '').replace(/"/g, '""')}"`,
            `"${(t.last_progress_memo || '').replace(/"/g, '""')}"`,
            `"${hasProgress}"`
        ].join(",");
        csvContent += row + "\n";
    });
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `${projectName}_tasks.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}


// ---- Members View ----
const openUserIds = new Set();

window.toggleUserTasks = function(userId) {
    const row = document.getElementById(`user-tasks-${userId}`);
    if(row) {
        if(row.style.display === 'none') {
            row.style.display = 'table-row';
            openUserIds.add(parseInt(userId));
        } else {
            row.style.display = 'none';
            openUserIds.delete(parseInt(userId));
        }
    }
}

function renderMembers() {
    const tbody = document.getElementById('membersBody');
    if(!tbody) return;
    tbody.innerHTML = '';
    users.forEach(u => {
        const uTasks = tasks.filter(t => t.assignees && t.assignees.some(a => a.id == u.id));
        const count = uTasks.length;
        const primaryCount = uTasks.filter(t => t.assignees && t.assignees.some(a => a.id == u.id && a.role === 'main')).length;
        
        const todayStr = new Date().toISOString().split('T')[0];
        const urgentCount = uTasks.filter(t => t.due_date && t.due_date <= todayStr && t.status !== '完了').length;

        const tr = document.createElement('tr');
        tr.setAttribute('data-user-id', u.id);
        
        tr.innerHTML = `
            
            <td>${u.id}</td>
            <td style="font-weight: 500;">
                <span onclick="toggleUserTasks('${u.id}')" style="cursor:pointer; display:inline-flex; align-items:center; gap:8px;">
                    ${u.name}
                    ${urgentCount > 0 ? `<span class="badge" style="background:#ef4444; color:white; font-size:12px;">期限超過/本日迄: ${urgentCount}件</span>` : ''}
                </span>
            </td>
            <td>${count} <span style="font-size:0.9rem; color:#64748b;">(うち主担当: ${primaryCount})</span></td>
            <td class="crud-actions">
                            <button class="btn-primary btn-sm" onclick="openUserModal('メンバー編集', ${u.id}, '${u.name}', '${u.avatar_url || ''}')">編集</button>
                            <button class="btn-danger btn-sm" onclick="deleteUser(${u.id})">削除</button>
            </td>
        `;
        tbody.appendChild(tr);

        // Accordion Row
        const tasksRow = document.createElement('tr');
        tasksRow.className = 'user-tasks-row';
        tasksRow.id = `user-tasks-${u.id}`;
        if (openUserIds.has(u.id)) {
            tasksRow.style.display = 'table-row';
        } else {
            tasksRow.style.display = 'none';
        }

        if(uTasks.length === 0) {
            tasksRow.innerHTML = `<td colspan="4" style="padding: 0; background: #f8fafc; border-bottom:2px solid var(--primary-color);">
                <div style="padding: 16px 16px 16px 60px; border-left: 4px solid var(--primary-color); color:var(--text-secondary); font-size:0.875rem;">
                    <div style="background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); padding: 16px;">担当タスクなし</div>
                </div>
            </td>`;
        } else {
            let tasksHtml = `<table style="width:100%; border-collapse: collapse;"><tbody>`;

            const categoriesMap = new Map();
            categoriesMap.set('null', { name: '(分類なし)', tasks: [] });
            businessCategories.forEach(bc => {
                categoriesMap.set(String(bc.id), { name: bc.name, tasks: [] });
            });

            uTasks.forEach(t => {
                let bcId = null;
                if (t.project_id) {
                    const p = projects.find(pr => pr.id == t.project_id);
                    if (p && p.business_category_id) {
                        bcId = String(p.business_category_id);
                    }
                }
                if (!bcId && t.business_category_id) {
                    bcId = String(t.business_category_id);
                }
                if (!bcId) bcId = 'null';
                
                if (categoriesMap.has(bcId)) {
                    categoriesMap.get(bcId).tasks.push(t);
                } else {
                    categoriesMap.get('null').tasks.push(t);
                }
            });

            categoriesMap.forEach((catData, catId) => {
                if (catData.tasks.length === 0) return;
                
                tasksHtml += `
                    <tr>
                        <td colspan="7" style="font-weight:bold; padding:12px 16px; font-size:1.05rem; border-bottom: 2px solid var(--border-color); background: rgba(0,0,0,0.02);">
                            <i class="fas fa-layer-group"></i> 業務分類: ${catData.name}
                        </td>
                    </tr>
                `;
                
                catData.tasks.sort((a, b) => (a.project_name || '').localeCompare(b.project_name || ''));
                
                catData.tasks.forEach(t => {
                    const dateColorClass = getDueDateColorClass(t.due_date);
                    const trClass = t.status === '完了' ? '' : (dateColorClass || '');
                    
                    let statusClass = 'status-todo';
                    if(t.status === '処理中') statusClass = 'status-inprogress';
                    if(t.status === '完了') statusClass = 'status-done';
                    
                    let typeClass = 'type-routine';
                    if(t.task_type === 'HELP！') typeClass = 'type-sudden';
                    if(t.task_type === '大（数日以上）') typeClass = 'type-long';
                    if(t.task_type === '中（数時間）') typeClass = 'type-routine';
                    if(t.task_type === '小（すぐ終わる）') typeClass = 'status-done';
                    
                    tasksHtml += `
                    <tr class="${trClass}" data-task-id="${t.id}">
                        <td style="padding-left:12px;" onclick="startInlineEdit(event, ${t.id}, 'status')">
                            <div class="inline-text inline-edit-trigger" style="flex:1;">
                                <span class="badge ${statusClass}" style="cursor:pointer;">${t.status}</span>
                            </div>
                            <div class="inline-input" style="display:none; flex:1;">
                                <select class="inline-edit-input" onchange="saveInlineEdit(${t.id}, 'status', this.value)" onblur="cancelInlineEdit(event)" onclick="event.stopPropagation()">
                                    <option value="未対応" ${t.status==='未対応'?'selected':''}>未対応</option>
                                    <option value="処理中" ${t.status==='処理中'?'selected':''}>処理中</option>
                                    <option value="依頼中" ${t.status==='依頼中'?'selected':''}>依頼中</option>
                                    <option value="完了" ${t.status==='完了'?'selected':''}>完了</option>
                                </select>
                            </div>
                        </td>
                        <td style="font-weight: 500; cursor:pointer;" onclick="openModalById(${t.id})">${getBadgesHtml(t.id)}${t.subtasks_total > 0 ? `<span style='font-size:0.8rem; color:var(--text-secondary); background:rgba(255,255,255,0.1); padding:2px 4px; border-radius:4px; margin-right:4px;'>&#9745; ${t.subtasks_completed}/${t.subtasks_total}</span>` : ''}${t.title}</td>
                        <td style="font-size:0.9rem; color:#64748b;">${t.project_name || 'プロジェクト外業務'}</td>
                        <td onclick="showAssigneePopup(event, ${t.id})">
                            <div class="inline-edit-trigger" style="display: flex; align-items: center; gap: 4px; flex-wrap: wrap; width: 100%; height: 100%;">
                                ${renderAssignees(t.assignees) || '<span style="color:#aaa;">未設定</span>'}
                            </div>
                        </td>
                        <td onclick="startInlineEdit(event, ${t.id}, 'start_date')">
                            <div class="inline-text inline-edit-trigger">${t.start_date || '<span style="color:#aaa;">未設定</span>'}</div>
                            <div class="inline-input" style="display:none;">
                                <input type="date" class="inline-edit-input" value="${t.start_date||''}" onchange="saveInlineEdit(${t.id}, 'start_date', this.value)" onblur="cancelInlineEdit(event)" onclick="event.stopPropagation()">
                            </div>
                        </td>
                        <td onclick="startInlineEdit(event, ${t.id}, 'due_date')">
                            <div class="inline-text inline-edit-trigger">${t.due_date || '<span style="color:#aaa;">未設定</span>'}</div>
                            <div class="inline-input" style="display:none;">
                                <input type="date" class="inline-edit-input" value="${t.due_date||''}" onchange="saveInlineEdit(${t.id}, 'due_date', this.value)" onblur="cancelInlineEdit(event)" onclick="event.stopPropagation()">
                            </div>
                        </td>

                        <td onclick="startInlineEdit(event, ${t.id}, 'task_type')">
                            <div class="inline-text inline-edit-trigger">
                                <span class="badge ${typeClass}">${t.task_type}</span>
                            </div>
                            <div class="inline-input" style="display:none;">
                                <select class="inline-edit-input" onchange="saveInlineEdit(${t.id}, 'task_type', this.value)" onblur="cancelInlineEdit(event)" onclick="event.stopPropagation()">
                                    <option value="HELP！" ${t.task_type==='HELP！'?'selected':''}>HELP！</option>
                                    <option value="大（数日以上）" ${t.task_type==='大（数日以上）'?'selected':''}>大（数日以上）</option>
                                    <option value="中（数時間）" ${t.task_type==='中（数時間）'?'selected':''}>中（数時間）</option>
                                    <option value="小（すぐ終わる）" ${t.task_type==='小（すぐ終わる）'?'selected':''}>小（すぐ終わる）</option>
                                </select>
                            </div>
                        </td>
                    </tr>`;
                });
            });
            tasksHtml += `</tbody></table>`;
            
            tasksRow.innerHTML = `<td colspan="4" style="padding: 0; background: #f8fafc; border-bottom:2px solid var(--primary-color);">
                <div style="padding: 8px 16px 16px 60px; border-left: 4px solid var(--primary-color);">
                    <div style="background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden;">
                        ${tasksHtml}
                    </div>
                </div>
            </td>`;
        }
        tbody.appendChild(tasksRow);
    });
}

window.openUserModal = function(title, id=null, currentVal='', avatarUrl=null) {
    userModalId = id;
    userModalTitle.textContent = title;
    userModalName.value = currentVal;
    
    const preview = document.getElementById('userModalAvatarPreview');
    const actions = document.getElementById('avatarActionsContainer');
    if (actions) {
        actions.style.display = id ? 'block' : 'none';
    }

    if (avatarUrl) {
        preview.innerHTML = `<img src="${avatarUrl}" style="width:100%; height:100%; border-radius:50%; object-fit:cover;">`;
        preview.style.background = 'transparent';
        preview.style.border = 'none';
    } else {
        const initials = currentVal ? currentVal.substring(0, 2) : '-';
        preview.innerHTML = initials;
        preview.style.background = 'var(--bg-surface)';
        preview.style.border = '2px dashed var(--border-color)';
    }

    userModal.classList.add('show');
    userModalName.focus();
}

document.getElementById('userModalName').addEventListener('input', (e) => {
    const preview = document.getElementById('userModalAvatarPreview');
    if (preview && !preview.querySelector('img')) {
        const val = e.target.value.trim();
        preview.innerHTML = val ? val.substring(0, 2) : '-';
    }
});

window.openProjectModal = function(title, id=null, name='', desc='', start='', due='', status='進行中', ownerId='', categoryId='') {
    projectModalId = id;
    projectModalTitle.textContent = title;
    projectModalName.value = name;
    projectModalDesc.value = desc;
    projectModalStart.value = start;
    projectModalDue.value = due;

    const weeklyMemoEl = document.getElementById('projectModalWeeklyMemo');
    const weeklyMemoVerbatimEl = document.getElementById('projectModalWeeklyMemoVerbatim');
    const proj = id ? projects.find(p => p.id === id) : null;
    if (weeklyMemoEl) weeklyMemoEl.value = proj ? (proj.weekly_memo || '') : '';
    if (weeklyMemoVerbatimEl) weeklyMemoVerbatimEl.checked = proj ? !!proj.weekly_memo_verbatim : false;
    
    if (document.getElementById('projectModalCategory')) {
        document.getElementById('projectModalCategory').value = categoryId || '';
    }
    
    if (projectModalOwner) {
        projectModalOwner.innerHTML = '<option value="">(なし)</option>';
        users.forEach(u => {
            projectModalOwner.innerHTML += `<option value="${u.id}">${u.name}</option>`;
        });
        projectModalOwner.value = ownerId || '';
    }
    if (projectModalStatus) {
        projectModalStatus.value = status;
    }
    
    projectModal.classList.add('show');
    projectModalName.focus();
}

window.duplicateProject = async function(id) {
    if(!confirm("このプロジェクトとすべてのタスクをそのまま流用（コピー）しますか？")) return;
    try {
        const res = await fetch(`${API_BASE}/projects/${id}/duplicate`, { method: 'POST' });
        if(res.ok) {
            await fetchData();
            renderAllViews();
        }
    } catch(err) { console.error(err); }
}


window.copyTask = async function(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;
    window.openTaskCreateModal(task.project_id, task.title, task.description);
    
    if (taskCreateStart) taskCreateStart.value = task.start_date || '';
    if (taskCreateDue) taskCreateDue.value = task.due_date || '';
    if (taskCreateType) taskCreateType.value = task.task_type || 'task';
    if (taskCreateStatus) taskCreateStatus.value = task.status || '未対応';
    
    // Set multi-select assignees by assigning to currentModalAssignees array
    if (task.assignees) {
        window.currentModalAssignees = [...task.assignees];
    } else {
        window.currentModalAssignees = [];
    }
    if (window.renderModalAssigneeUI) {
        window.renderModalAssigneeUI();
    }
}

window.updateTaskCreateProjectOptions = function() {
    const categoryId = document.getElementById('taskCreateCategory') ? document.getElementById('taskCreateCategory').value : '';
    const projectSelect = document.getElementById('taskCreateProject');
    if (!projectSelect) return;
    
    const currentVal = projectSelect.value;
    projectSelect.innerHTML = '<option value="">プロジェクト外業務</option>';
    
    projects.forEach(p => {
        const pCatId = (p.business_category_id === null || p.business_category_id === undefined) ? '' : String(p.business_category_id);
        if (pCatId === String(categoryId)) {
            projectSelect.innerHTML += `<option value="${p.id}">${p.name}</option>`;
        }
    });
    projectSelect.innerHTML += '<option value="NEW_PROJECT">+ 新しいプロジェクトを作成</option>';
    
    if (currentVal && Array.from(projectSelect.options).some(opt => opt.value === currentVal)) {
        projectSelect.value = currentVal;
    }
};

document.addEventListener('DOMContentLoaded', () => {
    const catSel = document.getElementById('taskCreateCategory');
    if (catSel) catSel.addEventListener('change', window.updateTaskCreateProjectOptions);
});

window.openTaskCreateModal = function(projectId=null, title=null, desc=null) {
    editingTaskId = null;
    if (document.getElementById('taskCreateCategory')) document.getElementById('taskCreateCategory').value = '';
    window.updateTaskCreateProjectOptions();
    const npn = document.getElementById('newTaskProjectName');
    if (npn) { npn.style.display = 'none'; npn.value = ''; }
    if(projectId) taskCreateProject.value = projectId;
    
    window.currentModalAssignees = [];
    window.renderModalAssigneeUI();
    
    taskCreateTitle.value = title || '';
    taskCreateDesc.value = desc || '';
    taskCreateType.value = 'タスク';
    taskCreateStatus.value = '未対応';
    taskCreateStart.value = '';
    taskCreateDue.value = '';
    window.setImportanceSlider(50);

    document.querySelector('#taskCreateModal .modal-title').textContent = "新規タスク追加";
    const deleteBtn = document.getElementById('taskDeleteBtn');
    if (deleteBtn) deleteBtn.style.display = 'none';
    taskCreateModal.classList.add('show');
    taskCreateTitle.focus();
}

window.currentModalAssignees = [];

window.renderModalAssigneeUI = function() {
    const container = document.getElementById('taskCreateAssignee');
    if (!container) return;
    let html = '';
    users.forEach(u => {
        const idx = window.currentModalAssignees.findIndex(a => parseInt(a.id) === parseInt(u.id));
        const role = idx !== -1 ? window.currentModalAssignees[idx].role : null;
        const order = idx !== -1 ? idx + 1 : '';
        
        const mainStyle = role === 'main' ? 'background:var(--primary-color); color:white; border-color:var(--primary-color);' : 'background:white; color:#64748b; border-color:#cbd5e1;';
        const subStyle = role === 'sub' ? 'background:#64748b; color:white; border-color:#64748b;' : 'background:white; color:#64748b; border-color:#cbd5e1;';
        const mainText = role === 'main' ? order : '主';
        const subText = role === 'sub' ? order : '副';
        
        html += `
            <div class="assignee-select-row" style="display:flex; align-items:center; gap:8px; margin-bottom:8px;">
                <div onclick="toggleModalAssigneeRole(${u.id}, 'main')" style="border:1px solid #cbd5e1; border-radius:4px; width:24px; height:24px; display:flex; align-items:center; justify-content:center; cursor:pointer; font-size:12px; user-select:none; ${mainStyle}">${mainText}</div>
                <div onclick="toggleModalAssigneeRole(${u.id}, 'sub')" style="border:1px solid #cbd5e1; border-radius:4px; width:24px; height:24px; display:flex; align-items:center; justify-content:center; cursor:pointer; font-size:12px; user-select:none; ${subStyle}">${subText}</div>
                <span style="font-size:14px;">${u.name}</span>
            </div>
        `;
    });
    container.innerHTML = html;
};

window.toggleModalAssigneeRole = function(userId, role) {
    const idx = window.currentModalAssignees.findIndex(a => parseInt(a.id) === parseInt(userId));
    if (idx !== -1) {
        if (window.currentModalAssignees[idx].role === role) {
            window.currentModalAssignees.splice(idx, 1);
        } else {
            window.currentModalAssignees[idx].role = role;
            const item = window.currentModalAssignees.splice(idx, 1)[0];
            window.currentModalAssignees.push(item);
        }
    } else {
        window.currentModalAssignees.push({id: userId, role: role});
    }
    window.renderModalAssigneeUI();
};

window.openTaskEditModal = function(taskId) {
    editingTaskId = taskId;
    const task = tasks.find(t => t.id == taskId);
    if(!task) {
        alert('対象のタスクが見つかりません。既に削除された可能性があります。');
        return;
    }
    
    window.currentModalAssignees = task.assignees ? task.assignees.map(a => ({id: a.id, role: a.role || 'sub'})) : [];
    window.renderModalAssigneeUI();

    taskCreateTitle.value = task.title;
    taskCreateDesc.value = task.description || '';
    // The project dropdown is filtered by whatever category is selected
    // (updateTaskCreateProjectOptions), so the category shown here must
    // match the task's *project's* category - not the task's own
    // business_category_id, which can be null/stale for a task that has
    // a project (that field really only matters for project-less tasks).
    // Otherwise the task's own project silently disappears from the
    // filtered list and both dropdowns come up blank.
    let categoryForEdit = task.business_category_id || '';
    if (task.project_id) {
        const proj = projects.find(p => p.id == task.project_id);
        if (proj) categoryForEdit = proj.business_category_id || '';
    }
    if (document.getElementById('taskCreateCategory')) document.getElementById('taskCreateCategory').value = categoryForEdit;
    window.updateTaskCreateProjectOptions();
    taskCreateProject.value = task.project_id || '';
    taskCreateType.value = task.task_type || 'タスク';
    taskCreateStatus.value = task.status || '未対応';
    taskCreateStart.value = task.start_date || '';
    taskCreateDue.value = task.due_date || '';
    window.setImportanceSlider(task.importance != null ? task.importance : 50);

    document.querySelector('#taskCreateModal .modal-title').textContent = "タスク編集";
    const deleteBtn = document.getElementById('taskDeleteBtn');
    if (deleteBtn) deleteBtn.style.display = 'block';
    taskCreateModal.classList.add('show');
    taskCreateTitle.focus();
}

// ---- CRUD APIs ----
async function createProject(data) {
    await fetch(`${API_BASE}/projects`, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(data) });
}
async function updateProject(id, data) {
    await fetch(`${API_BASE}/projects/${id}`, { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify(data) });
}
window.deleteProject = async function(id) {
    if(!confirm('本当にこのプロジェクトを削除しますか？\n（プロジェクト内のすべてのタスクも同時に削除されます）')) return;
    await fetch(`${API_BASE}/projects/${id}`, { method: 'DELETE' });
    await fetchData();
    renderAllViews();
}

async function createUser(name) {
    await fetch(`${API_BASE}/users`, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({name}) });
}
async function updateUser(id, name) {
    await fetch(`${API_BASE}/users/${id}`, { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify({name}) });
}
window.deleteUser = async function(id) {
    if(!confirm('本当にこのメンバーを削除しますか？\n（担当していたタスクは「未設定」になります）')) return;
    await fetch(`${API_BASE}/users/${id}`, { method: 'DELETE' });
    await fetchData();
    renderAllViews();
}

// ---- List View ----

function getFilteredTasks(includeStatus = false) {
    const typeFilter = document.getElementById('filterType') ? document.getElementById('filterType').value : 'all';
    const assigneeFilter = document.getElementById('filterAssignee') ? document.getElementById('filterAssignee').value : 'all';
    const roleFilter = document.getElementById('filterAssigneeRole') ? document.getElementById('filterAssigneeRole').value : 'all';
    const projectFilter = document.getElementById('filterProject') ? document.getElementById('filterProject').value : 'all';
    const statusFilter = document.getElementById('filterStatus') ? document.getElementById('filterStatus').value : 'all';
    const keywordFilter = document.getElementById('filterKeyword') ? document.getElementById('filterKeyword').value.toLowerCase() : '';

    return tasks.filter(t => {
        const matchType = typeFilter === 'all' || t.task_type === typeFilter;
        const matchProject = projectFilter === 'all' || t.project_name === projectFilter;
        let matchStatus = true;
        if (includeStatus) {
            matchStatus = statusFilter === 'all' || t.status === statusFilter;
        }

        const showCompleted = document.getElementById('showCompletedToggle') && document.getElementById('showCompletedToggle').checked;
        if (!showCompleted && t.status === '完了') {
            return false;
        }

        let matchAssignee = true;
        if (assigneeFilter !== 'all') {
            if (t.assignees && t.assignees.length > 0) {
                const assigneeObj = t.assignees.find(a => a.id == assigneeFilter);
                if (assigneeObj) {
                    if (roleFilter === 'main') {
                        matchAssignee = assigneeObj.role === 'main';
                    } else {
                        matchAssignee = true;
                    }
                } else {
                    matchAssignee = false;
                }
            } else {
                matchAssignee = false;
            }
        }

        const matchKeyword = keywordFilter === '' || t.title.toLowerCase().includes(keywordFilter) || (t.description && t.description.toLowerCase().includes(keywordFilter)) || (t.project_name && t.project_name.toLowerCase().includes(keywordFilter));
        return matchType && matchProject && matchStatus && matchAssignee && matchKeyword;
    });
}

function renderList() {
    let filtered = getFilteredTasks(true);
    
    const listSort = document.getElementById('listSort');
    const sortVal = listSort ? listSort.value : 'default';

    if (sortVal === 'date_asc') {
        filtered.sort((a, b) => new Date(a.due_date || '9999-12-31') - new Date(b.due_date || '9999-12-31'));
    } else if (sortVal === 'date_desc') {
        filtered.sort((a, b) => new Date(b.due_date || '1970-01-01') - new Date(a.due_date || '1970-01-01'));
    } else if (sortVal === 'project') {
        filtered.sort((a, b) => (a.project_name || '').localeCompare(b.project_name || ''));
    } else if (sortVal === 'workload') {
        const order = { 'HELP！': 1, '大（数日以上）': 2, '中（数時間）': 3, '小（すぐ終わる）': 4 };
        filtered.sort((a, b) => (order[a.task_type] || 99) - (order[b.task_type] || 99));
    }

    const categoriesMap = new Map();
    categoriesMap.set('null', { name: '(分類なし)', tasks: [] });
    businessCategories.forEach(bc => {
        categoriesMap.set(String(bc.id), { name: bc.name, tasks: [] });
    });

    filtered.forEach(t => {
        let bcId = null;
        if (t.project_id) {
            const p = projects.find(pr => pr.id == t.project_id);
            if (p && p.business_category_id) {
                bcId = String(p.business_category_id);
            }
        }
        if (!bcId && t.business_category_id) {
            bcId = String(t.business_category_id);
        }
        if (!bcId) bcId = 'null';
        if (categoriesMap.has(bcId)) {
            categoriesMap.get(bcId).tasks.push(t);
        } else {
            categoriesMap.get('null').tasks.push(t);
        }
    });

    listBody.innerHTML = '';
    
    categoriesMap.forEach((catData, catId) => {
        if (catData.tasks.length === 0) return;
        
        const headerTr = document.createElement('tr');
        headerTr.style.background = 'rgba(255,255,255,0.08)';
        headerTr.innerHTML = `
            <td colspan="8" style="font-weight:bold; padding:12px 16px; font-size:1.05rem; border-bottom: 2px solid var(--border-color);">
                <i class="fas fa-layer-group"></i> 業務分類: ${catData.name}
            </td>
        `;
        listBody.appendChild(headerTr);

        catData.tasks.forEach(t => {
            const tr = document.createElement('tr');
            tr.setAttribute('data-task-id', t.id);
            tr.style.cursor = 'pointer';
            /* removed global row click for inline edit */
            const dateColorClass = getDueDateColorClass(t.due_date);
            if(dateColorClass) tr.classList.add(dateColorClass);

            let statusClass = 'status-todo';
            if(t.status === '処理中') statusClass = 'status-inprogress';
            if(t.status === '完了') statusClass = 'status-done';
            
            let typeClass = 'type-routine';
            if(t.task_type === 'HELP！') typeClass = 'type-sudden';
            if(t.task_type === '大（数日以上）') typeClass = 'type-long';
            if(t.task_type === '中（数時間）') typeClass = 'type-routine';
            if(t.task_type === '小（すぐ終わる）') typeClass = 'status-done';

            tr.innerHTML = `
                <td style="padding-left:12px;" onclick="startInlineEdit(event, ${t.id}, 'status')">
                        <div style="display:flex; align-items:center;">
                            <span class="drag-handle" onclick="event.stopPropagation()" style="display:inline-block; user-select:none; -webkit-user-select:none; color:#ccc; margin-right:8px; cursor:grab; font-size:16px; padding:4px;">☰</span>
                            <div class="inline-text inline-edit-trigger" style="flex:1;">
                                <span class="badge ${statusClass}" style="cursor:pointer;">${t.status}</span>
                            </div>
                            <div class="inline-input" style="display:none; flex:1;">
                                <select class="inline-edit-input" onchange="saveInlineEdit(${t.id}, 'status', this.value)" onblur="cancelInlineEdit(event)" onclick="event.stopPropagation()">
                                    <option value="未対応" ${t.status==='未対応'?'selected':''}>未対応</option>
                                    <option value="処理中" ${t.status==='処理中'?'selected':''}>処理中</option>
                                    <option value="完了" ${t.status==='完了'?'selected':''}>完了</option>
                                </select>
                            </div>
                        </div>
                    </td>
                <td style="font-weight: 500; cursor:pointer;" onclick="openModalById(${t.id})">${getBadgesHtml(t.id)}${t.subtasks_total > 0 ? `<span style='font-size:0.8rem; color:var(--text-secondary); background:rgba(255,255,255,0.1); padding:2px 4px; border-radius:4px; margin-right:4px;'>&#9745; ${t.subtasks_completed}/${t.subtasks_total}</span>` : ''}${t.title}</td>
                <td>${t.project_name || 'プロジェクト外業務'}</td>
                <td onclick="showAssigneePopup(event, ${t.id})">
                    <div class="inline-edit-trigger" style="display: flex; align-items: center; gap: 4px; flex-wrap: wrap; width: 100%; height: 100%;">
                        ${renderAssignees(t.assignees) || '<span style="color:#aaa;">未設定</span>'}
                    </div>
                </td>
                <td onclick="startInlineEdit(event, ${t.id}, 'start_date')">
                    <div class="inline-text inline-edit-trigger">${t.start_date || '<span style="color:#aaa;">未設定</span>'}</div>
                    <div class="inline-input" style="display:none;">
                        <input type="date" class="inline-edit-input" value="${t.start_date||''}" onchange="saveInlineEdit(${t.id}, 'start_date', this.value)" onblur="cancelInlineEdit(event)" onclick="event.stopPropagation()">
                    </div>
                </td>
                <td onclick="startInlineEdit(event, ${t.id}, 'due_date')">
                    <div class="inline-text inline-edit-trigger">${t.due_date || '<span style="color:#aaa;">未設定</span>'}</div>
                    <div class="inline-input" style="display:none;">
                        <input type="date" class="inline-edit-input" value="${t.due_date||''}" onchange="saveInlineEdit(${t.id}, 'due_date', this.value)" onblur="cancelInlineEdit(event)" onclick="event.stopPropagation()">
                    </div>
                </td>

                <td onclick="startInlineEdit(event, ${t.id}, 'task_type')">
                    <div class="inline-text inline-edit-trigger">
                        <span class="badge ${typeClass}">${t.task_type}</span>
                    </div>
                    <div class="inline-input" style="display:none;">
                        <select class="inline-edit-input" onchange="saveInlineEdit(${t.id}, 'task_type', this.value)" onblur="cancelInlineEdit(event)" onclick="event.stopPropagation()">
                            <option value="HELP！" ${t.task_type==='HELP！'?'selected':''}>HELP！</option>
                            <option value="大（数日以上）" ${t.task_type==='大（数日以上）'?'selected':''}>大（数日以上）</option>
                            <option value="中（数時間）" ${t.task_type==='中（数時間）'?'selected':''}>中（数時間）</option>
                            <option value="小（すぐ終わる）" ${t.task_type==='小（すぐ終わる）'?'selected':''}>小（すぐ終わる）</option>
                        </select>
                    </div>
                </td>
                <td class="crud-actions"><button class="btn-secondary btn-sm" onclick="copyTask(${t.id})">コピー</button></td>
            `;
            
            // Remove the tr.onclick because inline edit needs to handle clicks
            tr.onclick = null;
            tr.style.cursor = 'default';
            
            // Add double click to open modal? Or click title
            Array.from(tr.cells).forEach((cell, idx) => {
                if(idx === 1) { // title cell
                    cell.style.cursor = 'pointer';
                    cell.onclick = (e) => { e.stopPropagation(); openModal(t); };
                }
            });
            /* removed global row click */
            listBody.appendChild(tr);
        });
    });
    initSortable();
}

// ---- Kanban View ----
function renderKanban() {
    const board = document.getElementById('kanbanBoard');
    if (!board) return;

    const kanbanSort = document.getElementById('kanbanSort');
    const sortVal = kanbanSort ? kanbanSort.value : 'default';
    let filtered = getFilteredTasks(false);

    if (sortVal === 'date_asc') {
        filtered.sort((a, b) => new Date(a.due_date || '9999-12-31') - new Date(b.due_date || '9999-12-31'));
    } else if (sortVal === 'date_desc') {
        filtered.sort((a, b) => new Date(b.due_date || '1970-01-01') - new Date(a.due_date || '1970-01-01'));
    } else if (sortVal === 'project') {
        filtered.sort((a, b) => (a.project_name || '').localeCompare(b.project_name || ''));
    }

    board.innerHTML = '';

    const categoriesMap = new Map();
    categoriesMap.set('null', { name: '(分類なし)', tasks: [] });
    businessCategories.forEach(bc => {
        categoriesMap.set(String(bc.id), { name: bc.name, tasks: [] });
    });

    filtered.forEach(t => {
        let bcId = null;
        if (t.project_id) {
            const p = projects.find(pr => pr.id == t.project_id);
            if (p && p.business_category_id) {
                bcId = String(p.business_category_id);
            }
        }
        if (!bcId && t.business_category_id) {
            bcId = String(t.business_category_id);
        }
        if (!bcId) bcId = 'null';
        if (categoriesMap.has(bcId)) {
            categoriesMap.get(bcId).tasks.push(t);
        } else {
            categoriesMap.get('null').tasks.push(t);
        }
    });

    board.innerHTML = '';

    categoriesMap.forEach((catData, catId) => {
        if (catData.tasks.length === 0) return;

        const catContainer = document.createElement('div');
        catContainer.className = 'kanban-category-container';
        catContainer.style.display = 'flex';
        catContainer.style.flexDirection = 'column';
        
        const catHeader = document.createElement('div');
        catHeader.style.padding = '8px 16px';
        catHeader.style.marginBottom = '16px';
        catHeader.style.background = 'rgba(255,255,255,0.08)';
        catHeader.style.borderBottom = '2px solid var(--border-color)';
        catHeader.style.borderRadius = '4px';
        catHeader.innerHTML = `<h3 style="margin:0; font-size:1.1rem;"><i class="fas fa-layer-group"></i> 業務分類: ${catData.name}</h3>`;
        catContainer.appendChild(catHeader);

        const lanesContainer = document.createElement('div');
        lanesContainer.style.display = 'flex';
        lanesContainer.style.gap = '24px';
        lanesContainer.style.overflowX = 'auto';
        lanesContainer.style.paddingBottom = '8px';
        lanesContainer.style.minHeight = '300px';

        statuses.forEach(s => {
            const col = document.createElement('div');
            col.className = 'kanban-column drop-zone';
            col.dataset.status = s.name;
            col.dataset.id = s.id;
            col.draggable = true; // For column reordering

            // Column drag events
            col.ondragstart = (e) => {
                if (e.target === col) {
                    e.dataTransfer.setData('colId', s.id);
                    e.stopPropagation();
                }
            };
            col.ondragover = (e) => {
                e.preventDefault(); // Allow drop
            };
            col.ondrop = async (e) => {
                const colId = e.dataTransfer.getData('colId');
                const taskId = e.dataTransfer.getData('taskId');
                if (colId && colId != s.id) {
                    e.stopPropagation();
                    // Reorder columns
                    const draggedIdx = statuses.findIndex(st => st.id == colId);
                    const dropIdx = statuses.findIndex(st => st.id == s.id);
                    if (draggedIdx > -1 && dropIdx > -1) {
                        const item = statuses.splice(draggedIdx, 1)[0];
                        statuses.splice(dropIdx, 0, item);
                        // Update order indices
                        const updateData = statuses.map((st, idx) => ({id: st.id, order_index: idx}));
                        await fetch(`${API_BASE}/statuses/reorder`, {
                            method: 'PUT',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify(updateData)
                        });
                        await fetchData();
                        renderKanban();
                    }
                } else if (taskId) {
                    e.stopPropagation();
                    const task = tasks.find(t => t.id == taskId);
                    if (task && task.status !== s.name) {
                        task.status = s.name;
                        await fetch(`${API_BASE}/tasks/${taskId}`, {
                            method: 'PUT',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({status: s.name, user_id: currentUserId})
                        });
                        await fetchData();
                        renderKanban();
                    }
                }
            };

            const colTasks = catData.tasks.filter(t => t.status === s.name);
            
            let headerHtml = `
                <div class="kanban-col-header" style="cursor: grab; display: flex; align-items: center; gap: 12px; padding: 16px 16px 24px 16px; border-bottom: 1px solid var(--border-color);">
                    <h3 style="margin: 0; font-size: 1.1rem; font-weight: 600; color: var(--text-primary);">${s.name}</h3>
                    <span class="count" style="background: var(--bg-primary); color: var(--text-secondary); padding: 2px 10px; border-radius: 12px; font-size: 0.85rem; font-weight: 600;">${colTasks.length}</span>
                </div>
            `;
            col.innerHTML = headerHtml;

            const cardsContainer = document.createElement('div');
            cardsContainer.className = 'kanban-cards';
            
            // Task Drop events for this column
            cardsContainer.ondragover = (e) => e.preventDefault();
            cardsContainer.ondrop = async (e) => {
                const taskId = e.dataTransfer.getData('taskId');
                if (taskId) { e.stopPropagation(); }
                if (taskId) {
                    const task = tasks.find(t => t.id == taskId);
                    if (task && task.status !== s.name) {
                        task.status = s.name;
                        await fetch(`${API_BASE}/tasks/${taskId}`, {
                            method: 'PUT',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({status: s.name, user_id: currentUserId})
                        });
                        await fetchData();
                        renderKanban();
                    }
                }
            };

            colTasks.forEach(t => {
                let typeClass = 'type-routine';
                if(t.task_type === 'HELP！') typeClass = 'type-sudden';
                if(t.task_type === '大（数日以上）') typeClass = 'type-long';

                const card = document.createElement('div');
                card.className = 'task-card';
                card.draggable = true;
                card.style.cursor = 'pointer';
                
                // Task Drag events
                card.ondragstart = (e) => {
                    e.dataTransfer.setData('taskId', t.id);
                    e.stopPropagation();
                };
                card.onclick = (e) => {
                    openModal(t);
                };

                card.innerHTML = `
                    <div style="display:flex; justify-content:space-between; align-items:start; margin-bottom: 8px;">
                        <span class="task-project-badge">${t.project_name || '未設定'}</span>
                        <span class="badge ${typeClass}">${t.task_type}</span>
                    </div>
                    <div class="task-title" style="display: flex; align-items: flex-start; line-height: 1.4;">${getBadgesHtml(t.id)}${t.subtasks_total > 0 ? `<span style='font-size:0.8rem; color:var(--text-secondary); background:rgba(255,255,255,0.1); padding:2px 4px; border-radius:4px; margin-right:4px;'>&#9745; ${t.subtasks_completed}/${t.subtasks_total}</span>` : ''}${t.title}</div>
                    <div class="card-meta">
                        <span>${renderAssignees(t.assignees)}</span>
                        <span>${t.due_date ? t.due_date.slice(5) : '-'}</span>
                    </div>
                `;
                cardsContainer.appendChild(card);
            });

            col.appendChild(cardsContainer);
            lanesContainer.appendChild(col);
        });

        catContainer.appendChild(lanesContainer);
        board.appendChild(catContainer);
    });
}

// ---- Priority Map View (緊急度 x 重要度) ----
const PRIORITY_MAP_TYPE_COLORS = {
    'HELP！': '#ef4444',
    '大（数日以上）': '#f97316',
    '中（数時間）': '#eab308',
    '小（すぐ終わる）': '#22c55e'
};

function closePriorityMapPicker() {
    const existing = document.querySelector('.priority-map-picker');
    if (existing) existing.remove();
}

function renderPriorityMap() {
    const container = document.getElementById('priorityMapContainer');
    if (!container) return;
    closePriorityMapPicker();
    container.innerHTML = '';

    // Quadrant backgrounds (top-left=important/not urgent, top-right=important/urgent,
    // bottom-left=neither, bottom-right=urgent/not important) - classic Eisenhower coloring.
    const quadrants = [
        { top: '0', left: '0', bg: '#fef9c3' },   // yellow: important, not urgent
        { top: '0', left: '50%', bg: '#fecaca' }, // red: important, urgent
        { top: '50%', left: '0', bg: '#dcfce7' }, // green: not important, not urgent
        { top: '50%', left: '50%', bg: '#fed7aa' } // orange: not important, urgent
    ];
    quadrants.forEach(q => {
        const div = document.createElement('div');
        div.className = 'priority-map-quadrant';
        div.style.top = q.top;
        div.style.left = q.left;
        div.style.background = q.bg;
        container.appendChild(div);
    });

    // Axis divider lines + labels
    const vLine = document.createElement('div');
    vLine.style.cssText = 'position:absolute; left:50%; top:0; bottom:0; width:1px; background:rgba(0,0,0,0.35); border-left:1px dashed rgba(0,0,0,0.35);';
    container.appendChild(vLine);
    const hLine = document.createElement('div');
    hLine.style.cssText = 'position:absolute; top:50%; left:0; right:0; height:1px; background:rgba(0,0,0,0.35); border-top:1px dashed rgba(0,0,0,0.35);';
    container.appendChild(hLine);

    const labels = [
        { text: '重要度 高', top: '4px', left: '50%', translate: '-50%, 0' },
        { text: '重要度 低', bottom: '4px', left: '50%', translate: '-50%, 0' },
        { text: '緊急度 低 (期日まで2週間以上)', top: '50%', left: '8px', translate: '0, -50%' },
        { text: '緊急度 高 (本日期限/超過)', top: '50%', right: '8px', translate: '0, -50%' }
    ];
    labels.forEach(l => {
        const div = document.createElement('div');
        div.textContent = l.text;
        div.style.cssText = `position:absolute; font-size:11px; font-weight:600; color:#475569; background:rgba(255,255,255,0.75); padding:2px 6px; border-radius:4px; white-space:nowrap; z-index:1;`;
        if (l.top) div.style.top = l.top;
        if (l.bottom) div.style.bottom = l.bottom;
        if (l.left) div.style.left = l.left;
        if (l.right) div.style.right = l.right;
        div.style.transform = `translate(${l.translate})`;
        container.appendChild(div);
    });

    // Collect positioned tasks (期日未設定のタスクは対象外)
    const todayStr = new Date().toISOString().split('T')[0];
    const today = new Date(todayStr + 'T00:00:00');
    const filtered = getFilteredTasks(true);
    const positioned = [];
    filtered.forEach(t => {
        if (!t.due_date) return;
        const due = new Date(t.due_date + 'T00:00:00');
        const daysUntil = Math.round((due - today) / 86400000);
        const clampedDays = Math.max(0, Math.min(14, daysUntil)); // >14日先や超過分はそれぞれ左右端に丸める
        const xPct = ((14 - clampedDays) / 14) * 100;
        const importance = (t.importance != null) ? t.importance : 50;
        const yPct = 100 - importance;
        positioned.push({ task: t, xPct, yPct });
    });

    // Cluster tasks whose positions are close enough to overlap visually
    const clusters = [];
    const CLUSTER_THRESHOLD = 4; // % in both axes
    positioned.forEach(p => {
        let cluster = clusters.find(c => Math.abs(c.avgX - p.xPct) < CLUSTER_THRESHOLD && Math.abs(c.avgY - p.yPct) < CLUSTER_THRESHOLD);
        if (!cluster) {
            cluster = { items: [], avgX: p.xPct, avgY: p.yPct };
            clusters.push(cluster);
        }
        cluster.items.push(p);
        cluster.avgX = cluster.items.reduce((s, it) => s + it.xPct, 0) / cluster.items.length;
        cluster.avgY = cluster.items.reduce((s, it) => s + it.yPct, 0) / cluster.items.length;
    });

    // Markers/labels have real width & height, so plotting them at raw 0%/100%
    // gets half-clipped by the container edge. Inset the usable plot area by a
    // safety margin (H_PAD/V_PAD) while keeping the 0-100% axis meaning intact.
    const H_PAD = 72, V_PAD = 36;
    clusters.forEach(cluster => {
        const marker = document.createElement('div');
        marker.className = 'priority-map-marker';
        marker.style.left = `calc(${H_PAD}px + (100% - ${H_PAD * 2}px) * ${cluster.avgX / 100})`;
        marker.style.top = `calc(${V_PAD}px + (100% - ${V_PAD * 2}px) * ${cluster.avgY / 100})`;

        if (cluster.items.length === 1) {
            const t = cluster.items[0].task;
            const color = PRIORITY_MAP_TYPE_COLORS[t.task_type] || '#334155';
            marker.innerHTML = `
                <span class="pm-star" style="color:${color};">★</span>
                <span class="pm-label" style="color:${color};">${t.title}</span>
            `;
            marker.onclick = (e) => { e.stopPropagation(); closePriorityMapPicker(); window.openModalById(t.id); };
        } else {
            marker.innerHTML = `
                <span class="pm-star" style="color:#334155; position:relative;">★<span class="pm-count">${cluster.items.length}</span></span>
                <span class="pm-label" style="color:#334155;">${cluster.items.length}件のタスク</span>
            `;
            marker.onclick = (e) => {
                e.stopPropagation();
                closePriorityMapPicker();
                const picker = document.createElement('div');
                picker.className = 'priority-map-picker';
                // Anchor to the marker's actual rendered position (post H_PAD/V_PAD
                // inset), not the raw axis %, so the picker never clips either.
                picker.style.left = `${marker.offsetLeft}px`;
                picker.style.top = `${marker.offsetTop}px`;
                picker.style.transform = cluster.avgX > 60 ? 'translate(-100%, 8px)' : 'translate(0, 8px)';
                cluster.items
                    .slice()
                    .sort((a, b) => a.task.title.localeCompare(b.task.title))
                    .forEach(it => {
                        const t = it.task;
                        const color = PRIORITY_MAP_TYPE_COLORS[t.task_type] || '#334155';
                        const item = document.createElement('div');
                        item.className = 'priority-map-picker-item';
                        item.style.color = color;
                        item.textContent = `★ ${t.title}`;
                        item.onclick = (ev) => { ev.stopPropagation(); closePriorityMapPicker(); window.openModalById(t.id); };
                        picker.appendChild(item);
                    });
                container.appendChild(picker);
            };
        }
        container.appendChild(marker);
    });
}
document.addEventListener('click', (e) => {
    if (!e.target.closest('.priority-map-picker') && !e.target.closest('.priority-map-marker')) {
        closePriorityMapPicker();
    }
});

// ---- Gantt View ----
function renderGantt() {
    const container = document.getElementById('ganttContainer'); if(!container) return;
    container.innerHTML = '';
    
    const scaleSelect = document.getElementById('ganttScaleSelect');
    const scale = scaleSelect ? scaleSelect.value : 'day';

    const ganttTasks = getFilteredTasks(false).filter(t => t.start_date && t.due_date);
    if(ganttTasks.length === 0) {
        container.innerHTML = '<p style="color:#6b7280;">期間が設定されているタスクがありません。</p>';
        return;
    }

    let minDate = new Date(ganttTasks[0].start_date);
    let maxDate = new Date(ganttTasks[0].due_date);
    ganttTasks.forEach(t => {
        const s = new Date(t.start_date);
        const d = new Date(t.due_date);
        if(s < minDate) minDate = s;
        if(d > maxDate) maxDate = d;
    });

    minDate.setDate(minDate.getDate() - 3);
    maxDate.setDate(maxDate.getDate() + 14);

    let columns = [];
    
    if (scale === 'day') {
        let curr = new Date(minDate);
        while (curr <= maxDate) {
            const yyyy = curr.getFullYear();
            const mm = String(curr.getMonth() + 1).padStart(2, '0');
            const dd = String(curr.getDate()).padStart(2, '0');
            const dateStr = `${yyyy}-${mm}-${dd}`;
            const daysStr = ["日", "月", "火", "水", "木", "金", "土"];
            const dow = daysStr[curr.getDay()];
            columns.push({
                date: new Date(curr),
                label: curr.getDate().toString() + '<br>(' + dow + ')',
                monthLabel: (curr.getMonth() + 1) + '/' + curr.getDate() + '<br>(' + dow + ')',
                isWeekend: curr.getDay() === 0 || curr.getDay() === 6,
                isHoliday: holidays.includes(dateStr)
            });
            curr.setDate(curr.getDate() + 1);
        }
    } else if (scale === 'week') {
        let curr = new Date(minDate);
        let day = curr.getDay();
        let diff = curr.getDate() - day + (day == 0 ? -6 : 1); // Monday start
        curr.setDate(diff);
        
        while (curr <= maxDate) {
            let weekEnd = new Date(curr);
            weekEnd.setDate(curr.getDate() + 6);
            columns.push({
                date: new Date(curr),
                endDate: new Date(weekEnd),
                label: (curr.getMonth()+1) + '/' + curr.getDate() + ' - ' + (weekEnd.getMonth()+1) + '/' + weekEnd.getDate(),
                isWeekend: false, isHoliday: false
            });
            curr.setDate(curr.getDate() + 7);
        }
    } else if (scale === 'month') {
        let curr = new Date(minDate.getFullYear(), minDate.getMonth(), 1);
        while (curr <= maxDate) {
            let nextMonth = new Date(curr.getFullYear(), curr.getMonth() + 1, 1);
            let monthEnd = new Date(nextMonth.getTime() - 1);
            columns.push({
                date: new Date(curr),
                endDate: monthEnd,
                label: curr.getFullYear() + '年' + (curr.getMonth() + 1) + '月',
                isWeekend: false, isHoliday: false
            });
            curr = nextMonth;
        }
    }

    const totalCols = columns.length;
    let html = `<div class="gantt-grid" style="display:grid; grid-template-columns: 240px repeat(${totalCols}, ${scale==='day'?'50px':'minmax(120px, 1fr)'}); min-width: max-content;">`;

    html += `<div class="gantt-cell" style="grid-column: 1; grid-row: 1; background:#f8fafc; font-weight:bold; position:sticky; left:0; z-index:100;">タスク名</div>`;
    columns.forEach((col, idx) => {
        let bg = col.isWeekend ? '#f1f5f9' : '#f8fafc';
        if (col.isHoliday) bg = '#e2e8f0';
        let color = col.isWeekend ? '#ef4444' : 'var(--text-secondary)';
        if (col.date.getDay() === 6) color = '#3b82f6';
        if (col.isHoliday) color = '#ef4444';
        
        html += `<div class="gantt-cell" style="grid-column: ${idx + 2}; grid-row: 1; background:${bg}; color:${color}; font-size:11px; font-weight:bold; text-align:center; padding: 4px 2px; display:flex; flex-direction:column; justify-content:center; align-items:center;">${scale==='day'?col.monthLabel:col.label}</div>`;
    });

    const categoriesMap = new Map();
    categoriesMap.set('null', { name: '(分類なし)', projectsMap: {} });
    businessCategories.forEach(bc => {
        categoriesMap.set(String(bc.id), { name: bc.name, projectsMap: {} });
    });

    ganttTasks.forEach(t => {
        let bcId = null;
        if (t.project_id) {
            const p = projects.find(pr => pr.id == t.project_id);
            if (p && p.business_category_id) {
                bcId = String(p.business_category_id);
            }
        }
        if (!bcId && t.business_category_id) {
            bcId = String(t.business_category_id);
        }
        if (!bcId) bcId = 'null';
        
        let targetMap;
        if (categoriesMap.has(bcId)) {
            targetMap = categoriesMap.get(bcId).projectsMap;
        } else {
            targetMap = categoriesMap.get('null').projectsMap;
        }

        const pName = t.project_name || '未設定';
        if(!targetMap[pName]) targetMap[pName] = [];
        targetMap[pName].push(t);
    });

    let currentRow = 2;

    categoriesMap.forEach((catData, catId) => {
        if (Object.keys(catData.projectsMap).length === 0) return;

        // Render Category Header
        html += `<div class="gantt-cell" style="grid-column: 1; grid-row: ${currentRow}; background:rgba(255,255,255,0.08); font-weight:bold; position:sticky; left:0; text-align:left; padding:12px 16px; font-size:1.05rem; z-index:96; display:flex; align-items:center; border-bottom: 2px solid var(--border-color);"><i class="fas fa-layer-group" style="margin-right:8px;"></i> 業務分類: ${catData.name}</div>`;
        html += `<div class="gantt-cell" style="grid-column: 2 / -1; grid-row: ${currentRow}; background:rgba(255,255,255,0.08); border-bottom: 2px solid var(--border-color);"></div>`;
        currentRow++;

        Object.keys(catData.projectsMap).forEach(pName => {
            const todayStr = new Date().toISOString().split('T')[0];
            const pTasks = catData.projectsMap[pName];
            const urgentCount = pTasks.filter(t => t.due_date && t.due_date <= todayStr && t.status !== '完了').length;
            const urgentHtml = urgentCount > 0 ? `<span class="badge" style="background:#ef4444; color:white; font-size:10px; padding:2px 4px; margin-left:8px;">期限超過/本日迄: ${urgentCount}件</span>` : '';
            
            html += `<div class="gantt-cell" style="grid-column: 1; grid-row: ${currentRow}; background:#e2e8f0; font-weight:bold; position:sticky; left:0; text-align:left; padding-left:16px; z-index:95; display:flex; align-items:center;">${pName}${urgentHtml}</div>`;
            html += `<div class="gantt-cell" style="grid-column: 2 / -1; grid-row: ${currentRow}; background:#e2e8f0;"></div>`;
            currentRow++;

            catData.projectsMap[pName].forEach(t => {
                const startDate = new Date(t.start_date);
                startDate.setHours(0,0,0,0);
                const dueDate = new Date(t.due_date);
                dueDate.setHours(0,0,0,0);
                
                let startCol = -1;
                let endCol = -1;
                
                if (scale === 'day') {
                    startCol = columns.findIndex(c => c.date.getTime() >= startDate.getTime());
                    if(startCol === -1) startCol = 0;
                    let edIdx = columns.findIndex(c => c.date.getTime() > dueDate.getTime());
                    endCol = edIdx === -1 ? columns.length - 1 : edIdx - 1;
                } else if (scale === 'week' || scale === 'month') {
                    startCol = columns.findIndex(c => c.endDate.getTime() >= startDate.getTime());
                    if(startCol === -1) startCol = 0;
                    let edIdx = columns.findIndex(c => c.date.getTime() > dueDate.getTime());
                    endCol = edIdx === -1 ? columns.length - 1 : edIdx - 1;
                }
                
                html += `<div class="gantt-task-name gantt-cell" style="grid-column: 1; grid-row: ${currentRow}; padding-left:24px; background:#ffffff; position:sticky; left:0; z-index:90;" onclick="openModalById(${t.id})">${t.subtasks_total > 0 ? `<span style='font-size:0.8rem; color:var(--text-secondary); background:rgba(255,255,255,0.1); padding:2px 4px; border-radius:4px; margin-right:4px;'>&#9745; ${t.subtasks_completed}/${t.subtasks_total}</span>` : ''}${t.title}</div>`;
                
                columns.forEach((col, idx) => {
                    let bg = col.isWeekend ? '#f8fafc' : '#ffffff';
                    if (col.isHoliday) bg = '#f1f5f9';
                    html += `<div class="gantt-cell" style="grid-column: ${idx + 2}; grid-row: ${currentRow}; background:${bg}; border-right:1px solid #e2e8f0; border-bottom:1px solid #e2e8f0;"></div>`;
                });

                if (startCol !== -1 && endCol !== -1 && startCol <= endCol) {
                    const duration = endCol - startCol + 1;
                    html += `<div class="gantt-bar" style="grid-column: ${startCol + 2} / span ${duration}; grid-row: ${currentRow}; align-self:center;" onclick="openModalById(${t.id})">${getBadgesHtml(t.id)}${renderAssignees(t.assignees)}</div>`;
                }
                currentRow++;
            });
        });
    });

    html += `</div>`;
    container.innerHTML = html;
}

// ---- Task API Actions ----
async function createTask(data) {
    if (!data.user_id) data.user_id = currentUserId;
    await fetch(`${API_BASE}/tasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });
    await fetchNotifications();
}

async function updateTaskStatus(taskId, status) {
    await fetch(`${API_BASE}/tasks/${taskId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, user_id: currentUserId })
    });
    await fetchData();
    renderAllViews();
    if(currentOpenTaskId == taskId) {
        // sync modal
        modalStatus.value = status;
    }
}

async function addComment(taskId, content, mentions = []) {
    const res = await fetch(`${API_BASE}/tasks/${taskId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: currentUserId, content, mentions, chat_type: window.currentChatTab })
    });
    const comment = await res.json();
    appendCommentToModal(comment);
    await fetchNotifications();
}

// ---- Notifications API ----
window.renderAssignees = function(assignees) {
    if (!assignees || assignees.length === 0) return '<span>未設定</span>';
    const maxDisplay = 2;
    let html = '';
    const sorted = [...assignees].sort((a, b) => (a.order_index || 999) - (b.order_index || 999));
    sorted.slice(0, maxDisplay).forEach((a, i) => {
        if (a.role === 'main') {
            html += `<span class="assignee-tag" style="display:inline-block; background:var(--primary-color); color:white; padding:2px 6px; border-radius:4px; font-size:0.8rem; margin-right:4px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:100%;">主 ${a.name}</span>`;
        } else {
            html += `<span class="assignee-tag" style="display:inline-block; background:#e5e7eb; color:#475569; padding:2px 6px; border-radius:4px; font-size:0.8rem; margin-right:4px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:100%;">${a.role === 'sub' ? '副' : (i+1)} ${a.name}</span>`;
        }
    });
    if (sorted.length > maxDisplay) {
        html += `<span class="assignee-tag" style="display:inline-block; background:#e5e7eb; color:#475569; padding:2px 6px; border-radius:4px; font-size:0.8rem; white-space:nowrap;">+${sorted.length - maxDisplay}</span>`;
    }
    return html;
}

async function fetchNotifications() {
    try {
        const res = await fetch(`${API_BASE}/notifications/${currentUserId}`);
        const notifs = await res.json();
        
        const badge = document.getElementById('notifBadge');
        const list = document.getElementById('notifList');
        list.innerHTML = '';
        
        const unread = notifs.filter(n => !n.is_read);
        if(unread.length > 0) {
            badge.style.display = 'inline-block';
            badge.textContent = unread.length;
        } else {
            badge.style.display = 'none';
        }
        
        if(notifs.length === 0) {
            list.innerHTML = '<div style="padding:12px; color:var(--text-secondary); text-align:center;">通知はありません</div>';
            return;
        }
        
        notifs.forEach(n => {
            const div = document.createElement('div');
            div.className = `notif-item ${n.is_read ? '' : 'unread'}`;
            const d = new Date(n.created_at);
            const timeStr = `${d.getMonth()+1}/${d.getDate()} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
            const isComment = n.message.includes('コメント');
            
            if (isComment) {
                div.innerHTML = `
                    <div class="notif-text">${n.message}</div>
                    <div class="notif-time">${timeStr}</div>
                `;
                div.style.cursor = 'pointer';
                div.addEventListener('click', async () => {
                    if(!n.is_read) {
                        await fetch(`${API_BASE}/notifications/${n.id}/read`, { method: 'PUT' });
                        n.is_read = 1;
                        div.classList.remove('unread');
                        await fetchNotifications();
                    }
                    if (n.task_id) {
                        openModalById(n.task_id);
                        const notifDropdown = document.getElementById('notifDropdown');
                        if(notifDropdown) notifDropdown.classList.remove('show');
                    }
                });
            } else {
                div.innerHTML = `
                    <div class="notif-text">${n.message}</div>
                    <div class="notif-time">${timeStr}</div>
                    ${!n.is_read ? `
                    <div style="margin-top: 8px; display: flex; gap: 8px; justify-content: flex-end;">
                        <button class="btn-secondary btn-sm notif-later-btn" style="padding: 4px 8px; font-size: 11px;">後で確認</button>
                        <button class="btn-primary btn-sm notif-read-btn" style="padding: 4px 8px; font-size: 11px;">確認した</button>
                    </div>
                    ` : ''}
                `;
                div.style.cursor = 'default';
                
                const laterBtn = div.querySelector('.notif-later-btn');
                const readBtn = div.querySelector('.notif-read-btn');
                
                if (laterBtn) {
                    laterBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        const notifDropdown = document.getElementById('notifDropdown');
                        if(notifDropdown) notifDropdown.classList.remove('show');
                    });
                }
                if (readBtn) {
                    readBtn.addEventListener('click', async (e) => {
                        e.stopPropagation();
                        await fetch(`${API_BASE}/notifications/${n.id}/read`, { method: 'PUT' });
                        n.is_read = 1;
                        div.classList.remove('unread');
                        const btns = div.querySelector('div[style*="margin-top: 8px"]');
                        if (btns) btns.remove();
                        await fetchNotifications();
                    });
                }
            }
            list.appendChild(div);
        });
        const oldNotifsStr = JSON.stringify(allNotifications);
        allNotifications = notifs;
        if (oldNotifsStr !== JSON.stringify(allNotifications)) {
            updateBadgesUI();
        }
        
    } catch(err) {
        console.error(err);
    }
}

// ---- Modal ----
window.openModalById = function(id) {
    const t = tasks.find(x => x.id == id);
    if(t) {
        openModal(t);
    } else {
        alert('対象のタスクが見つかりません。既に削除された可能性があります。');
    }
}

async function openModal(task) {
    currentOpenTaskId = task.id;
    document.getElementById('modalProject').textContent = task.project_name || 'No Project';
    document.getElementById('modalTitle').textContent = task.title;
    document.getElementById('modalAssignee').innerHTML = renderAssignees(task.assignees);
    document.getElementById('modalDates').textContent = `${task.start_date || '-'} ~ ${task.due_date || '-'}`;
    document.getElementById('modalDesc').textContent = task.description || '詳細はありません。';
    modalStatus.value = task.status;
    document.getElementById('modalProgressMemo').value = task.progress_memo || '';
    const progressVerbatimEl = document.getElementById('modalProgressMemoVerbatim');
    if (progressVerbatimEl) progressVerbatimEl.checked = !!task.progress_memo_verbatim;
    
    const typeBadge = document.getElementById('modalType');
    typeBadge.textContent = task.task_type;
    typeBadge.className = 'value badge ' + (task.task_type === '突発' ? 'type-sudden' : task.task_type === '長期プロジェクト' ? 'type-long' : 'type-routine');

    window.copyToClipboard = function(text) {
    navigator.clipboard.writeText(text).then(() => {
        const toast = document.createElement('div');
        toast.textContent = 'コピーしました';
        toast.style.position = 'fixed';
        toast.style.bottom = '20px';
        toast.style.left = '50%';
        toast.style.transform = 'translateX(-50%)';
        toast.style.background = 'rgba(0,0,0,0.7)';
        toast.style.color = 'white';
        toast.style.padding = '8px 16px';
        toast.style.borderRadius = '20px';
        toast.style.zIndex = '9999';
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 2000);
    });
};

window.deleteAttachment = async function(attId) {
    if (!confirm('この添付ファイルを削除しますか？')) return;
    try {
        const res = await fetch(`${API_BASE}/tasks/${currentOpenTaskId}/attachments/${attId}`, {
            method: 'DELETE'
        });
        if (res.ok) {
            // Remove from UI
            const item = document.getElementById(`att-item-${attId}`);
            if (item) item.remove();
        }
    } catch (err) {
        console.error(err);
    }
};

    modal.classList.add('show');
    if(typeof loadSubtasks === 'function') loadSubtasks(task.id);

    // Load Comments
    fetch(`${API_BASE}/tasks/${task.id}/comments`).then(res => res.json()).then(comments => {
        const list = document.getElementById('commentsList');
        list.innerHTML = '';
        comments.filter(c => (c.chat_type || 'team') === window.currentChatTab).forEach(appendCommentToModal);
    }).catch(console.error);

    // Load Attachments
    fetch(`${API_BASE}/tasks/${task.id}/attachments`).then(res => res.json()).then(attachments => {
        const attList = document.getElementById('attachmentsList');
        attList.innerHTML = '';
        attachments.forEach(appendAttachmentToModal);
    }).catch(console.error);
    
    // Mark notifications as read for this task
    await fetch(`${API_BASE}/notifications/read_by_task/${task.id}/${currentUserId}`, { method: 'PUT' });
    await fetchNotifications(); // refresh badges
}

function appendAttachmentToModal(a) {
    const list = document.getElementById('attachmentsList');
    const div = document.createElement('div');
    div.className = 'attachment-item';
    div.id = `att-item-${a.id}`;
    div.style.display = 'flex';
    div.style.justifyContent = 'space-between';
    div.style.alignItems = 'center';
    
    const d = new Date(a.created_at);
    const timeStr = `${d.getMonth()+1}/${d.getDate()} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
    
    let contentHtml = '';
    if (a.is_link) {
        let folderPath = a.filepath.substring(0, Math.max(a.filepath.lastIndexOf('\\'), a.filepath.lastIndexOf('/')));
        contentHtml = `
            <div style="flex-grow:1;">
                <div><i class="fas fa-link" style="color:var(--text-tertiary);"></i> <span style="font-weight:500;">${a.filename}</span></div>
                <div style="font-size:0.8rem; color:var(--text-secondary); margin-bottom:4px;">${a.filepath}</div>
                <div>
                    <button class="btn-secondary btn-sm" onclick="copyToClipboard('${a.filepath.replace(/\\/g, '\\\\')}')" style="padding:2px 6px; font-size:0.75rem;">パスをコピー</button>
                    ${folderPath ? `<button class="btn-secondary btn-sm" onclick="copyToClipboard('${folderPath.replace(/\\/g, '\\\\')}')" style="padding:2px 6px; font-size:0.75rem;">フォルダパスをコピー</button>` : ''}
                </div>
                <div class="attachment-meta">${a.uploader_name || '誰か'} - ${timeStr}</div>
            </div>
            <div><button class="btn-danger btn-sm" onclick="deleteAttachment(${a.id})" style="padding:4px 8px;"><i class="fas fa-trash"></i></button></div>
        `;
    } else {
        contentHtml = `
            <div style="flex-grow:1;">
                <a href="${API_BASE}/attachments/${a.id}/download" target="_blank"><i class="fas fa-file"></i> ${a.filename}</a>
                <div class="attachment-meta">${a.uploader_name || '誰か'} - ${timeStr}</div>
            </div>
            <div><button class="btn-danger btn-sm" onclick="deleteAttachment(${a.id})" style="padding:4px 8px;"><i class="fas fa-trash"></i></button></div>
        `;
    }
    
    div.innerHTML = contentHtml;
    list.appendChild(div);
}

function appendCommentToModal(c) {
    const list = document.getElementById('commentsList');
    const div = document.createElement('div');
    const isOwn = String(c.user_id) === String(currentUserId);
    div.className = `chat-message ${isOwn ? 'own-message' : ''}`;
    
    const d = new Date(c.created_at);
    const timeStr = `${d.getMonth()+1}/${d.getDate()} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
    const authorName = c.user_name || '名無し';
    const initial = authorName.substring(0, 2);
    const avatarHtml = c.user_avatar_url 
        ? `<img src="${c.user_avatar_url}" class="chat-avatar" style="object-fit:cover;">`
        : `<div class="chat-avatar">${initial}</div>`;
    
    // Group reactions
    const reactCounts = {};
    const myReacts = new Set();
    if (c.reactions) {
        c.reactions.forEach(r => {
            if (!reactCounts[r.emoji]) reactCounts[r.emoji] = 0;
            reactCounts[r.emoji]++;
            if (String(r.user_id) === String(currentUserId)) {
                myReacts.add(r.emoji);
            }
        });
    }

    let reactionsHtml = '<div class="reactions-container">';
    Object.keys(reactCounts).forEach(emoji => {
        const isMine = myReacts.has(emoji);
        reactionsHtml += `
            <div class="reaction-badge ${isMine ? 'active' : ''}" onclick="toggleReaction(${c.id}, '${emoji}')">
                ${emoji} <span class="reaction-count">${reactCounts[emoji]}</span>
            </div>
        `;
    });
    
    // Add reaction button
    reactionsHtml += `
        <div class="reaction-add-btn" onclick="openReactionPicker(event, ${c.id})">☺</div>
    </div>`;

    // Reads
    let readsHtml = '';
    if (c.reads && c.reads.length > 0) {
        // Exclude self from read count conceptually? No, LINEWORKS shows total read count
        readsHtml = `<div class="read-receipt" data-users="既読: ${c.reads.map(r=>r.user_name).join(', ')}"><i class="fas fa-eye"></i> ${c.reads.length}</div>`;
    } else {
        readsHtml = `<div class="read-receipt" data-users="未読" style="color:var(--text-tertiary);"><i class="fas fa-eye"></i> 0</div>`;
    }

    div.innerHTML = `
        ${avatarHtml}
        <div class="chat-bubble-wrapper">
            <div class="chat-author">${authorName}</div>
            <div class="chat-bubble">${c.content.replace(/\n/g, '<br>')}</div>
            ${reactionsHtml}
            <div class="chat-meta">
                <div class="chat-time">${timeStr}</div>
                ${readsHtml}
            </div>
        </div>
    `;
    list.appendChild(div);
    list.scrollTop = list.scrollHeight;
}

window.toggleReaction = async function(commentId, emoji) {
    await fetch(`${API_BASE}/comments/${commentId}/reactions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: currentUserId, emoji })
    });
    // refresh comments
    const t = tasks.find(x => x.id == currentOpenTaskId);
    if(t) {
        const resComments = await fetch(`${API_BASE}/tasks/${t.id}/comments`);
        const comments = await resComments.json();
        const list = document.getElementById('commentsList');
        list.innerHTML = '';
        comments.filter(c => (c.chat_type || 'team') === window.currentChatTab).forEach(appendCommentToModal);
    }
}

window.openReactionPicker = function(e, commentId) {
    e.stopPropagation();
    let picker = document.getElementById('reactionPicker');
    if (!picker) {
        picker = document.createElement('div');
        picker.id = 'reactionPicker';
        picker.className = 'glass-panel';
        document.body.appendChild(picker);
        
        // Hide on outside click
        if (document) document.addEventListener('click', (ev) => {
            if (!picker.contains(ev.target)) {
                picker.style.display = 'none';
            }
        });
    }
    
    picker.style.display = 'flex';
    const rect = e.target.getBoundingClientRect();
    picker.style.top = (rect.bottom + window.scrollY + 5) + 'px';
    picker.style.left = (rect.left + window.scrollX) + 'px';
    
    const defaultEmojis = ['👍', '💖', '😂', '😥', '👀', '🙏'];
    let html = '<div style="display:flex; gap:8px; margin-bottom:8px;">';
    defaultEmojis.forEach(emoji => {
        html += `<div class="picker-emoji" onclick="toggleReaction(${commentId}, '${emoji}'); document.getElementById('reactionPicker').style.display='none';">${emoji}</div>`;
    });
    html += '</div>';
    html += `
        <div style="display:flex; gap:4px;">
            <input type="text" id="customEmojiInput" class="input-field" placeholder="自由な絵文字..." style="width:100px; padding:4px 8px;">
            <button class="btn-primary btn-sm" onclick="
                const em = document.getElementById('customEmojiInput').value.trim();
                if(em) toggleReaction(${commentId}, em);
                document.getElementById('reactionPicker').style.display='none';
            ">追加</button>
        </div>
    `;
    picker.innerHTML = html;
}

function closeModal() {
    modal.classList.remove('show');
    currentOpenTaskId = null;
}

// Kickoff
init();

// Auto-poll notifications for real-time badges
setInterval(() => {
    if (currentUserId) {
        fetchNotifications();
    }
}, 3000);

let currentCommentsJson = '';
setInterval(async () => {
    if (currentOpenTaskId && document.getElementById('taskModal').classList.contains('show')) {
        try {
            const res = await fetch(`${API_BASE}/tasks/${currentOpenTaskId}/comments`);
            const comments = await res.json();
            const newJson = JSON.stringify(comments);
            if (newJson !== currentCommentsJson) {
                currentCommentsJson = newJson;
                const commentsList = document.getElementById('commentsList');
                if (commentsList) {
                    commentsList.innerHTML = '';
                    comments.forEach(c => appendCommentToModal(c));
                }
                currentCommentsJson = JSON.stringify(comments);
            }
        } catch(e) {}
    }
}, 3000);


// ---- Settings & Avatar Logic ----
document.addEventListener('DOMContentLoaded', () => {
    // Theme Switch
    const themeCheckbox = document.getElementById('themeToggleCheckbox');
    if (themeCheckbox) {
        themeCheckbox.checked = document.body.classList.contains('dark-mode');
        themeCheckbox.addEventListener('change', () => {
            document.body.classList.toggle('dark-mode');
    // localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        });
    }

    // Theme Slider
    const themeSlider = document.getElementById('themeSlider');
    const themePreviewBox = document.getElementById('themePreviewBox');
    if (themeSlider && themePreviewBox) {
        themeSlider.addEventListener('input', (e) => {
            const hue = e.target.value;
            themePreviewBox.style.backgroundColor = `hsl(${hue}, 70%, 50%)`;
            document.documentElement.style.setProperty('--primary-hue', hue);
        });
        themeSlider.addEventListener('change', (e) => {
            const hue = e.target.value;
    // localStorage.setItem('themeHue', hue);
        });
        // load hue (Logic moved to appConfig loader)
    }


    const avatarInput = document.getElementById('avatarUploadInput');
    if (avatarInput) {
        avatarInput.addEventListener('change', async (e) => {
            const targetId = userModalId;
            if (!targetId || !e.target.files[0]) return;
            const formData = new FormData();
            formData.append('file', e.target.files[0]);
            
            try {
                const res = await fetch(`${API_BASE}/users/${targetId}/avatar`, {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                if (data.success) {
                    await fetchData();
                    renderList();
                    renderMembers();
                    
                    const preview = document.getElementById('userModalAvatarPreview');
                    preview.innerHTML = `<img src="${data.avatar_url}" style="width:100%; height:100%; border-radius:50%; object-fit:cover;">`;
                    preview.style.background = 'transparent';
                    preview.style.border = 'none';
                    
                    if (targetId == currentUserId) {
                        checkLoginStatus();
                    }
                }
            } catch (err) { console.error(err); }
        });
    }

    const avatarDeleteBtn = document.getElementById('avatarDeleteBtn');
    if (avatarDeleteBtn) {
        avatarDeleteBtn.addEventListener('click', async () => {
            const targetId = userModalId;
            if (!targetId) return;
            if (!confirm('画像を削除しますか？')) return;
            
            try {
                const res = await fetch(`${API_BASE}/users/${targetId}/avatar`, {
                    method: 'DELETE'
                });
                const data = await res.json();
                if (data.success) {
                    await fetchData();
                    renderList();
                    renderMembers();
                    
                    const preview = document.getElementById('userModalAvatarPreview');
                    const val = document.getElementById('userModalName').value.trim();
                    preview.innerHTML = val ? val.substring(0, 2) : '-';
                    preview.style.background = 'var(--bg-surface)';
                    preview.style.border = '2px dashed var(--border-color)';
                    
                    if (targetId == currentUserId) {
                        checkLoginStatus();
                    }
                }
            } catch (err) { console.error(err); }
        });
    }

    // Kanban Statuses Setup
    const addStatusBtn = document.getElementById('addStatusBtn');
    if (addStatusBtn) {
        addStatusBtn.addEventListener('click', async () => {
            const name = document.getElementById('newStatusName').value.trim();
            if (!name) return;
            try {
                await fetch(`${API_BASE}/statuses`, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({name: name, order_index: statuses.length})
                });
                document.getElementById('newStatusName').value = '';
                await fetchData();
                renderSettingsStatuses();
                renderKanban();
    renderSettingsStatuses();
    populateTaskStatusDropdown();
                populateTaskStatusDropdown();
            } catch(e) {}
        });
    }
});

function renderSettingsStatuses() {
    const container = document.getElementById('settingsKanbanColumns');
    if (!container) return;
    container.innerHTML = '';
    statuses.forEach(st => {
        const div = document.createElement('div');
        div.style.display = 'flex';
        div.style.justifyContent = 'space-between';
        div.style.alignItems = 'center';
        div.style.background = 'var(--bg-main)';
        div.style.padding = '8px 12px';
        div.style.borderRadius = '4px';
        
        div.innerHTML = `
            <div>
                <span style="font-weight:bold;">${st.name}</span>
                ${st.is_completed ? '<span style="margin-left:8px; font-size:0.75rem; background:var(--primary); color:white; padding:2px 6px; border-radius:12px;">完了扱い</span>' : ''}
            </div>
            <div>
                <button class="btn-secondary" onclick="deleteStatus(${st.id}, ${st.is_completed})" style="color:var(--danger); border-color:var(--danger); padding:4px 8px;">削除</button>
            </div>
        `;
        container.appendChild(div);
    });
}

async function deleteStatus(id, is_completed) {
    if (is_completed) {
        alert('「完了」ステータスは削除できません。');
        return;
    }
    if (!confirm('このステータスを削除しますか？')) return;
    try {
        await fetch(`${API_BASE}/statuses/${id}`, { method: 'DELETE' });
        await fetchData();
        renderSettingsStatuses();
        renderKanban();
    renderSettingsStatuses();
    populateTaskStatusDropdown();
        populateTaskStatusDropdown();
    } catch(e) {}
}

function populateTaskStatusDropdown() {
    const selects = [document.getElementById('modalStatus'), document.getElementById('taskCreateStatus')];
    selects.forEach(select => {
        if (!select) return;
        const currentVal = select.value;
        select.innerHTML = '';
        statuses.forEach(st => {
            const opt = document.createElement('option');
            opt.value = st.name;
            opt.textContent = st.name;
            select.appendChild(opt);
        });
        if (currentVal) select.value = currentVal;
    });

    const filterStatus = document.getElementById('filterStatus');
    if (filterStatus) {
        const currentVal = filterStatus.value;
        filterStatus.innerHTML = '<option value="all">すべてのステータス</option>';
        statuses.forEach(st => {
            const opt = document.createElement('option');
            opt.value = st.name;
            opt.textContent = st.name;
            filterStatus.appendChild(opt);
        });
        if (currentVal) filterStatus.value = currentVal;
    }
}


document.addEventListener('DOMContentLoaded', () => {
    const addColBtn = document.getElementById('kanbanAddColBtn');
    if (addColBtn) {
        addColBtn.addEventListener('click', () => {
            const name = prompt('新しい領域（ステータス）の名前を入力:');
            if (name && name.trim()) {
                fetch(`${API_BASE}/statuses`, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ name: name.trim(), order_index: statuses.length })
                }).then(() => fetchData()).then(() => {
                    renderKanban();
                    populateTaskStatusDropdown();
                });
            }
        });
    }
    
    const kbSort = document.getElementById('kanbanSort');
    if (kbSort) {
        kbSort.addEventListener('change', renderKanban);
    }
});

window.currentPopupAssignees = [];

window.showAssigneePopup = function(e, taskId) {
    e.stopPropagation();
    const task = tasks.find(t => t.id === taskId);
    if(!task) return;
    
    let popup = document.getElementById('assigneeInlinePopup');
    if(popup) popup.remove();
    
    popup = document.createElement('div');
    popup.id = 'assigneeInlinePopup';
    popup.className = 'multi-select-popup';
    popup.style.width = '240px';
    
    const rect = e.currentTarget.getBoundingClientRect();
    const popupHeight = 250;
    const popupWidth = 240;
    
    let top = rect.bottom + window.scrollY;
    if (rect.bottom + popupHeight > window.innerHeight) {
        top = rect.top + window.scrollY - popupHeight;
        if (top < window.scrollY) top = window.scrollY + 10;
    }
    
    let left = rect.left + window.scrollX;
    if (rect.left + popupWidth > window.innerWidth) {
        left = window.innerWidth - popupWidth - 20 + window.scrollX;
    }
    
    popup.style.top = top + 'px';
    popup.style.left = left + 'px';
    
    window.currentPopupAssignees = task.assignees ? task.assignees.map(a => ({id: a.id, role: a.role || 'sub'})) : [];
    
    window.renderPopupAssigneeUI = function() {
        let html = `<div class="checkbox-list" style="max-height: 200px; overflow-y: auto;">`;
        users.forEach(u => {
            const idx = window.currentPopupAssignees.findIndex(a => parseInt(a.id) === parseInt(u.id));
            const role = idx !== -1 ? window.currentPopupAssignees[idx].role : null;
            const order = idx !== -1 ? idx + 1 : '';
            
            const mainStyle = role === 'main' ? 'background:var(--primary-color); color:white; border-color:var(--primary-color);' : 'background:white; color:#64748b; border-color:#cbd5e1;';
            const subStyle = role === 'sub' ? 'background:#64748b; color:white; border-color:#64748b;' : 'background:white; color:#64748b; border-color:#cbd5e1;';
            const mainText = role === 'main' ? order : '主';
            const subText = role === 'sub' ? order : '副';
            
            html += `
                <div class="assignee-select-row" style="display:flex; align-items:center; gap:8px; margin-bottom:8px;">
                    <div onclick="togglePopupAssigneeRole(${u.id}, 'main')" style="border:1px solid #cbd5e1; border-radius:4px; width:24px; height:24px; display:flex; align-items:center; justify-content:center; cursor:pointer; font-size:12px; user-select:none; ${mainStyle}">${mainText}</div>
                    <div onclick="togglePopupAssigneeRole(${u.id}, 'sub')" style="border:1px solid #cbd5e1; border-radius:4px; width:24px; height:24px; display:flex; align-items:center; justify-content:center; cursor:pointer; font-size:12px; user-select:none; ${subStyle}">${subText}</div>
                    <span style="font-size:14px;">${u.name}</span>
                </div>
            `;
        });
        html += `</div>
            <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:8px;">
                <button class="btn-secondary btn-sm" onclick="this.closest('.multi-select-popup').remove(); event.stopPropagation();">キャンセル</button>
                <button class="btn-primary btn-sm" onclick="saveInlineAssignees(event, ${taskId})">保存</button>
            </div>
        `;
        popup.innerHTML = html;
    };
    
    window.togglePopupAssigneeRole = function(userId, role) {
        const idx = window.currentPopupAssignees.findIndex(a => parseInt(a.id) === parseInt(userId));
        if (idx !== -1) {
            if (window.currentPopupAssignees[idx].role === role) {
                window.currentPopupAssignees.splice(idx, 1);
            } else {
                window.currentPopupAssignees[idx].role = role;
                const item = window.currentPopupAssignees.splice(idx, 1)[0];
                window.currentPopupAssignees.push(item);
            }
        } else {
            window.currentPopupAssignees.push({id: userId, role: role});
        }
        window.renderPopupAssigneeUI();
    };

    window.renderPopupAssigneeUI();
    document.body.appendChild(popup);
}

window.saveInlineAssignees = async function(e, taskId) {
    e.stopPropagation();
    const popup = document.getElementById('assigneeInlinePopup');
    if(!popup) return;
    
    const assigneesPayload = window.currentPopupAssignees.map((a, i) => ({
        user_id: a.id,
        role: a.role,
        order_index: i + 1
    }));
    
    const task = tasks.find(t => t.id === taskId);
    if(task) {
        const payload = {
            title: task.title,
            description: task.description,
            status: task.status,
            project_id: task.project_id,
            task_type: task.task_type,
            priority: task.priority,
            start_date: task.start_date,
            due_date: task.due_date,
            estimated_hours: task.estimated_hours,
            actual_hours: task.actual_hours,
            assignees: assigneesPayload,
            user_id: currentUserId
        };
        await fetch(`${API_BASE}/tasks/${taskId}`, { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
        await fetchData();
        renderAllViews();
    }
    popup.remove();
}

window.startInlineEdit = function(e, taskId, field) {
    e.stopPropagation();
    window.isEditingInline = true;
    const td = e.currentTarget;
    const trigger = td.querySelector('.inline-edit-trigger');
    const inputWrapper = td.querySelector('.inline-input');
    if(trigger && inputWrapper) {
        trigger.style.display = 'none';
        inputWrapper.style.display = 'block';
        const input = inputWrapper.querySelector('.inline-edit-input');
        if(input) {
            input.focus();
            if(input.tagName === 'INPUT') {
                setTimeout(()=>input.select(), 10);
            }
        }
    }
};

window.saveInlineEdit = async function(taskId, field, value) {
    window.isEditingInline = false;
    try {
        const payload = {};
        payload[field] = value;
        payload['user_id'] = currentUserId;
        const res = await fetch(`/api/tasks/${taskId}`, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        if(res.ok) {
            await fetchTasks();
            renderAllViews();
        } else {
            alert('Error updating field');
        }
    } catch(err) {
        console.error(err);
    }
};

window.cancelInlineEdit = function(e) {
    window.isEditingInline = false;
    const td = e.currentTarget.closest('td');
    const trigger = td.querySelector('.inline-edit-trigger');
    const inputWrapper = td.querySelector('.inline-input');
    if(trigger && inputWrapper) {
        trigger.style.display = 'block';
        inputWrapper.style.display = 'none';
    }
};


function initSortable() {
    const tbody = document.getElementById('tasksBody');
    if (tbody && !tbody.sortableInit) {
        tbody.sortableInit = true;
        Sortable.create(tbody, {
            animation: 150,
            handle: '.drag-handle',
            onChoose(e) { console.log('Task onChoose', e.oldIndex); },
            onStart(e) { console.log('Task onStart', e.oldIndex); },
            onMove(e) { console.log('Task onMove'); },
            onEnd: async function (evt) {
                console.log('Task onEnd', evt.oldIndex, '->', evt.newIndex);
                const trs = tbody.querySelectorAll('tr[data-task-id]');
                const taskIds = Array.from(trs).map(tr => tr.getAttribute('data-task-id'));
                await reorderTasks(taskIds);
            }
        });
    }

    const projectTbodies = document.querySelectorAll('.tasks-row table tbody');
    projectTbodies.forEach(tb => {
        if (!tb.sortableInit) {
            tb.sortableInit = true;
            Sortable.create(tb, {
                animation: 150,
                handle: '.drag-handle',
                onChoose(e) { console.log('NestedTask onChoose', e.oldIndex); },
                onStart(e) { console.log('NestedTask onStart', e.oldIndex); },
                onMove(e) { console.log('NestedTask onMove'); },
                onEnd: async function (evt) {
                    console.log('NestedTask onEnd', evt.oldIndex, '->', evt.newIndex);
                    const trs = tb.querySelectorAll('tr[data-task-id]');
                    const taskIds = Array.from(trs).map(tr => tr.getAttribute('data-task-id'));
                    await reorderTasks(taskIds);
                }
            });
        }
    });

    // Projects View
    const projectsTable = document.getElementById('projectsTable');
    if (projectsTable && !projectsTable.sortableInit) {
        projectsTable.sortableInit = true;
        Sortable.create(projectsTable, {
            animation: 150,
            handle: '.project-row .drag-handle',
            forceFallback: true,
            fallbackOnBody: true,
            draggable: 'tbody.project-group',
            onChoose(e) { console.log('Proj onChoose', e.oldIndex); },
            onStart(e) { console.log('Proj onStart', e.oldIndex); },
            onMove(e) { console.log('Proj onMove'); },
            onEnd: async function (evt) {
                console.log('Proj onEnd', evt.oldIndex, '->', evt.newIndex);
                const groups = projectsTable.querySelectorAll('tbody.project-group[data-project-id]');
                const pIds = Array.from(groups).map(g => g.getAttribute('data-project-id'));
                await reorderProjects(pIds);
            }
        });
    }
}


window.reorderProjects = async function(pIds) {
    try {
        const res = await fetch('/api/projects/reorder', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({project_ids: pIds}) });
        if(res.ok) {
            await fetchData();
            renderAllViews();
        }
    } catch(err) { console.error(err); }
}

window.reorderTasks = async function(taskIds) {
    try {
        const res = await fetch('/api/tasks/reorder', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({task_ids: taskIds})
        });
        if(res.ok) {
            await fetchData();
            renderAllViews();
        }
    } catch (err) {
        console.error("Failed to reorder tasks", err);
    }
}

window.takeSnapshot = async function() {
    if(!confirm("現在の状態を「先週金曜のデータ」として保存しますか？\n※進捗比較の基準になります")) return;
    try {
        const res = await fetch('/api/tasks/snapshot', { method: 'POST' });
        if(res.ok) {
            alert("保存しました。");
            await fetchTasks();
            renderAllViews();
        } else {
            alert("エラーが発生しました。");
        }
    } catch(err) {
        console.error(err);
    }
};

// Completed Projects Logic
window.renderCompletedProjects = async function() {
    const table = document.getElementById('completedProjectsTable');
    if (!table) return;
    let tbody = table.querySelector('tbody');
    if (!tbody) {
        tbody = document.createElement('tbody');
        table.appendChild(tbody);
    }
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">読み込み中...</td></tr>';
    
    const startYear = document.getElementById('filterCompletedStartYear') ? document.getElementById('filterCompletedStartYear').value : '';
    const endYear = document.getElementById('filterCompletedEndYear') ? document.getElementById('filterCompletedEndYear').value : '';
    const ownerId = document.getElementById('filterCompletedOwner') ? document.getElementById('filterCompletedOwner').value : '';
    const keyword = document.getElementById('filterCompletedKeyword') ? document.getElementById('filterCompletedKeyword').value.toLowerCase() : '';
    
    try {
        const res = await fetch(`${API_BASE}/projects?status=completed`);
        if(res.ok) {
            let cp = await res.json();
            
            // Filter
            if (startYear) cp = cp.filter(p => p.start_date && p.start_date.substring(0,4) >= startYear);
            if (endYear) cp = cp.filter(p => p.due_date && p.due_date.substring(0,4) <= endYear);
            if (ownerId && ownerId !== 'all') cp = cp.filter(p => p.owner_id == ownerId);
            if (keyword) cp = cp.filter(p => (p.name && p.name.toLowerCase().includes(keyword)) || (p.description && p.description.toLowerCase().includes(keyword)));
            
            tbody.innerHTML = '';
            if (cp.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">該当するプロジェクトはありません</td></tr>';
            } else {
                cp.forEach(p => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${p.id}</td>
                        <td>${p.name}</td>
                        <td>${p.owner_name || '-'}</td>
                        <td>${p.start_date || '-'} ~ ${p.due_date || '-'}</td>
                        <td>${p.task_count || 0}</td>
                        <td class="crud-actions">
                            <button class="btn-primary btn-sm" onclick="openProjectModal('プロジェクト編集', ${p.id}, '${p.name}', '${p.description||''}', '${p.start_date||''}', '${p.due_date||''}', '${p.status||'進行中'}', '${p.owner_id||''}', '${p.business_category_id||''}')">編集</button>
                            <button class="btn-secondary btn-sm" onclick="duplicateProject(${p.id})">流用</button>
                            <button class="btn-danger btn-sm" onclick="deleteProject(${p.id})">削除</button>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            }
        }
    } catch(err) { console.error(err); }
}

window.populateCompletedFilters = function() {
    const sYear = document.getElementById('filterCompletedStartYear');
    const eYear = document.getElementById('filterCompletedEndYear');
    const owner = document.getElementById('filterCompletedOwner');
    if (!sYear || !eYear || !owner) return;
    
    if (sYear.options.length <= 1) {
        sYear.innerHTML = '<option value="">指定なし</option>';
        eYear.innerHTML = '<option value="">指定なし</option>';
        const currentYear = new Date().getFullYear();
        for (let y = currentYear - 5; y <= currentYear + 5; y++) {
            sYear.innerHTML += `<option value="${y}">${y}年</option>`;
            eYear.innerHTML += `<option value="${y}">${y}年</option>`;
        }
    }
    
    if (owner.options.length <= 1) {
        owner.innerHTML = '<option value="all">すべて</option>';
        users.forEach(u => {
            owner.innerHTML += `<option value="${u.id}">${u.name}</option>`;
        });
    }
}

window.bulkSelectProjectsByOwner = function() {
    const sel = document.getElementById('bulkSelectOwner');
    if (!sel || !sel.value || sel.value === 'all') {
        alert("責任者を選択してください。");
        return;
    }
    const ownerId = parseInt(sel.value, 10);
    const matchingIds = new Set(projects.filter(p => p.owner_id === ownerId).map(p => String(p.id)));
    if (matchingIds.size === 0) {
        alert("この責任者が設定されているプロジェクトが見つかりませんでした。");
        return;
    }
    document.querySelectorAll('.project-select-cb').forEach(cb => {
        if (matchingIds.has(cb.value)) cb.checked = true;
    });
};

window.generateWeeklyReportForProjects = async function(mode) {
    mode = mode === 'simple' ? 'simple' : 'ai';

    const checkedBoxes = document.querySelectorAll('.project-select-cb:checked');
    if (checkedBoxes.length === 0) {
        alert("プロジェクトを選択してください。");
        return;
    }
    const projectIds = Array.from(checkedBoxes).map(cb => parseInt(cb.value, 10));
    const names = projectIds
        .map(id => { const p = projects.find(x => x.id === id); return p ? p.name : null; })
        .filter(Boolean)
        .join('、');

    const modal = document.getElementById('weeklyReportModal');
    const titleEl = document.getElementById('weeklyReportTitle');
    const contentEl = document.getElementById('weeklyReportContent');
    const statusEl = document.getElementById('copyReportStatus');
    if (statusEl) statusEl.style.display = 'none';

    modal.style.display = 'flex';
    modal.classList.add('show');
    modal.style.opacity = '1';
    modal.style.pointerEvents = 'auto';

    if (mode === 'simple') {
        titleEl.textContent = '週報を作成中...';
        contentEl.value = '先週分のタスク進捗を集計しています…';
        try {
            const res = await fetch(`${API_BASE}/weekly_report`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ project_ids: projectIds, mode: 'simple' })
            });
            const data = await res.json();
            if (!res.ok || data.error) {
                titleEl.textContent = '週報の作成に失敗しました';
                contentEl.value = data.error || '不明なエラーが発生しました。';
                return;
            }
            titleEl.textContent = `✅ 週報が完成しました（簡易版） - ${names}`;
            contentEl.value = data.report;
        } catch (err) {
            titleEl.textContent = '週報の作成に失敗しました';
            contentEl.value = '通信エラーが発生しました: ' + err.message;
        }
        return;
    }

    // AI mode: stream the response so progress is visible as it's generated.
    titleEl.textContent = `週報を作成中(AI)... - ${names}`;
    contentEl.value = '';
    try {
        const res = await fetch(`${API_BASE}/weekly_report`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            // user_id lets the backend push a "完了しました" notification
            // through the app's own notifier popup (see notifier.py) once
            // generation finishes - unlike a browser notification, this
            // doesn't need repeated permission prompts (the app's port
            // changes every launch, which resets browser-level permission).
            body: JSON.stringify({ project_ids: projectIds, mode: 'ai', user_id: currentUserId })
        });

        if (!res.ok) {
            const data = await res.json().catch(() => ({}));
            titleEl.textContent = '週報の作成に失敗しました';
            contentEl.value = data.error || `エラーが発生しました (HTTP ${res.status})`;
            return;
        }

        const reader = res.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let full = '';
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            full += decoder.decode(value, { stream: true });
            contentEl.value = full;
            contentEl.scrollTop = contentEl.scrollHeight;
        }
        titleEl.textContent = `✅ 週報が完成しました（AI生成） - ${names}`;
    } catch (err) {
        titleEl.textContent = '週報の作成に失敗しました';
        contentEl.value = (contentEl.value || '') + '\n\n通信エラーが発生しました: ' + err.message;
    }
};

window.downloadProjectCsv = function(projectId) {
    const p = projects.find(x => x.id === projectId);
    if (!p) return;
    const pTasks = tasks.filter(t => t.project_id === projectId);
    
    let csvContent = "\uFEFF";
    csvContent += `"${p.name.replace(/"/g, '""')}"\n`;
    csvContent += "タスク名,担当者,開始日,期日\n";
    
    pTasks.forEach(t => {
        const assigneesText = getAssigneesText(t.assignees);
        const row = [
            `"${(t.title || '').replace(/"/g, '""')}"`,
            `"${assigneesText.replace(/"/g, '""')}"`,
            `"${(t.start_date || '').replace(/"/g, '""')}"`,
            `"${(t.due_date || '').replace(/"/g, '""')}"`
        ];
        csvContent += row.join(",") + "\n";
    });
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Project_${p.name}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};

window.quitSystem = async function() {
    if (confirm('システムを完全に終了しますか？\n※他のユーザーも一時的に利用できなくなります。')) {
        try {
            await fetch(`${API_BASE}/quit`, { method: 'POST' });
            alert('システムを終了しました。この画面を閉じてください。');
            window.close();
        } catch (e) {
            console.error(e);
            alert('終了リクエストを送信しました。');
        }
    }
}


function updateRoleFilterState() {
    const filterAssignee = document.getElementById('filterAssignee');
    const filterAssigneeRole = document.getElementById('filterAssigneeRole');
    if (filterAssignee && filterAssigneeRole) {
        if (filterAssignee.value === 'all') {
            filterAssigneeRole.disabled = true;
            filterAssigneeRole.style.opacity = '0.5';
            filterAssigneeRole.value = 'all'; // reset to all when disabled
        } else {
            filterAssigneeRole.disabled = false;
            filterAssigneeRole.style.opacity = '1';
        }
    }
}

window.uploadHolidayCsv = async function() {
    const fileInput = document.getElementById('holidayCsvInput');
    const file = fileInput.files[0];
    if(!file) {
        alert('CSVファイルを選択してください。');
        return;
    }
    const formData = new FormData();
    formData.append('file', file);
    
    try {
        const res = await fetch('/api/holidays/upload', {
            method: 'POST',
            body: formData
        });
        const result = await res.json();
        if(result.success) {
            alert(`休日のデータを${result.count}件登録しました。`);
            await fetchData();
            renderAllViews();
        } else {
            alert('エラーが発生しました: ' + result.error);
        }
    } catch(err) {
        alert('通信エラーが発生しました。');
    }
};

// --- Business Categories ---
window.renderBusinessCategories = function() {
    const list = document.getElementById('businessCategoryList');
    if (!list) return;
    
    list.innerHTML = '';
    if (businessCategories.length === 0) {
        list.innerHTML = '<div style="color:var(--text-secondary); font-size:0.9rem;">(登録されている業務分類はありません)</div>';
        return;
    }
    
    businessCategories.forEach(bc => {
        const item = document.createElement('div');
        item.style.display = 'flex';
        item.style.justifyContent = 'space-between';
        item.style.alignItems = 'center';
        item.style.padding = '8px 12px';
        item.style.background = 'rgba(255,255,255,0.05)';
        item.style.borderRadius = '6px';
        
        item.innerHTML = `
            <span style="font-weight:500;">${bc.name}</span>
            <button class="btn-danger btn-sm" onclick="deleteBusinessCategory(${bc.id})" title="削除">削除</button>
        `;
        list.appendChild(item);
    });
};

window.addBusinessCategory = async function() {
    const nameInput = document.getElementById('newBusinessCategoryName');
    const name = nameInput.value.trim();
    if (!name) return;
    
    try {
        const res = await fetch(`${API_BASE}/business_categories`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ name: name, order_index: businessCategories.length })
        });
        
        if (res.ok) {
            nameInput.value = '';
            await fetchData();
            renderBusinessCategories();
            populateCategorySelects();
        }
    } catch(err) {
        console.error(err);
        alert('追加に失敗しました');
    }
};

window.deleteBusinessCategory = async function(id) {
    if (!confirm('この業務分類を削除してよろしいですか？（紐づくタスク/プロジェクトから分類が解除されます）')) return;
    try {
        const res = await fetch(`${API_BASE}/business_categories/${id}`, {
            method: 'DELETE'
        });
        if (res.ok) {
            await fetchData();
            renderBusinessCategories();
            populateCategorySelects();
        }
    } catch(err) {
        console.error(err);
        alert('削除に失敗しました');
    }
};

function populateCategorySelects() {
    const selects = ['taskCreateCategory', 'projectModalCategory'];
    selects.forEach(id => {
        const el = document.getElementById(id);
        if(!el) return;
        const currentVal = el.value;
        
        let optionsHtml = '<option value="">(分類なし)</option>';
        businessCategories.forEach(bc => {
            optionsHtml += `<option value="${bc.id}">${bc.name}</option>`;
        });
        el.innerHTML = optionsHtml;
        
        if (currentVal && businessCategories.some(b => b.id == currentVal)) {
            el.value = currentVal;
        }
    });
}

// Call populateCategorySelects and renderBusinessCategories in init sequence or after fetchData

// --- Feedback ---
window.openFeedbackModal = function() {
    document.getElementById('feedbackForm').reset();
    document.getElementById('feedbackModal').classList.add('show');
};

window.submitFeedback = async function(event) {
    event.preventDefault();
    
    const type = document.getElementById('fbType').value;
    const title = document.getElementById('fbTitle').value;
    const content = document.getElementById('fbContent').value;
    const steps = document.getElementById('fbSteps').value;
    const imageFile = document.getElementById('fbImage').files[0];
    
    const formData = new FormData();
    formData.append('type', type);
    formData.append('title', title);
    formData.append('content', content);
    formData.append('steps', steps);
    formData.append('user_id', currentUserId || 1); // fallback
    if(imageFile) {
        formData.append('image', imageFile);
    }
    
    try {
        const res = await fetch(`${API_BASE}/feedbacks`, {
            method: 'POST',
            body: formData
        });
        if(res.ok) {
            alert('ご意見箱へ投稿しました。ご協力ありがとうございます！');
            document.getElementById('feedbackModal').classList.remove('show');
            if(document.getElementById('nav-feedback_list').style.display !== 'none') {
                window.renderFeedbackList();
            }
        } else {
            alert('投稿に失敗しました。');
        }
    } catch(err) {
        console.error(err);
        alert('通信エラーが発生しました。');
    }
};

window.renderFeedbackList = async function() {
    // switch active tab
    document.querySelectorAll('.view-container').forEach(v => v.style.display = 'none');
    document.getElementById('nav-feedback_list').style.display = 'block';
    document.querySelectorAll('.sidebar-menu li').forEach(li => li.classList.remove('active'));
    
    const container = document.getElementById('feedbackListContainer');
    container.innerHTML = '<div style="color:var(--text-secondary);">読み込み中...</div>';
    
    try {
        const res = await fetch(`${API_BASE}/feedbacks`);
        const feedbacks = await res.json();
        
        container.innerHTML = '';
        if(feedbacks.length === 0) {
            container.innerHTML = '<div style="color:var(--text-secondary);">現在投稿されている意見はありません。</div>';
            return;
        }
        
        feedbacks.forEach(fb => {
            const el = document.createElement('div');
            el.style.background = 'rgba(255,255,255,0.05)';
            el.style.border = '1px solid var(--border-color)';
            el.style.borderRadius = '8px';
            el.style.padding = '16px';
            
            const copyText = `【ご意見・要望】\n種別: ${fb.type}\nタイトル: ${fb.title}\n内容:\n${fb.content}\n\n発生手順:\n${fb.steps || 'なし'}`;
            
            let imgHtml = '';
            if(fb.attachment_path) {
                imgHtml = `<div style="margin-top:12px;"><img src="${fb.attachment_path}" style="max-width:100%; max-height:200px; border-radius:4px; border:1px solid var(--border-color);"></div>`;
            }
            
            el.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:start; margin-bottom:12px;">
                    <div>
                        <span class="badge" style="background:var(--primary);">${fb.type}</span>
                        <h3 style="display:inline-block; margin-left:8px; font-size:1.1rem;">${fb.title}</h3>
                    </div>
                    <button class="btn-primary btn-sm" onclick="copyFeedback(this)" data-feedback="${encodeURIComponent(copyText)}" style="display:flex; align-items:center; gap:6px;">
                        <i class="fas fa-robot"></i> AIへコピー
                    </button>
                </div>
                <div style="color:var(--text-secondary); font-size:0.95rem; white-space:pre-wrap;">${fb.content}</div>
                ${fb.steps ? `<div style="margin-top:12px; font-size:0.9rem;"><strong>発生手順:</strong><br><span style="white-space:pre-wrap; color:var(--text-secondary);">${fb.steps}</span></div>` : ''}
                ${imgHtml}
                <div style="margin-top:16px; font-size:0.8rem; color:var(--text-secondary); border-top:1px dashed var(--border-color); padding-top:8px;">
                    投稿日時: ${new Date(fb.created_at).toLocaleString()}
                </div>
            `;
            container.appendChild(el);
        });
    } catch(err) {
        console.error(err);
        container.innerHTML = '<div style="color:var(--danger);">読み込みに失敗しました。</div>';
    }
};

window.copyToClipboard = function(btn, text) {
    navigator.clipboard.writeText(text).then(() => {
        const origText = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-check"></i> コピー完了!';
        btn.style.background = 'var(--success)';
        setTimeout(() => {
            btn.innerHTML = origText;
            btn.style.background = '';
        }, 2000);
    });
};

window.copyFeedback = function(btn) {
    const text = decodeURIComponent(btn.getAttribute('data-feedback'));
    copyToClipboard(btn, text);
};


document.addEventListener('paste', (e) => {
    const modal = document.getElementById('feedbackModal');
    if (!modal || !modal.classList.contains('show')) return;
    const items = (e.clipboardData || e.originalEvent.clipboardData).items;
    for (let index in items) {
        const item = items[index];
        if (item.kind === 'file' && item.type.startsWith('image/')) {
            const blob = item.getAsFile();
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(blob);
            document.getElementById('fbImage').files = dataTransfer.files;
            
            let preview = document.getElementById('fbImagePreview');
            if (!preview) {
                preview = document.createElement('div');
                preview.id = 'fbImagePreview';
                preview.style = 'margin-top: 8px; color: var(--success); font-size: 0.9rem;';
                const fbImage = document.getElementById('fbImage');
                fbImage.parentNode.insertBefore(preview, fbImage.nextSibling);
            }
            preview.textContent = '✅ クリップボードから画像がセットされました (' + blob.name + ')';
        }
    }
});

// ---- Analytics Dashboard Logic ----
let statusChartInstance = null;
let assigneeChartInstance = null;

function renderDashboard() {
    if(!document.getElementById('statusChart')) return;
    
    const ctxStatus = document.getElementById('statusChart').getContext('2d');
    const ctxAssignee = document.getElementById('assigneeChart').getContext('2d');
    
    // Process Data for Main Charts
    const statusCounts = {};
    const assigneeCounts = {};
    
    tasks.forEach(t => {
        if(t.status !== '完了') {
            statusCounts[t.status] = (statusCounts[t.status] || 0) + 1;
        }
        if(t.assignees && t.status !== '完了') {
            t.assignees.forEach(a => {
                assigneeCounts[a.name] = (assigneeCounts[a.name] || 0) + 1;
            });
        }
    });
    
    // Render Main Charts
    if(window.statusChartInstance) window.statusChartInstance.destroy();
    window.statusChartInstance = new Chart(ctxStatus, {
        type: 'pie',
        data: { labels: Object.keys(statusCounts), datasets: [{ data: Object.values(statusCounts), backgroundColor: ['#3b82f6', '#f59e0b', '#10b981', '#8b5cf6', '#ec4899'], borderWidth: 0 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'right', labels: { color: getComputedStyle(document.body).getPropertyValue('--text-primary') } } } }
    });
    
    if(window.assigneeChartInstance) window.assigneeChartInstance.destroy();
    window.assigneeChartInstance = new Chart(ctxAssignee, {
        type: 'bar',
        data: { labels: Object.keys(assigneeCounts), datasets: [{ label: '未完了タスク数', data: Object.values(assigneeCounts), backgroundColor: '#3b82f6', borderRadius: 4 }] },
        options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { color: getComputedStyle(document.body).getPropertyValue('--text-primary') }, grid: { color: 'rgba(255,255,255,0.1)' } }, x: { ticks: { color: getComputedStyle(document.body).getPropertyValue('--text-primary') }, grid: { display: false } } }, plugins: { legend: { display: false } } }
    });

    // Destroy old dynamic instances
    if(window.dynamicCatInstances) { window.dynamicCatInstances.forEach(i => i.destroy()); }
    if(window.dynamicProjInstances) { window.dynamicProjInstances.forEach(i => i.destroy()); }
    window.dynamicCatInstances = [];
    window.dynamicProjInstances = [];

    // Process Business Categories
    const catContainer = document.getElementById('dynamicCatChartsContainer');
    if(!catContainer) return;
    catContainer.innerHTML = '';
    
    document.getElementById('drilldownSection').style.display = 'none';

    // Group tasks by category
    const catDataMap = {}; // categoryName -> { projects: {}, status: {}, assigneesByProject: {} }
    
    // Setup categories
    businessCategories.forEach(bc => {
        catDataMap[bc.name] = { id: bc.id, projects: {}, status: {}, assigneesByProject: {} };
    });
    catDataMap['未分類'] = { id: null, projects: {}, status: {}, assigneesByProject: {} };

    tasks.forEach(t => {
        if(t.status === '完了') return;
        
        let cId = null;
        if(t.project_id) {
            const p = projects.find(pr => pr.id == t.project_id);
            if(p && p.business_category_id) cId = p.business_category_id;
        }
        if(!cId && t.business_category_id) cId = t.business_category_id;
        
        const catName = cId ? (businessCategories.find(b => b.id == cId)?.name || '未分類') : '未分類';
        const pName = t.project_name || '未分類';
        
        const cData = catDataMap[catName];
        cData.projects[pName] = (cData.projects[pName] || 0) + 1;
        cData.status[t.status] = (cData.status[t.status] || 0) + 1;
        
        if(!cData.assigneesByProject[pName]) cData.assigneesByProject[pName] = new Set();
        if(t.assignees) {
            t.assignees.forEach(a => cData.assigneesByProject[pName].add(a.name));
        }
    });

    // Render Category Charts
    Object.keys(catDataMap).forEach((catName, idx) => {
        const cData = catDataMap[catName];
        if(Object.keys(cData.projects).length === 0 && Object.keys(cData.status).length === 0) return; // Skip empty
        
        const wrapper = document.createElement('div');
        wrapper.className = 'glass-panel';
        wrapper.style.padding = '16px';
        wrapper.style.display = 'flex';
        wrapper.style.flexDirection = 'column';
        wrapper.style.cursor = 'pointer';
        wrapper.style.transition = 'transform 0.2s';
        wrapper.onmouseover = () => wrapper.style.transform = 'translateY(-2px)';
        wrapper.onmouseout = () => wrapper.style.transform = 'translateY(0)';
        
        const header = document.createElement('div');
        header.style.display = 'flex';
        header.style.justifyContent = 'space-between';
        header.style.alignItems = 'center';
        header.style.marginBottom = '12px';
        
        const title = document.createElement('h4');
        title.textContent = catName;
        title.style.margin = '0';
        title.style.fontSize = '1rem';
        
        const toggle = document.createElement('select');
        toggle.className = 'input-field proj-chart-toggle';
        toggle.style.width = '110px';
        toggle.style.margin = '0';
        toggle.style.padding = '4px 8px';
        toggle.style.fontSize = '0.8rem';
        toggle.innerHTML = '<option value="project">PJ比率</option><option value="status">ステータス比率</option>';
        
        header.appendChild(title);
        header.appendChild(toggle);
        
        const canvasContainer = document.createElement('div');
        canvasContainer.style.position = 'relative';
        canvasContainer.style.height = '180px';
        canvasContainer.style.width = '100%';
        const canvas = document.createElement('canvas');
        canvasContainer.appendChild(canvas);
        
        wrapper.appendChild(header);
        wrapper.appendChild(canvasContainer);
        catContainer.appendChild(wrapper);

        // Click wrapper to drill down
        wrapper.addEventListener('click', (e) => {
            if(e.target === toggle) return;
            renderProjectDrilldown(catName, cData.id);
        });
        
        const ctx = canvas.getContext('2d');
        let chartInstance = null;
        
        const colors = ['#f87171', '#fb923c', '#fbbf24', '#a3e635', '#34d399', '#22d3ee', '#818cf8', '#c084fc', '#f472b6'];
        
        const updateChart = () => {
            const mode = toggle.value;
            let labels = [];
            let data = [];
            
            if(mode === 'project') {
                labels = Object.keys(cData.projects);
                data = Object.values(cData.projects);
            } else {
                labels = Object.keys(cData.status);
                data = Object.values(cData.status);
            }
            
            if(chartInstance) chartInstance.destroy();
            chartInstance = new Chart(ctx, {
                type: 'pie',
                data: { labels, datasets: [{ data, backgroundColor: colors, borderWidth: 1, borderColor: 'var(--bg-panel)' }] },
                options: { 
                    responsive: true, maintainAspectRatio: false, 
                    plugins: { 
                        legend: { position: 'right', labels: { color: getComputedStyle(document.body).getPropertyValue('--text-primary'), boxWidth: 12, font: {size: 10} } },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    let label = context.label || '';
                                    let val = context.raw || 0;
                                    let text = label + ': ' + val + '件';
                                    if(mode === 'project') {
                                        const assignees = Array.from(cData.assigneesByProject[label] || []);
                                        if(assignees.length > 0) {
                                            text += ' (担当: ' + assignees.join(', ') + ')';
                                        }
                                    }
                                    return text;
                                }
                            }
                        }
                    } 
                }
            });
            window.dynamicCatInstances.push(chartInstance);
        };
        
        toggle.addEventListener('change', updateChart);
        updateChart();
    });
}

function renderProjectDrilldown(catName, catId) {
    const drilldownSection = document.getElementById('drilldownSection');
    let title = document.getElementById('drilldownTitle');
    const container = document.getElementById('dynamicProjChartsContainer');
    
    drilldownSection.style.display = 'block';
    
    // Inject global toggle next to title
    if (!document.getElementById('globalProjToggle')) {
        const titleContainer = document.createElement('div');
        titleContainer.style.display = 'flex';
        titleContainer.style.justifyContent = 'space-between';
        titleContainer.style.alignItems = 'center';
        titleContainer.style.borderBottom = '1px solid var(--border-color)';
        titleContainer.style.marginBottom = '16px';
        titleContainer.style.paddingBottom = '8px';
        
        const newTitle = document.createElement('h3');
        newTitle.id = 'drilldownTitle';
        newTitle.style.margin = '0';
        newTitle.style.fontSize = '1.2rem';
        newTitle.style.color = 'var(--primary-color)';
        
        const globalToggle = document.createElement('select');
        globalToggle.id = 'globalProjToggle';
        globalToggle.className = 'input-field';
        globalToggle.style.width = '150px';
        globalToggle.style.margin = '0';
        globalToggle.innerHTML = '<option value="status">全プロジェクト：ステータス</option><option value="deadline">全プロジェクト：期限比率</option>';
        
        globalToggle.addEventListener('change', (e) => {
            const val = e.target.value;
            const allToggles = container.querySelectorAll('.proj-chart-toggle');
            allToggles.forEach(sel => {
                sel.value = val;
                sel.dispatchEvent(new Event('change'));
            });
        });
        
        titleContainer.appendChild(newTitle);
        titleContainer.appendChild(globalToggle);
        
        title.parentNode.replaceChild(titleContainer, title);
        title = newTitle;
    } else {
        title = document.getElementById('drilldownTitle');
    }
    
    title.textContent = `選択中の業務分類: ${catName} のプロジェクト詳細`;
    container.innerHTML = '';
    
    if(window.dynamicProjInstances) { window.dynamicProjInstances.forEach(i => i.destroy()); }
    window.dynamicProjInstances = [];

    const projDataMap = {}; // projectName -> { status: {}, deadline: {} }
    
    const today = new Date();
    today.setHours(0,0,0,0);
    const nextWeek = new Date(today);
    nextWeek.setDate(nextWeek.getDate() + 7);

    tasks.forEach(t => {
        if(t.status === '完了') return;
        let cId = null;
        if(t.project_id) {
            const p = projects.find(pr => pr.id == t.project_id);
            if(p) cId = p.business_category_id;
        }
        if(!cId && t.business_category_id) cId = t.business_category_id;
        
        const tCatName = cId ? (businessCategories.find(b => b.id == cId)?.name || '未分類') : '未分類';
        
        if(tCatName !== catName) return;
        
        const pName = t.project_name || '未分類';
        if(!projDataMap[pName]) projDataMap[pName] = { status: {}, deadline: {'本日・超過':0, '1週間以内':0, 'ゆとりあり':0} };
        
        const pData = projDataMap[pName];
        pData.status[t.status] = (pData.status[t.status] || 0) + 1;
        
        if(!t.due_date) {
            pData.deadline['ゆとりあり']++;
        } else {
            const dDate = new Date(t.due_date);
            dDate.setHours(0,0,0,0);
            if(dDate <= today) {
                pData.deadline['本日・超過']++;
            } else if(dDate <= nextWeek) {
                pData.deadline['1週間以内']++;
            } else {
                pData.deadline['ゆとりあり']++;
            }
        }
    });

    Object.keys(projDataMap).forEach((pName) => {
        const pData = projDataMap[pName];
        
        const wrapper = document.createElement('div');
        wrapper.className = 'glass-panel';
        wrapper.style.padding = '16px';
        wrapper.style.display = 'flex';
        wrapper.style.flexDirection = 'column';
        wrapper.style.background = 'rgba(255,255,255,0.03)';
        wrapper.style.border = '1px solid rgba(255,255,255,0.1)';
        
        const header = document.createElement('div');
        header.style.display = 'flex';
        header.style.justifyContent = 'space-between';
        header.style.alignItems = 'center';
        header.style.marginBottom = '12px';
        
        const hTitle = document.createElement('h4');
        hTitle.textContent = pName;
        hTitle.style.margin = '0';
        hTitle.style.fontSize = '1rem';
        
        const toggle = document.createElement('select');
        toggle.className = 'input-field proj-chart-toggle';
        toggle.style.width = '110px';
        toggle.style.margin = '0';
        toggle.style.padding = '4px 8px';
        toggle.style.fontSize = '0.8rem';
        toggle.innerHTML = '<option value="status">ステータス</option><option value="deadline">期限比率</option>';
        
        header.appendChild(hTitle);
        header.appendChild(toggle);
        
        const canvasContainer = document.createElement('div');
        canvasContainer.style.position = 'relative';
        canvasContainer.style.height = '160px';
        canvasContainer.style.width = '100%';
        const canvas = document.createElement('canvas');
        canvasContainer.appendChild(canvas);
        
        wrapper.appendChild(header);
        wrapper.appendChild(canvasContainer);
        container.appendChild(wrapper);

        const ctx = canvas.getContext('2d');
        let chartInstance = null;
        
        const colors = ['#f87171', '#fb923c', '#fbbf24', '#a3e635', '#34d399', '#22d3ee', '#818cf8', '#c084fc', '#f472b6'];
        const dlColors = ['#ef4444', '#f59e0b', '#10b981']; // Red, Orange, Green
        
        const updateChart = () => {
            const mode = toggle.value;
            let labels = [];
            let data = [];
            let bgColors = colors;
            
            if(mode === 'status') {
                labels = Object.keys(pData.status);
                data = Object.values(pData.status);
            } else {
                labels = ['本日・超過', '1週間以内', 'ゆとりあり'];
                data = [pData.deadline['本日・超過'], pData.deadline['1週間以内'], pData.deadline['ゆとりあり']];
                bgColors = dlColors;
            }
            
            // remove zeros for deadline
            if(mode === 'deadline') {
                const fLabels = [];
                const fData = [];
                const fColors = [];
                for(let i=0; i<data.length; i++){
                    if(data[i]>0) { fLabels.push(labels[i]); fData.push(data[i]); fColors.push(bgColors[i]); }
                }
                labels = fLabels; data = fData; bgColors = fColors;
            }
            
            if(chartInstance) chartInstance.destroy();
            chartInstance = new Chart(ctx, {
                type: 'pie',
                data: { labels, datasets: [{ data, backgroundColor: bgColors, borderWidth: 1, borderColor: 'var(--bg-panel)' }] },
                options: { 
                    responsive: true, maintainAspectRatio: false, 
                    plugins: { 
                        legend: { position: 'right', labels: { color: getComputedStyle(document.body).getPropertyValue('--text-primary'), boxWidth: 10, font: {size: 10} } },
                    } 
                }
            });
            window.dynamicProjInstances.push(chartInstance);
        };
        
        toggle.addEventListener('change', updateChart);
        updateChart();
    });
    
    // Smooth scroll to drilldown section
    drilldownSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ---- Subtasks Logic ----
async function loadSubtasks(taskId) {
    const res = await fetch(`/api/tasks/${taskId}/subtasks`);
    const subtasks = await res.json();
    renderSubtasks(subtasks);
}

function renderSubtasks(subtasks) {
    const container = document.getElementById('subtasksContainer');
    if(!container) return;
    container.innerHTML = '';
    subtasks.forEach(st => {
        const div = document.createElement('div');
        div.style.display = 'flex';
        div.style.alignItems = 'center';
        div.style.gap = '8px';
        div.style.background = 'var(--bg-surface)';
        div.style.padding = '8px';
        div.style.borderRadius = '4px';
        
        const cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.checked = st.is_completed === 1;
        cb.onchange = () => toggleSubtask(st.id, cb.checked);
        
        const title = document.createElement('span');
        title.textContent = st.title;
        title.style.flex = '1';
        title.style.textDecoration = cb.checked ? 'line-through' : 'none';
        title.style.color = cb.checked ? 'var(--text-secondary)' : 'var(--text-primary)';
        
        const delBtn = document.createElement('button');
        delBtn.innerHTML = '&times;';
        delBtn.className = 'btn-danger btn-sm';
        delBtn.style.padding = '2px 8px';
        delBtn.onclick = () => deleteSubtask(st.id);
        
        div.appendChild(cb);
        div.appendChild(title);
        div.appendChild(delBtn);
        container.appendChild(div);
    });
}

async function addSubtask() {
    const input = document.getElementById('newSubtaskTitle');
    const title = input.value.trim();
    if(!title || !currentOpenTaskId) return;
    
    await fetch(`/api/tasks/${currentOpenTaskId}/subtasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: title, order_index: 0 })
    });
    input.value = '';
    await loadSubtasks(currentOpenTaskId);
    fetchData(); // update counts
}

async function toggleSubtask(subId, isCompleted) {
    await fetch(`/api/tasks/${currentOpenTaskId}/subtasks/${subId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_completed: isCompleted ? 1 : 0 })
    });
    await loadSubtasks(currentOpenTaskId);
    fetchData(); // update counts
}

async function deleteSubtask(subId) {
    await fetch(`/api/tasks/${currentOpenTaskId}/subtasks/${subId}`, {
        method: 'DELETE'
    });
    await loadSubtasks(currentOpenTaskId);
    fetchData(); // update counts
}

// Hook into openTaskModal
const originalOpenTaskModal = window.openTaskModal;
window.openTaskModal = function(taskId) {
    originalOpenTaskModal(taskId);
    if(document.getElementById('subtasksContainer')) {
        document.getElementById('subtasksContainer').innerHTML = 'Loading...';
        loadSubtasks(taskId);
    }
};

// Multi-team Config logic
let appConfig = { team_name: '', theme: 'light', themeHue: '230' };

async function loadAppConfig() {
    try {
        const res = await fetch(`${API_BASE}/config`);
        if (res.ok) {
            appConfig = await res.json();
            applyAppConfig();
        }
    } catch (e) {
        console.error('Failed to load config', e);
    }
}

async function saveAppConfig() {
    try {
        await fetch(`${API_BASE}/config`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(appConfig)
        });
    } catch(e) {
        console.error('Failed to save config', e);
    }
}

function applyAppConfig() {
    if (appConfig.team_name) {
        document.title = `はかどり - ${appConfig.team_name}`;
        const badge = document.getElementById('teamBadge');
        if (badge) {
            badge.innerText = appConfig.team_name;
            badge.style.display = 'inline-block';
        }
    }
    
    const themeCheckbox = document.getElementById('themeToggleCheckbox');
    const themeToggle = document.getElementById('themeToggle'); // For backwards compat
    const isDark = appConfig.theme === 'dark';
    
    if (isDark) {
        document.body.classList.add('dark-mode');
    } else {
        document.body.classList.remove('dark-mode');
    }
    
    if (themeCheckbox) themeCheckbox.checked = isDark;
    if (themeToggle) themeToggle.checked = isDark;
    
    const themeSlider = document.getElementById('themeSlider');
    const themePreviewBox = document.getElementById('themePreviewBox');
    
    if (appConfig.themeHue) {
        document.documentElement.style.setProperty('--primary-hue', appConfig.themeHue);
        if (themeSlider) themeSlider.value = appConfig.themeHue;
        if (themePreviewBox) themePreviewBox.style.backgroundColor = `hsl(${appConfig.themeHue}, 70%, 50%)`;
    }
}

window.editTeamName = async function() {
    const currentName = appConfig.team_name || '';
    const newName = prompt('チーム名を入力してください:', currentName);
    if (newName !== null && newName.trim() !== '') {
        appConfig.team_name = newName.trim();
        applyAppConfig();
        await saveAppConfig();
        alert('チーム名を更新しました！');
    }
};

// Intercept theme changes
document.addEventListener('DOMContentLoaded', () => {
    loadAppConfig();
    
    const themeCheckbox = document.getElementById('themeToggleCheckbox');
    if (themeCheckbox) {
        themeCheckbox.addEventListener('change', () => {
            appConfig.theme = themeCheckbox.checked ? 'dark' : 'light';
            applyAppConfig();
            saveAppConfig();
        });
    }
    
    const themeSlider = document.getElementById('themeSlider');
    if (themeSlider) {
        themeSlider.addEventListener('change', (e) => {
            appConfig.themeHue = e.target.value;
            applyAppConfig();
            saveAppConfig();
        });
    }
});

window.openTransferModal = function() {
    if (!currentOpenTaskId) return;
    const select = document.getElementById('transferTargetTeam');
    select.innerHTML = '<option value="">読み込み中...</option>';
    document.getElementById('transferModal').classList.add('show');
    
    fetch('/api/config')
        .then(res => res.json())
        .then(data => {
            select.innerHTML = '';
            if (!data.teams || data.teams.length === 0) {
                select.innerHTML = '<option value="">他チームの設定がありません</option>';
            } else {
                data.teams.forEach(t => {
                    select.innerHTML += `<option value="${t.dir}">${t.name}</option>`;
                });
            }
        });
};

window.submitTransfer = async function() {
    if (!currentOpenTaskId) return;
    const targetDir = document.getElementById('transferTargetTeam').value;
    if (!targetDir) {
        alert('移管先チームを選択してください');
        return;
    }
    if (!confirm('本当にこのタスクを移管しますか？\n※この操作は元に戻せません。')) return;
    
    try {
        const res = await fetch(`/api/tasks/${currentOpenTaskId}/transfer`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ target_team_dir: targetDir })
        });
        const data = await res.json();
        if (data.success) {
            alert('移管しました');
            document.getElementById('transferModal').classList.remove('show');
            closeModal();
            refreshData();
        } else {
            alert('エラー: ' + data.error);
        }
    } catch (e) {
        alert('通信エラー');
    }
};
