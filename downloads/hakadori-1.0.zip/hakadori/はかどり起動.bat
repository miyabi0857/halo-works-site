@echo off
rem ---------------------------------------------------------------
rem  Hakadori launcher.
rem
rem  NOTE: keep this file ASCII-only. cmd.exe reads .bat files using
rem  the OEM code page, so UTF-8 Japanese comments corrupt parsing.
rem
rem  Two distributions are supported:
rem    - exe build   : Hakadori.exe sits next to this file
rem    - source build: run app.py with Python (this is what the zip ships)
rem  The previous version only handled the exe build, so the source
rem  zip always failed with "Master file not found".
rem ---------------------------------------------------------------
echo ----------------------------------------------------
echo Starting Hakadori...
echo ----------------------------------------------------

echo [INFO] Killing old processes...
taskkill /F /IM Hakadori.exe /T >nul 2>&1
taskkill /F /IM notifier.exe /T >nul 2>&1
rem "timeout" prints an error when stdin is redirected; ping is safe everywhere.
ping -n 2 127.0.0.1 >nul 2>&1

set "MASTER_DIR=%~dp0"
if "%MASTER_DIR:~-1%"=="\" set "MASTER_DIR=%MASTER_DIR:~0,-1%"

set "HAKADORI_APP_DIR=%MASTER_DIR%"
cd /d "%MASTER_DIR%"

if exist "%MASTER_DIR%\Hakadori.exe" goto run_exe
goto run_source

:run_exe
rem Running the exe straight off a shared folder locks the file for
rem everyone else, so copy it to this PC first.
set "LOCAL_DIR=%LOCALAPPDATA%\Hakadori"
if not exist "%LOCAL_DIR%" mkdir "%LOCAL_DIR%"
copy /Y "%MASTER_DIR%\Hakadori.exe" "%LOCAL_DIR%\Hakadori.exe" >nul
if errorlevel 1 echo [WARNING] Failed to copy exe file. Maybe it is still running.
echo [INFO] Launching Hakadori (exe)...
start "" "%LOCAL_DIR%\Hakadori.exe"
exit /b

:run_source
if not exist "%MASTER_DIR%\app.py" (
    echo [ERROR] app.py not found in:
    echo         %MASTER_DIR%
    echo         Extract the zip first, then run this file from inside the folder.
    pause
    exit /b 1
)

rem Prefer the "py" launcher. Plain "python" is often the Microsoft Store
rem stub, which just opens the Store and exits without running anything.
set "PYCMD="
where py >nul 2>&1
if %errorlevel%==0 set "PYCMD=py"
if not defined PYCMD (
    where python >nul 2>&1
    if %errorlevel%==0 set "PYCMD=python"
)
if not defined PYCMD (
    echo [ERROR] Python was not found.
    echo         Install Python 3.10 or later from https://www.python.org/downloads/
    echo         and make sure "Add Python to PATH" is checked during setup.
    pause
    exit /b 1
)

echo [INFO] Launching Hakadori with %PYCMD% ...
echo [INFO] Keep this window open while you use Hakadori.
%PYCMD% app.py
if errorlevel 1 (
    echo.
    echo [ERROR] Hakadori stopped with an error.
    echo         If the message says "No module named flask", run this once:
    echo             pip install -r requirements.txt
    pause
)
