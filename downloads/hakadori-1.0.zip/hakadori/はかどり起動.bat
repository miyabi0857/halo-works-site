@echo off
echo ----------------------------------------------------
echo Starting Hakadori...
echo ----------------------------------------------------

echo [INFO] Killing old processes...
taskkill /F /IM Hakadori.exe /T >nul 2>&1
taskkill /F /IM notifier.exe /T >nul 2>&1
timeout /t 1 >nul

set "MASTER_DIR=%~dp0"
if "%MASTER_DIR:~-1%"=="\" set "MASTER_DIR=%MASTER_DIR:~0,-1%"

set "LOCAL_DIR=%LOCALAPPDATA%\Hakadori"

if not exist "%LOCAL_DIR%" (
    mkdir "%LOCAL_DIR%"
)

if not exist "%MASTER_DIR%\Hakadori.exe" (
    echo [ERROR] Master file not found.
    echo Expected: %MASTER_DIR%\Hakadori.exe
    pause
    exit /b
)

copy /Y "%MASTER_DIR%\Hakadori.exe" "%LOCAL_DIR%\Hakadori.exe" >nul
if errorlevel 1 (
    echo [WARNING] Failed to copy exe file. Maybe it is still running.
)

set "HAKADORI_APP_DIR=%MASTER_DIR%"
cd /d "%MASTER_DIR%"

echo [INFO] Launching Hakadori...
start "" "%LOCAL_DIR%\Hakadori.exe"
exit
