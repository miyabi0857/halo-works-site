import tkinter as tk
from tkinter import ttk
import urllib.request
import json
import time
import threading
import queue
import logging
import os
import sys
import hashlib

def get_instance_hash():
    cwd = os.getcwd()
    return hashlib.md5(cwd.encode('utf-8')).hexdigest()[:8]

INSTANCE_HASH = get_instance_hash()

# Determine log file path (next to the exe or in current dir)
log_path = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), 'notifier.log')
logging.basicConfig(filename=log_path, level=logging.DEBUG, format='%(asctime)s %(levelname)s:%(message)s')
logging.info('Notifier script started')

from datetime import datetime

API_BASE = "http://127.0.0.1:5000/api"
USER_ID = None
POLL_INTERVAL = 5 # seconds

# Bypass proxy for all local API calls
proxy_handler = urllib.request.ProxyHandler({})
opener = urllib.request.build_opener(proxy_handler)
urllib.request.install_opener(opener)

def fetch_users():
    try:
        req = urllib.request.Request(f"{API_BASE}/users")
        with urllib.request.urlopen(req) as response:
            return json.loads(response.read().decode())
    except:
        return []

def fetch_notifications(user_id):
    try:
        req = urllib.request.Request(f"{API_BASE}/notifications/{user_id}")
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode())
            if data:
                logging.debug(f'Fetched {len(data)} notifications for {user_id}')
            return data
    except Exception as e:
        logging.error(f'Error fetching notifications: {e}')
        return []

def fetch_comments(task_id):
    try:
        req = urllib.request.Request(f"{API_BASE}/tasks/{task_id}/comments")
        with urllib.request.urlopen(req) as response:
            return json.loads(response.read().decode())
    except:
        return []

def post_comment(task_id, user_id, content, mentions=None):
    if mentions is None:
        mentions = []
    try:
        data = json.dumps({"user_id": user_id, "content": content, "mentions": mentions}).encode()
        req = urllib.request.Request(f"{API_BASE}/tasks/{task_id}/comments", data=data, headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req) as response:
            return json.loads(response.read().decode())
    except:
        return None

def post_reaction(comment_id, user_id, emoji):
    try:
        data = json.dumps({"user_id": user_id, "emoji": emoji}).encode()
        req = urllib.request.Request(f"{API_BASE}/comments/{comment_id}/reactions", data=data, headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req) as response:
            return json.loads(response.read().decode())
    except:
        return None

def mark_as_read(notif_id):
    try:
        req = urllib.request.Request(f"{API_BASE}/notifications/{notif_id}/read", method='PUT')
        # Some servers require Content-Length for PUT
        req.add_header('Content-Length', '0')
        with urllib.request.urlopen(req) as response:
            pass
    except Exception as e:
        logging.error(f"Error marking notification {notif_id} as read: {e}")

class LoginWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("はかどり通知 - ログイン")
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        x = int((sw - 300) / 2)
        y = int((sh - 200) / 2)
        self.root.geometry(f"300x200+{x}+{y}")
        
        ttk.Label(root, text="ユーザーを選択してください", font=("Arial", 12)).pack(pady=20)
        
        self.users = fetch_users()
        if not self.users:
            ttk.Label(root, text="サーバーに接続できません。\nWebサーバーが起動しているか確認してください。", foreground="red").pack()
            return
            
        self.user_var = tk.StringVar()
        self.combo = ttk.Combobox(root, textvariable=self.user_var, state="readonly")
        self.combo['values'] = [u['name'] for u in self.users]
        self.combo.pack(pady=10)
        
        self.last_user_file = os.path.join(os.environ.get('APPDATA', os.getcwd()), f'HakadoriNotifier_last_user_{INSTANCE_HASH}.txt')
        if os.path.exists(self.last_user_file):
            try:
                with open(self.last_user_file, 'r', encoding='utf-8') as f:
                    last_user = f.read().strip()
                if last_user in self.combo['values']:
                    self.user_var.set(last_user)
            except:
                pass
        
        ttk.Button(root, text="開始", command=self.login).pack(pady=10)
        
    def login(self):
        name = self.user_var.get()
        if not name: return
        global USER_ID
        for u in self.users:
            if u['name'] == name:
                USER_ID = u['id']
                try:
                    with open(self.last_user_file, 'w', encoding='utf-8') as f:
                        f.write(name)
                except:
                    pass
                break
        self.root.destroy()

class AlertPopup:
    def __init__(self, parent, notif, app_instance):
        self.top = tk.Toplevel(parent)
        
        team_name = ""
        try:
            req = urllib.request.Request(f"{API_BASE}/config")
            with urllib.request.urlopen(req, timeout=1.0) as r:
                team_name = json.loads(r.read().decode('utf-8')).get('team_name', '')
        except:
            pass
            
        self.top.title(f"新着通知 - {team_name}" if team_name else "新着通知")
        
        self.notif = notif
        self.app = app_instance
        
        project_name = notif.get('project_name') or 'システム通知'
        task_title = notif.get('task_title') or '新着メッセージ'
        message = notif.get('message') or ''
        
        # Calculate dynamic height based on lines
        lines = message.split('\n')
        num_lines = sum((len(line)//35 + 1) for line in lines)
        sw = self.top.winfo_screenwidth()
        sh = self.top.winfo_screenheight()
        max_h = int(sh * 0.85) # max 85% of screen height
        req_height = min(max_h, max(250, 150 + num_lines * 18))
        x = int((sw - 400) / 2)
        y = int((sh - req_height) / 2)
        self.top.geometry(f"400x{req_height}+{x}+{y}")
        self.top.maxsize(400, max_h)
        self.top.attributes('-topmost', True)
        
        # Format the text
        tk.Label(self.top, text=f"プロジェクト: {project_name}", font=("Arial", 9, "bold"), anchor="w", fg="#4f46e5").pack(fill=tk.X, padx=10, pady=(10, 2))
        tk.Label(self.top, text=f"タスク: {task_title}", font=("Arial", 10, "bold"), anchor="w").pack(fill=tk.X, padx=10, pady=2)
        
        # Quick Reactions and Buttons (Pack at bottom first to ensure visibility)
        btn_frame = tk.Frame(self.top)
        btn_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=(10, 10))
        
        react_frame = tk.Frame(self.top)
        react_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=(5, 5))
        
        tk.Label(react_frame, text="クイックリアクション:", font=("Arial", 8), fg="gray").pack(side=tk.LEFT, padx=5)
        for emoji in ['👍', '💖', '😂', '🙏']:
            tk.Button(react_frame, text=emoji, font=("Arial", 10), bd=0, cursor="hand2", command=lambda e=emoji: self.quick_react(e)).pack(side=tk.LEFT, padx=2)
        
        tk.Button(btn_frame, text="閉じる (後で確認)", width=15, command=self.top.destroy).pack(side=tk.LEFT, padx=10)
        is_comment = 'コメント' in message
        if is_comment:
            tk.Button(btn_frame, text="確認する", width=15, bg="#4f46e5", fg="white", command=self.open_chat).pack(side=tk.RIGHT, padx=10)
        else:
            tk.Button(btn_frame, text="確認した", width=15, bg="#10b981", fg="white", command=self.mark_read_and_close).pack(side=tk.RIGHT, padx=10)
            
        # Message Frame (Expands to fill remaining space)
        msg_frame = tk.Frame(self.top, bg="#f3f4f6")
        msg_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        import tkinter.scrolledtext as st
        text_widget = st.ScrolledText(msg_frame, font=("Arial", 10), bg="#f3f4f6", wrap=tk.WORD, bd=0, padx=8, pady=8)
        text_widget.pack(fill=tk.BOTH, expand=True)
        text_widget.tag_configure("bold", font=("Arial", 10, "bold"))
        
        parts = message.split('**')
        for i, part in enumerate(parts):
            if i % 2 == 1:
                text_widget.insert(tk.END, part, "bold")
            else:
                text_widget.insert(tk.END, part)
        text_widget.config(state=tk.DISABLED)
        
    def quick_react(self, emoji):
        task_id = self.notif.get('task_id')
        if task_id:
            comments = fetch_comments(task_id)
            if comments:
                last_comment = comments[-1]
                post_reaction(last_comment['id'], USER_ID, emoji)
        self.top.destroy()
        
    def mark_read_and_close(self):
        mark_as_read(self.notif.get('id'))
        self.top.destroy()

    def open_chat(self):
        self.top.destroy()
        self.app.open_chat_popup(self.notif)

class ChatPopup:
    def __init__(self, parent, notif):
        self.top = tk.Toplevel(parent)
        self.top.title("はかどり - チャット通知")
        sw = self.top.winfo_screenwidth()
        sh = self.top.winfo_screenheight()
        x = int((sw - 500) / 2)
        y = int((sh - 600) / 2)
        self.top.geometry(f"500x600+{x}+{y}")
        
        # Removed -topmost to fix IME (Input Method Editor) bug on Windows where composition text doesn't show
        self.top.lift()
        self.top.focus_force()
        
        self.notif = notif
        self.task_id = notif.get('task_id')
        
        # main container
        self.main_frame = tk.Frame(self.top, bg='white')
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Header
        header = tk.Frame(self.main_frame, bg='#4f46e5', height=60)
        header.pack(fill=tk.X)
        header.pack_propagate(False) # keep height
        
        project_name = notif.get('project_name') or 'プロジェクト情報なし'
        task_title = notif.get('task_title') or 'タスク情報なし'
        if not self.task_id:
            project_name = 'システム通知'
            task_title = '新着メッセージ'
        
        tk.Label(header, text=project_name, fg='#a5b4fc', bg='#4f46e5', font=("Arial", 9)).pack(anchor='w', padx=10, pady=(8,0))
        tk.Label(header, text=task_title, fg='white', bg='#4f46e5', font=("Arial", 12, "bold")).pack(anchor='w', padx=10)
        
        # Chat History Area (Scrollable Canvas)
        chat_container = tk.Frame(self.main_frame, bg='white')
        chat_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.canvas = tk.Canvas(chat_container, bg='white', highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(chat_container, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas, bg='white')
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw", width=450)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
        # Input Area
        input_frame = tk.Frame(self.main_frame, bg='white', height=60, padx=10, pady=10)
        input_frame.pack(fill=tk.X, side=tk.BOTTOM)
        
        if self.task_id:
            self.users = fetch_users() or []
            
            # Mention dropdown
            self.mention_list = tk.Listbox(self.main_frame, font=("Arial", 10), height=5)
            self.mention_list.place_forget()
            self.mention_list.bind('<Double-1>', self.insert_mention)
            self.mention_list.bind('<Return>', self.insert_mention)
            
            self.text_input = tk.Entry(input_frame, font=("Arial", 11))
            self.text_input.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0,10))
            self.text_input.bind('<Return>', lambda e: self.send_reply())
            self.text_input.bind('<KeyRelease>', self.check_mention)
            
            btn_send = tk.Button(input_frame, text="送信", bg='#4f46e5', fg='white', font=("Arial", 11, "bold"), relief="flat", command=self.send_reply)
            btn_send.pack(side=tk.RIGHT)
        else:
            tk.Label(input_frame, text="この通知には返信できません", bg='white', fg='gray', font=("Arial", 10)).pack(expand=True)
        
        # Mark as read and populate chat
        mark_as_read(self.notif['id'])
        self.last_comments_json = None
        self.load_comments()
        self.poll_chat()
        
    
    def poll_chat(self):
        if self.top.winfo_exists():
            self.load_comments(polling=True)
            self.top.after(3000, self.poll_chat)

    def load_comments(self, polling=False):
        import json
        if not self.task_id:
            if not polling:
                for widget in self.scrollable_frame.winfo_children():
                    widget.destroy()
                tk.Label(self.scrollable_frame, text=self.notif['message'], bg='white', wraplength=450, justify="left", padx=10, pady=10, font=("Arial", 11)).pack(pady=5, anchor='w')
            return
            
        comments = fetch_comments(self.task_id)
        current_json = json.dumps(comments, sort_keys=True)
        if polling and self.last_comments_json == current_json:
            return
        self.last_comments_json = current_json

        # clear frame only when we are going to populate it
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()

        if not comments:
            tk.Label(self.scrollable_frame, text="コメントがありません", bg='white', fg='gray').pack(pady=20)
            return
            
        for c in comments:
            self.add_comment_bubble(c)
            
        # scroll to bottom
        self.canvas.update_idletasks()
        self.canvas.yview_moveto(1.0)
            
    def add_comment_bubble(self, c):
        is_me = str(c['user_id']) == str(USER_ID)
        
        bubble_frame = tk.Frame(self.scrollable_frame, bg='white')
        bubble_frame.pack(fill=tk.X, pady=8)
        
        content = c['content']
        user_name = c.get('user_name', '不明')
        comment_id = c['id']
        
        reactions = c.get('reactions', [])
        reads = c.get('reads', [])
        
        # Group reactions
        react_counts = {}
        for r in reactions:
            emoji = r['emoji']
            react_counts[emoji] = react_counts.get(emoji, 0) + 1
            
        reads_count = len(reads)
        reads_text = f"既読 {reads_count}" if reads_count > 0 else ""
        
        if is_me:
            # Right aligned
            inner = tk.Frame(bubble_frame, bg='white')
            inner.pack(side=tk.RIGHT, anchor='e', padx=10)
            
            tk.Label(inner, text="あなた", font=("Arial", 8), bg='white', fg='gray').pack(anchor='e')
            msg_frame = tk.Frame(inner, bg='white', highlightbackground='#e5e7eb', highlightcolor='#e5e7eb', highlightthickness=1)
            msg_frame.pack(anchor='e')
            msg_lbl = tk.Label(msg_frame, text=content, bg='white', fg='black', font=("Arial", 10), padx=12, pady=10, wraplength=250, justify='left')
            msg_lbl.pack()
            
            meta_frame = tk.Frame(inner, bg='white')
            meta_frame.pack(anchor='e', pady=2)
            if reads_text:
                tk.Label(meta_frame, text=reads_text, font=("Arial", 8, "bold"), fg="#4f46e5", bg='white').pack(side=tk.RIGHT, padx=5)
            self._add_reactions_ui(meta_frame, comment_id, react_counts)
            
        else:
            # Left aligned
            inner = tk.Frame(bubble_frame, bg='white')
            inner.pack(side=tk.LEFT, anchor='w', padx=10)
            
            tk.Label(inner, text=user_name, font=("Arial", 8), bg='white', fg='gray').pack(anchor='w')
            msg_frame = tk.Frame(inner, bg='#e0e7ff')
            msg_frame.pack(anchor='w')
            msg_lbl = tk.Label(msg_frame, text=content, bg='#e0e7ff', fg='black', font=("Arial", 10), padx=12, pady=10, wraplength=250, justify='left')
            msg_lbl.pack()
            
            meta_frame = tk.Frame(inner, bg='white')
            meta_frame.pack(anchor='w', pady=2)
            self._add_reactions_ui(meta_frame, comment_id, react_counts)
            if reads_text:
                tk.Label(meta_frame, text=reads_text, font=("Arial", 8, "bold"), fg="#4f46e5", bg='white').pack(side=tk.LEFT, padx=5)

    def _add_reactions_ui(self, parent, comment_id, react_counts):
        for emoji, count in react_counts.items():
            btn = tk.Button(parent, text=f"{emoji} {count}", font=("Arial", 8), bg="#f3f4f6", bd=0, cursor="hand2", command=lambda e=emoji: self.toggle_react(comment_id, e))
            btn.pack(side=tk.LEFT, padx=2)
        
        add_btn = tk.Button(parent, text="☺", font=("Arial", 8), bg="#f3f4f6", bd=0, cursor="hand2", command=lambda: self.show_reaction_picker(parent, comment_id))
        add_btn.pack(side=tk.LEFT, padx=2)
        
    def toggle_react(self, comment_id, emoji):
        post_reaction(comment_id, USER_ID, emoji)
        self.last_comments_json = None
        self.load_comments()
        self.poll_chat()
        
    def show_reaction_picker(self, parent, comment_id):
        picker = tk.Toplevel(self.top)
        picker.overrideredirect(True) # no window border
        picker.attributes('-topmost', True)
        
        # position near the button
        x = parent.winfo_rootx()
        y = parent.winfo_rooty() + 20
        picker.geometry(f"+{x}+{y}")
        
        frame = tk.Frame(picker, bg="white", highlightbackground="gray", highlightthickness=1)
        frame.pack()
        
        for emoji in ['👍', '💖', '😂', '😥', '👀', '🙏']:
            tk.Button(frame, text=emoji, font=("Arial", 12), bd=0, cursor="hand2", command=lambda e=emoji, p=picker: [p.destroy(), self.toggle_react(comment_id, e)]).pack(side=tk.LEFT, padx=2)
            
        picker.bind("<FocusOut>", lambda e: picker.destroy())
        picker.focus_set()

    def check_mention(self, event):
        text = self.text_input.get()
        cursor_pos = self.text_input.index(tk.INSERT)
        text_before = text[:cursor_pos]
        
        import re
        match = re.search(r'@(\S*)$', text_before)
        if match:
            search_str = match.group(1).lower()
            matched = [u for u in self.users if search_str in u['name'].lower()]
            if matched:
                self.mention_list.delete(0, tk.END)
                for u in matched:
                    self.mention_list.insert(tk.END, u['name'])
                
                # Position the listbox above the entry
                x = self.text_input.winfo_x()
                y = self.text_input.winfo_y() - 100
                self.mention_list.place(x=x, y=y, width=200)
                self.mention_match = match
                return
        
        self.mention_list.place_forget()

    def insert_mention(self, event=None):
        if not self.mention_list.curselection(): return
        name = self.mention_list.get(self.mention_list.curselection())
        
        text = self.text_input.get()
        match = getattr(self, 'mention_match', None)
        if match:
            new_text = text[:match.start()] + f"@{name} " + text[match.end():]
            self.text_input.delete(0, tk.END)
            self.text_input.insert(0, new_text)
            self.mention_list.place_forget()
            self.text_input.focus_set()

    def send_reply(self):
        text = self.text_input.get().strip()
        if not text or not self.task_id: return
        
        mentions = []
        for u in self.users:
            if f"@{u['name']}" in text:
                mentions.append(u['id'])
                
        res = post_comment(self.task_id, USER_ID, text, mentions)
        if res:
            self.text_input.delete(0, tk.END)
            self.last_comments_json = None
        self.load_comments()
        self.poll_chat()

class NotifierApp:
    def __init__(self):
        logging.info(f'NotifierApp init for user {USER_ID}')
        self.root = tk.Tk()
        self.root.withdraw()
        self.notified_ids = set()
        self.q = queue.Queue()
        self.open_popups = {} # task_id -> ChatPopup
        
        self.poll_thread = threading.Thread(target=self.poll_loop, daemon=True)
        self.poll_thread.start()
        
        self.root.after(100, self.process_queue)
        self.root.mainloop()
        
    def poll_loop(self):
        while True:
            notifs = fetch_notifications(USER_ID)
            unread = [n for n in notifs if not n.get('is_read')]
            
            for n in unread:
                if n['id'] not in self.notified_ids:
                    self.notified_ids.add(n['id'])
                    self.q.put(n)
            
            time.sleep(POLL_INTERVAL)
            
    def process_queue(self):
        try:
            while True:
                notif = self.q.get_nowait()
                self.show_popup(notif)
        except queue.Empty:
            pass
        finally:
            self.root.after(100, self.process_queue)
            
    def show_popup(self, notif):
        logging.info(f'Showing popup for notif {notif.get("id")}')
        task_id = notif.get('task_id')
        
        if task_id and task_id in self.open_popups:
            popup = self.open_popups[task_id]
            if popup.top.winfo_exists():
                popup.notif = notif
                popup.load_comments()
                popup.top.lift()
                popup.top.focus_force()
                self.beep()
                return
            else:
                del self.open_popups[task_id]
                
        AlertPopup(self.root, notif, self)
        self.beep()
        
    def open_chat_popup(self, notif):
        task_id = notif.get('task_id')
        popup = ChatPopup(self.root, notif)
        if task_id:
            self.open_popups[task_id] = popup
        
    def beep(self):
        try:
            import winsound
            winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
        except:
            pass

if __name__ == "__main__":
    login_root = tk.Tk()
    app = LoginWindow(login_root)
    login_root.mainloop()
    
    if USER_ID:
        NotifierApp()
