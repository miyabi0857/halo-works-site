import sqlite3
import os
import sys

if 'HAKADORI_APP_DIR' in os.environ:
    app_dir = os.environ['HAKADORI_APP_DIR']
elif getattr(sys, 'frozen', False):
    app_dir = os.path.dirname(sys.executable)
else:
    app_dir = os.path.dirname(os.path.abspath(__file__))

DB_PATH = os.path.join(app_dir, 'task_manager.db')

def get_db_connection():
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Create tables
    cursor.executescript('''
        CREATE TABLE IF NOT EXISTS business_categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            order_index INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS feedbacks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            type TEXT NOT NULL,
            title TEXT NOT NULL,
            content TEXT,
            steps TEXT,
            attachment_path TEXT,
            status TEXT DEFAULT '未対応',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        );

        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            business_category_id INTEGER,
            name TEXT NOT NULL,
            description TEXT,
            start_date TEXT,
            due_date TEXT,
            order_index INTEGER DEFAULT 0,
            status TEXT DEFAULT '進行中',
            owner_id INTEGER,
            FOREIGN KEY (owner_id) REFERENCES users(id),
            FOREIGN KEY (business_category_id) REFERENCES business_categories(id)
        );

        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            avatar_url TEXT
        );

        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            business_category_id INTEGER,
            project_id INTEGER,
            title TEXT NOT NULL,
            description TEXT,
            status TEXT NOT NULL,
            assignee_id INTEGER,
            start_date TEXT,
            due_date TEXT,
            task_type TEXT,
            progress_memo TEXT DEFAULT '',
            order_index INTEGER DEFAULT 0,
            FOREIGN KEY (project_id) REFERENCES projects(id),
            FOREIGN KEY (assignee_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER,
            user_id INTEGER,
            content TEXT NOT NULL,
            chat_type TEXT DEFAULT 'team',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (task_id) REFERENCES tasks(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            message TEXT NOT NULL,
            task_id INTEGER,
            is_read INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS task_statuses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            order_index INTEGER NOT NULL,
            is_completed INTEGER DEFAULT 0
        );
        
        CREATE TABLE IF NOT EXISTS holidays (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            holiday_date TEXT UNIQUE NOT NULL,
            description TEXT
        );
        
        CREATE TABLE IF NOT EXISTS task_assignees (
            task_id INTEGER,
            user_id INTEGER,
            PRIMARY KEY(task_id, user_id),
            FOREIGN KEY (task_id) REFERENCES tasks(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
    ''')
    
    # Schema migrations
    # 初期データの投入はこの後に行う。移行より先に流すと、まだ追加されていない
    # 列（task_assignees.role など）に書き込めず失敗するため。
    try:
        cursor.execute("ALTER TABLE tasks ADD COLUMN order_index INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass # Column might already exist
        
    try:
        cursor.execute("ALTER TABLE tasks ADD COLUMN completed_at DATETIME")
    except sqlite3.OperationalError:
        pass # Column might already exist
        
    try:
        cursor.execute("ALTER TABLE task_assignees ADD COLUMN role TEXT DEFAULT 'sub'")
    except sqlite3.OperationalError:
        pass
        
    try:
        cursor.execute("ALTER TABLE task_assignees ADD COLUMN order_index INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass
        
    try:
        cursor.execute("ALTER TABLE comments ADD COLUMN chat_type TEXT DEFAULT 'team'")
    except sqlite3.OperationalError:
        pass

    # Check if we need to seed data（スキーマ移行がすべて済んでから）
    cursor.execute("SELECT COUNT(*) FROM projects")
    if cursor.fetchone()[0] == 0:
        seed_data(cursor)

    # Ensure at least one user exists
    cursor.execute("SELECT COUNT(*) FROM users")
    if cursor.fetchone()[0] == 0:
        cursor.execute("INSERT INTO users (name) VALUES (?)", ('初期ユーザー',))

    # Check if we need to seed task_statuses
    cursor.execute("SELECT COUNT(*) FROM task_statuses")
    if cursor.fetchone()[0] == 0:
        cursor.execute("INSERT INTO task_statuses (name, order_index, is_completed) VALUES ('未対応', 0, 0)")
        cursor.execute("INSERT INTO task_statuses (name, order_index, is_completed) VALUES ('処理中', 1, 0)")
        cursor.execute("INSERT INTO task_statuses (name, order_index, is_completed) VALUES ('完了', 2, 1)")
        
    conn.commit()
    conn.close()

def seed_data(cursor):
    """Creates a small set of generic sample rows so that a fresh install
    opens with something to look at. Everything here is placeholder text;
    delete these rows once you start entering real work."""

    # Sample users
    users = [('山田 太郎',), ('佐藤 花子',), ('鈴木 一郎',)]
    cursor.executemany("INSERT INTO users (name) VALUES (?)", users)

    # Sample projects
    projects = [
        ('サンプルプロジェクトA',),
        ('サンプルプロジェクトB',),
        ('その他',),
    ]
    cursor.executemany("INSERT INTO projects (name) VALUES (?)", projects)

    sql = ("INSERT INTO tasks (project_id, title, description, status, assignee_id, "
           "start_date, due_date, task_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")

    # 日付は「インストールした日」を基準にした相対日にする。
    # 固定日を埋め込むと、時間が経つほどサンプルが全部期限切れ（赤表示）になり、
    # 初めて起動した人が「壊れている」と感じてしまうため。
    from datetime import date, timedelta

    def d(offset_days):
        return (date.today() + timedelta(days=offset_days)).isoformat()

    # Long-term
    cursor.execute(sql, (1, '長期プロジェクトのサンプル', '数週間〜数ヶ月かけて進める仕事の例です。',
                         '処理中', 1, d(-20), d(+40), '長期プロジェクト'))
    cursor.execute(sql, (2, '資料作成のサンプル', '担当者と期限を決めて進める仕事の例です。',
                         '未対応', 2, d(-3), d(+7), '長期プロジェクト'))

    # Routine
    cursor.execute(sql, (2, '定例業務のサンプル', '毎週・毎月くり返し発生する仕事の例です。',
                         '完了', 3, d(-14), d(-11), '定例'))
    cursor.execute(sql, (1, '月次処理のサンプル', '締め日までに済ませる事務作業の例です。',
                         '未対応', 1, d(0), d(+5), '定例'))

    # Sudden
    cursor.execute(sql, (3, '突発対応のサンプル', '急に飛び込んでくる仕事の例です。至急！',
                         '未対応', 2, d(0), d(+1), '突発'))
    cursor.execute(sql, (3, '問い合わせ対応のサンプル', '電話・メールでの問い合わせ対応の例です。',
                         '処理中', 3, d(0), d(0), '突発'))

    # 担当者は task_assignees 側にも入れる。
    # 一覧・カンバンの担当者フィルタはこちらのテーブルだけを見ており、
    # ログイン直後はフィルタが自分に設定される。ここが空だと
    # 「初めて起動したのにタスクが1件も出ない」状態になってしまう。
    # （担当者欄の「未設定」表示と、メンバー別タスク数グラフが空になるのも同じ原因）
    cursor.executemany(
        "INSERT INTO task_assignees (task_id, user_id, role, order_index) VALUES (?, ?, 'main', 0)",
        [(1, 1), (2, 2), (3, 3), (4, 1), (5, 2), (6, 3)]
    )

if __name__ == '__main__':
    init_db()
    print("Database initialized and seeded.")
