from flask import Flask, jsonify, request, send_from_directory, Response, stream_with_context
import sqlite3
import os
import hashlib
import json
def get_instance_hash():
    cwd = os.getcwd()
    return hashlib.md5(cwd.encode('utf-8')).hexdigest()[:8]
INSTANCE_HASH = get_instance_hash()
CONFIG_FILE = os.path.join(os.getcwd(), 'config.json')
def get_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f: return json.load(f)
        except: pass
    return {'team_name': os.path.basename(os.getcwd()), 'theme': 'light', 'themeHue': '14'}
def save_config(conf):
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f: json.dump(conf, f, ensure_ascii=False)
    except: pass
import uuid
from werkzeug.utils import secure_filename
from database import get_db_connection, init_db

import sys
import os

if getattr(sys, 'frozen', False):
    app_dir = getattr(sys, '_MEIPASS', os.path.dirname(sys.executable))
    exe_dir = os.path.dirname(sys.executable)
else:
    app_dir = os.path.dirname(os.path.abspath(__file__))
    exe_dir = app_dir

UPLOAD_FOLDER = os.path.join(exe_dir, 'uploads')
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)


static_dir = os.path.join(app_dir, 'static')
app = Flask(__name__, static_folder=static_dir, static_url_path='')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
@app.after_request
def add_header(r):
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    return r

@app.route('/')
def serve_index():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


# ---- Settings / Statuses ----
@app.route('/api/statuses', methods=['GET'])
def get_statuses():
    conn = get_db_connection()
    statuses = conn.execute('SELECT * FROM task_statuses ORDER BY order_index ASC').fetchall()
    conn.close()
    return jsonify([dict(s) for s in statuses])

@app.route('/api/statuses', methods=['POST'])
def add_status():
    data = request.json
    conn = get_db_connection()
    try:
        conn.execute('INSERT INTO task_statuses (name, order_index, is_completed) VALUES (?, ?, ?)',
                     (data['name'], data['order_index'], data.get('is_completed', 0)))
        conn.commit()
    except:
        pass
    conn.close()
    return jsonify({"success": True})

@app.route('/api/statuses/<int:status_id>', methods=['PUT', 'DELETE'])
def update_status(status_id):
    conn = get_db_connection()
    if request.method == 'DELETE':
        conn.execute('DELETE FROM task_statuses WHERE id = ? AND is_completed = 0', (status_id,))
    else:
        data = request.json
        conn.execute('UPDATE task_statuses SET name = ?, order_index = ?, is_completed = ? WHERE id = ?',
                     (data['name'], data['order_index'], data.get('is_completed', 0), status_id))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/statuses/reorder', methods=['PUT'])
def reorder_statuses():
    data = request.json
    if not isinstance(data, list):
        return jsonify({"success": False, "error": "Invalid data format"})
    
    conn = get_db_connection()
    for item in data:
        conn.execute('UPDATE task_statuses SET order_index = ? WHERE id = ?',
                     (item.get('order_index'), item.get('id')))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

# ---- Business Categories ----
@app.route('/api/business_categories', methods=['GET'])
def get_business_categories():
    conn = get_db_connection()
    categories = conn.execute('SELECT * FROM business_categories ORDER BY order_index ASC').fetchall()
    conn.close()
    return jsonify([dict(c) for c in categories])

@app.route('/api/business_categories', methods=['POST'])
def create_business_category():
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO business_categories (name, order_index) VALUES (?, ?)',
                   (data['name'], data.get('order_index', 0)))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/business_categories/<int:cat_id>', methods=['PUT', 'DELETE'])
def manage_business_category(cat_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    if request.method == 'PUT':
        data = request.json
        cursor.execute('UPDATE business_categories SET name = ? WHERE id = ?', (data['name'], cat_id))
    elif request.method == 'DELETE':
        # Default to null
        cursor.execute('UPDATE projects SET business_category_id = NULL WHERE business_category_id = ?', (cat_id,))
        cursor.execute('UPDATE tasks SET business_category_id = NULL WHERE business_category_id = ?', (cat_id,))
        cursor.execute('DELETE FROM business_categories WHERE id = ?', (cat_id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/business_categories/reorder', methods=['PUT'])
def reorder_business_categories():
    data = request.json
    conn = get_db_connection()
    for item in data:
        conn.execute('UPDATE business_categories SET order_index = ? WHERE id = ?',
                     (item.get('order_index'), item.get('id')))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

# ---- Avatars ----
import os
from werkzeug.utils import secure_filename

@app.route('/api/users/<int:user_id>/avatar', methods=['POST'])
def upload_avatar(user_id):
    if 'file' not in request.files:
        return jsonify({"error": "No file"}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No file"}), 400
    if file:
        filename = secure_filename(file.filename)
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        path = os.path.join(app.config['UPLOAD_FOLDER'], f"avatar_{user_id}_{filename}")
        file.save(path)
        
        avatar_url = f"/uploads/avatar_{user_id}_{filename}"
        conn = get_db_connection()
        conn.execute('UPDATE users SET avatar_url = ? WHERE id = ?', (avatar_url, user_id))
        conn.commit()
        conn.close()
        
        return jsonify({"success": True, "avatar_url": avatar_url})

@app.route('/api/users/<int:user_id>/avatar', methods=['DELETE'])
def delete_avatar(user_id):
    conn = get_db_connection()
    conn.execute('UPDATE users SET avatar_url = NULL WHERE id = ?', (user_id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/projects', methods=['GET'])
def get_projects():
    status_filter = request.args.get('status', 'active')
    conn = get_db_connection()
    
    where_clause = "WHERE p.status != '完了' OR p.status IS NULL" if status_filter == 'active' else "WHERE p.status = '完了'"
    if status_filter == 'all':
        where_clause = ""
        
    query = f'''
        SELECT p.*, COUNT(t.id) as task_count, u.name as owner_name, bc.name as business_category_name
        FROM projects p 
        LEFT JOIN tasks t ON p.id = t.project_id
        LEFT JOIN users u ON p.owner_id = u.id
        LEFT JOIN business_categories bc ON p.business_category_id = bc.id
        {where_clause}
        GROUP BY p.id
        ORDER BY p.order_index ASC
    '''
    projects = conn.execute(query).fetchall()
    conn.close()
    return jsonify([dict(ix) for ix in projects])

@app.route('/api/projects', methods=['POST'])
def create_project():
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO projects (name, description, start_date, due_date, status, owner_id, business_category_id, weekly_memo, weekly_memo_verbatim) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                   (data['name'], data.get('description'), data.get('start_date'), data.get('due_date'), data.get('status', '進行中'), data.get('owner_id'), data.get('business_category_id'), data.get('weekly_memo', ''), 1 if data.get('weekly_memo_verbatim') else 0))
    conn.commit()
    project_id = cursor.lastrowid
    conn.close()
    return jsonify({"id": project_id}), 201

@app.route('/api/projects/<int:project_id>', methods=['PUT'])
def update_project(project_id):
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    # weekly_memo uses COALESCE so a caller that doesn't send this field
    # (e.g. a future lightweight update) never wipes it out.
    cursor.execute('''UPDATE projects SET name = ?, description = ?, start_date = ?, due_date = ?, status = ?,
                       owner_id = ?, business_category_id = ?, weekly_memo = COALESCE(?, weekly_memo),
                       weekly_memo_verbatim = ? WHERE id = ?''',
                   (data['name'], data.get('description'), data.get('start_date'), data.get('due_date'), data.get('status', '進行中'),
                    data.get('owner_id'), data.get('business_category_id'), data.get('weekly_memo'),
                    1 if data.get('weekly_memo_verbatim') else 0, project_id))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/projects/<int:project_id>', methods=['DELETE'])
def delete_project(project_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # First delete associated comments
    cursor.execute('DELETE FROM comments WHERE task_id IN (SELECT id FROM tasks WHERE project_id = ?)', (project_id,))
    
    # Also delete associated task_assignees
    cursor.execute('DELETE FROM task_assignees WHERE task_id IN (SELECT id FROM tasks WHERE project_id = ?)', (project_id,))
    
    # Then delete associated tasks
    cursor.execute('DELETE FROM tasks WHERE project_id = ?', (project_id,))
    
    # Finally delete the project
    cursor.execute('DELETE FROM projects WHERE id = ?', (project_id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/projects/<int:project_id>/duplicate', methods=['POST'])
def duplicate_project(project_id):
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    orig = cursor.execute('SELECT * FROM projects WHERE id = ?', (project_id,)).fetchone()
    if not orig:
        conn.close()
        return jsonify({"error": "Project not found"}), 404
        
    cursor.execute('''INSERT INTO projects (name, description, start_date, due_date, status, owner_id)
                      VALUES (?, ?, ?, ?, ?, ?)''',
                   (orig['name'], orig['description'], orig['start_date'], orig['due_date'], orig['status'], orig['owner_id']))
    new_project_id = cursor.lastrowid
    
    tasks = cursor.execute('SELECT * FROM tasks WHERE project_id = ?', (project_id,)).fetchall()
    
    for t in tasks:
        cursor.execute('''INSERT INTO tasks (business_category_id, project_id, title, description, status, assignee_id, start_date, due_date, task_type, order_index, progress_memo)
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                       (t.get('business_category_id'), new_project_id, t['title'], t['description'], t['status'], t['assignee_id'], t['start_date'], t['due_date'], t['task_type'], t['order_index'], t['progress_memo']))
        new_task_id = cursor.lastrowid
        
        assignees = cursor.execute('SELECT * FROM task_assignees WHERE task_id = ?', (t['id'],)).fetchall()
        for a in assignees:
            cursor.execute('INSERT INTO task_assignees (task_id, user_id, role, order_index) VALUES (?, ?, ?, ?)',
                           (new_task_id, a['user_id'], a['role'], a['order_index']))
                           
    conn.commit()
    conn.close()
    return jsonify({"id": new_project_id}), 201

notifier_user_id = None

@app.route('/api/notifier/login', methods=['POST'])
def notifier_login():
    global notifier_user_id
    data = request.json
    notifier_user_id = data.get('user_id')
    return jsonify({"success": True})

@app.route('/api/holidays', methods=['GET'])
def get_holidays():
    conn = get_db_connection()
    holidays = conn.execute('SELECT * FROM holidays ORDER BY holiday_date').fetchall()
    conn.close()
    return jsonify([dict(h) for h in holidays])

@app.route('/api/holidays/upload', methods=['POST'])
def upload_holidays():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
        
    try:
        content = file.read().decode('utf-8')
        lines = content.splitlines()
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        count = 0
        for line in lines:
            line = line.strip()
            if not line:
                continue
            parts = line.split(',')
            date_str = parts[0].strip()
            date_str = date_str.replace('/', '-')
            
            description = parts[1].strip() if len(parts) > 1 else '休日'
            
            try:
                cursor.execute('INSERT OR IGNORE INTO holidays (holiday_date, description) VALUES (?, ?)', (date_str, description))
                count += 1
            except Exception as e:
                pass
                
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'count': count})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/users', methods=['GET'])
def get_users():
    conn = get_db_connection()
    users = conn.execute('SELECT * FROM users').fetchall()
    # ユーザーが0人の場合、デフォルトユーザーを自動作成する
    if len(users) == 0:
        default_users = [('山田 太郎',), ('佐藤 花子',), ('鈴木 一郎',)]
        conn.executemany('INSERT INTO users (name) VALUES (?)', default_users)
        conn.commit()
        users = conn.execute('SELECT * FROM users').fetchall()
    conn.close()
    return jsonify([dict(ix) for ix in users])

@app.route('/api/users', methods=['POST'])
def create_user():
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO users (name) VALUES (?)', (data['name'],))
    conn.commit()
    user_id = cursor.lastrowid
    conn.close()
    return jsonify({"id": user_id}), 201

@app.route('/api/users/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET name = ? WHERE id = ?', (data['name'], user_id))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/users/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    # Set tasks' assignee_id to NULL
    cursor.execute('UPDATE tasks SET assignee_id = NULL WHERE assignee_id = ?', (user_id,))
    cursor.execute('DELETE FROM task_assignees WHERE user_id = ?', (user_id,))
    cursor.execute('DELETE FROM users WHERE id = ?', (user_id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/tasks', methods=['GET'])
def get_tasks():
    perform_weekly_rollover_if_needed()
    conn = get_db_connection()
    tasks = conn.execute('''
        SELECT t.*, p.name as project_name, bc.name as business_category_name
        FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        LEFT JOIN business_categories bc ON t.business_category_id = bc.id
        ORDER BY t.order_index ASC
    ''').fetchall()
    
    assignees = conn.execute('''
        SELECT ta.task_id, u.id, u.name, u.avatar_url, ta.role, ta.order_index
        FROM task_assignees ta
        JOIN users u ON ta.user_id = u.id
        ORDER BY ta.order_index ASC
    ''').fetchall()
    conn.close()

    tasks_list = [dict(ix) for ix in tasks]
    assignees_by_task = {}
    for a in assignees:
        if a['task_id'] not in assignees_by_task:
            assignees_by_task[a['task_id']] = []
        assignees_by_task[a['task_id']].append({"id": a['id'], "name": a['name'], "avatar_url": a['avatar_url'], "role": a['role'], "order_index": a['order_index']})
        
    for t in tasks_list:
        t['assignees'] = assignees_by_task.get(t['id'], [])
        
    return jsonify(tasks_list)

@app.route('/api/tasks', methods=['POST'])
def create_task():
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    assignees = data.get('assignees', [])
    if not assignees and 'assignee_ids' in data:
        assignees = [{'user_id': x, 'role': 'sub', 'order_index': i+1} for i, x in enumerate(data['assignee_ids'])]
        
    first_user = assignees[0]['user_id'] if assignees else None

    cursor.execute('''
        INSERT INTO tasks (business_category_id, project_id, title, description, status, assignee_id, start_date, due_date, task_type, progress_memo, importance)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (data.get('business_category_id'), data.get('project_id'), data.get('title'), data.get('description', ''), data.get('status', '未着手'),
          first_user, data.get('start_date'), data.get('due_date'), data.get('task_type', 'タスク'), data.get('progress_memo', ''), data.get('importance', 50)))
    
    task_id = cursor.lastrowid
    
    for a in assignees:
        uid = a.get('user_id')
        cursor.execute('INSERT INTO task_assignees (task_id, user_id, role, order_index) VALUES (?, ?, ?, ?)',
                       (task_id, uid, a.get('role', 'sub'), a.get('order_index', 999)))
        
        if str(uid) != str(data.get('user_id')):
            msg = f"新規タスク「{data['title']}」に追加されました。"
            cursor.execute('INSERT INTO notifications (user_id, message) VALUES (?, ?)', (uid, msg))
            
    conn.commit()
    conn.close()
    return jsonify({"id": task_id}), 201

@app.route('/api/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    conn = get_db_connection()
    assignees = conn.execute('SELECT user_id FROM task_assignees WHERE task_id = ?', (task_id,)).fetchall()
    for row in assignees:
        conn.execute('DELETE FROM notifications WHERE user_id = ? AND message LIKE "%本日のタスク%" AND is_read = 0', (row['user_id'],))
        
    conn.execute('DELETE FROM tasks WHERE id = ?', (task_id,))
    conn.execute('DELETE FROM task_assignees WHERE task_id = ?', (task_id,))
    conn.execute('DELETE FROM comments WHERE task_id = ?', (task_id,))
    conn.execute('DELETE FROM attachments WHERE task_id = ?', (task_id,))
    conn.execute('DELETE FROM subtasks WHERE task_id = ?', (task_id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    
    task_row = conn.execute('SELECT * FROM tasks WHERE id = ?', (task_id,)).fetchone()
    if not task_row:
        conn.close()
        return jsonify({"error": "Task not found"}), 404
        
    # Daily summary notification is no longer cleared here to prevent annoying popups
        
    current_user_id = data.get('user_id')
    changed_fields = []
    field_labels = {
        'project_id': 'プロジェクト', 'business_category_id': '業務分類', 'title': 'タイトル', 'description': '詳細',
        'status': 'ステータス', 'assignee_ids': '担当者', 'start_date': '開始日',
        'due_date': '期日', 'task_type': 'タスク種別', 'progress_memo': '進捗メモ',
        'progress_memo_verbatim': '進捗メモの要約設定', 'importance': '重要度'
    }    # Handle assignees (roles and order)
    assignees_changed = False
    if 'assignees' in data:
        new_assignees = data['assignees']
        assignees_changed = True
        changed_fields.append('担当者設定')
        cursor.execute('DELETE FROM task_assignees WHERE task_id = ?', (task_id,))
        for a in new_assignees:
            cursor.execute('INSERT INTO task_assignees (task_id, user_id, role, order_index) VALUES (?, ?, ?, ?)', 
                           (task_id, a.get('user_id'), a.get('role', 'sub'), a.get('order_index', 999)))
        
        first_user = new_assignees[0]['user_id'] if new_assignees else None
        cursor.execute('UPDATE tasks SET assignee_id = ? WHERE id = ?', (first_user, task_id))

    # Update only provided fields
    fields = []
    values = []
    for key in ['business_category_id', 'project_id', 'title', 'description', 'status', 'start_date', 'due_date', 'task_type', 'progress_memo', 'progress_memo_verbatim', 'importance']:
        if key in data:
            old_val = str(task_row[key]) if task_row[key] is not None else ''
            new_val = str(data[key]) if data[key] is not None else ''
            if old_val != new_val:
                changed_fields.append(field_labels.get(key, key))
                fields.append(f"{key} = ?")
                values.append(data[key])
                
                # Handle completed_at logic
                if key == 'status':
                    if new_val == '完了':
                        fields.append("completed_at = datetime('now', 'localtime')")
                    elif old_val == '完了' and new_val != '完了':
                        fields.append("completed_at = NULL")
            
    if not fields and not assignees_changed:
        conn.close()
        return jsonify({"error": "No data changed"}), 400
        
    if fields:
        values.append(task_id)
        query = f"UPDATE tasks SET {', '.join(fields)} WHERE id = ?"
        cursor.execute(query, values)
    
    # Notify if changes were made and user is known
    if current_user_id and changed_fields:
        user_row = conn.execute('SELECT name FROM users WHERE id = ?', (current_user_id,)).fetchone()
        user_name = user_row['name'] if user_row else '誰か'
        msg = f"タスクの「{'、'.join(changed_fields)}」が変更されました。"
        
        # Insert as a comment (will show up in chat)
        cursor.execute('INSERT INTO comments (task_id, user_id, content) VALUES (?, ?, ?)', (task_id, current_user_id, msg))
        
        # Notify Assignees and all commenters (except sender)
        notify_users = set()
        current_assignees = conn.execute('SELECT user_id FROM task_assignees WHERE task_id = ?', (task_id,)).fetchall()
        for row in current_assignees:
            if str(row['user_id']) != str(current_user_id):
                notify_users.add(int(row['user_id']))
            
        commenters = conn.execute('SELECT DISTINCT user_id FROM comments WHERE task_id = ? AND user_id IS NOT NULL', (task_id,)).fetchall()
        for c in commenters:
            if str(c['user_id']) != str(current_user_id):
                notify_users.add(int(c['user_id']))
                
        notif_msg = f"{user_name}さんが{msg}"
        for uid in notify_users:
            cursor.execute('INSERT INTO notifications (user_id, message, task_id) VALUES (?, ?, ?)', (uid, notif_msg, task_id))
        
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/tasks/<int:task_id>/comments', methods=['GET'])
def get_comments(task_id):
    conn = get_db_connection()
    comments = conn.execute('''
        SELECT c.*, u.name as user_name, u.avatar_url as user_avatar_url 
        FROM comments c
        LEFT JOIN users u ON c.user_id = u.id
        WHERE c.task_id = ?
        ORDER BY c.created_at ASC
    ''', (task_id,)).fetchall()
    
    # fetch reactions for these comments
    reactions = conn.execute('''
        SELECT r.comment_id, r.emoji, r.user_id, u.name as user_name
        FROM comment_reactions r
        LEFT JOIN users u ON r.user_id = u.id
        WHERE r.comment_id IN (SELECT id FROM comments WHERE task_id = ?)
    ''', (task_id,)).fetchall()
    
    # fetch reads
    reads = conn.execute('''
        SELECT r.comment_id, r.user_id, u.name as user_name
        FROM comment_reads r
        LEFT JOIN users u ON r.user_id = u.id
        WHERE r.comment_id IN (SELECT id FROM comments WHERE task_id = ?)
    ''', (task_id,)).fetchall()
    
    conn.close()
    
    res = []
    for c in comments:
        c_dict = dict(c)
        c_dict['reactions'] = [dict(r) for r in reactions if r['comment_id'] == c['id']]
        c_dict['reads'] = [dict(r) for r in reads if r['comment_id'] == c['id']]
        res.append(c_dict)
        
    return jsonify(res)

@app.route('/api/comments/<int:comment_id>/reactions', methods=['POST'])
def toggle_reaction(comment_id):
    data = request.json
    user_id = data['user_id']
    emoji = data['emoji']
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # check if exists
    existing = cursor.execute('SELECT * FROM comment_reactions WHERE comment_id = ? AND user_id = ? AND emoji = ?', (comment_id, user_id, emoji)).fetchone()
    if existing:
        cursor.execute('DELETE FROM comment_reactions WHERE id = ?', (existing['id'],))
        action = 'removed'
    else:
        cursor.execute('INSERT INTO comment_reactions (comment_id, user_id, emoji) VALUES (?, ?, ?)', (comment_id, user_id, emoji))
        action = 'added'
        
    conn.commit()
    conn.close()
    return jsonify({"success": True, "action": action})

@app.route('/api/tasks/<int:task_id>/comments', methods=['POST'])
def add_comment(task_id):
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO comments (task_id, user_id, content, chat_type)
        VALUES (?, ?, ?, ?)
    ''', (task_id, data['user_id'], data['content'], data.get('chat_type', 'team')))
    comment_id = cursor.lastrowid
    
    mentions = data.get('mentions', [])
    
    # Get sender name
    sender = conn.execute('SELECT name FROM users WHERE id = ?', (data['user_id'],)).fetchone()
    sender_name = sender['name'] if sender else '誰か'
    
    # Notify Assignees and all commenters (except sender)
    notify_users = set()
    task = conn.execute('SELECT title FROM tasks WHERE id = ?', (task_id,)).fetchone()
    
    assignees = conn.execute('SELECT user_id FROM task_assignees WHERE task_id = ?', (task_id,)).fetchall()
    for row in assignees:
        notify_users.add(row['user_id'])
        
    commenters = conn.execute('SELECT DISTINCT user_id FROM comments WHERE task_id = ?', (task_id,)).fetchall()
    for row in commenters:
        notify_users.add(row['user_id'])
        
    for uid in mentions:
        notify_users.add(int(uid))
        
    sender_id = int(data['user_id'])
    if sender_id in notify_users:
        notify_users.remove(sender_id)
        
    if notify_users and task:
        commenter = conn.execute('SELECT name FROM users WHERE id = ?', (sender_id,)).fetchone()
        c_name = commenter['name'] if commenter else "誰か"
        
        # Determine plain text snippet for notification
        content_snippet = data['content']
        if len(content_snippet) > 20:
            content_snippet = content_snippet[:20] + "..."
            
        for uid in notify_users:
            if uid in mentions:
                msg = f"{c_name}さんがあなたをメンションしました: {content_snippet}"
            else:
                msg = f"{c_name}さんがコメント: {content_snippet}"
                
            cursor.execute('INSERT INTO notifications (user_id, message, task_id) VALUES (?, ?, ?)', (uid, msg, task_id))
            
    conn.commit()
    
    # fetch the inserted comment
    comment = conn.execute('''
        SELECT c.*, u.name as user_name, u.avatar_url as user_avatar_url 
        FROM comments c
        LEFT JOIN users u ON c.user_id = u.id
        WHERE c.id = ?
    ''', (comment_id,)).fetchone()
    
    conn.close()
    return jsonify(dict(comment)), 201

# ---- Subtasks API ----
@app.route('/api/tasks/<int:task_id>/subtasks', methods=['GET'])
def get_subtasks(task_id):
    conn = get_db_connection()
    subtasks = conn.execute('SELECT * FROM subtasks WHERE task_id = ? ORDER BY order_index ASC, id ASC', (task_id,)).fetchall()
    conn.close()
    return jsonify([dict(ix) for ix in subtasks])

@app.route('/api/tasks/<int:task_id>/subtasks', methods=['POST'])
def add_subtask(task_id):
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO subtasks (task_id, title, order_index) VALUES (?, ?, ?)',
                   (task_id, data.get('title', ''), data.get('order_index', 0)))
    subtask_id = cursor.lastrowid
    conn.commit()
    subtask = conn.execute('SELECT * FROM subtasks WHERE id = ?', (subtask_id,)).fetchone()
    conn.close()
    return jsonify(dict(subtask)), 201

@app.route('/api/tasks/<int:task_id>/subtasks/<int:sub_id>', methods=['PUT'])
def update_subtask(task_id, sub_id):
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    if 'is_completed' in data:
        cursor.execute('UPDATE subtasks SET is_completed = ? WHERE id = ?', (data['is_completed'], sub_id))
    if 'title' in data:
        cursor.execute('UPDATE subtasks SET title = ? WHERE id = ?', (data['title'], sub_id))
    if 'order_index' in data:
        cursor.execute('UPDATE subtasks SET order_index = ? WHERE id = ?', (data['order_index'], sub_id))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

@app.route('/api/tasks/<int:task_id>/subtasks/<int:sub_id>', methods=['DELETE'])
def delete_subtask(task_id, sub_id):
    conn = get_db_connection()
    conn.execute('DELETE FROM subtasks WHERE id = ?', (sub_id,))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

# ---- Attachments API ----
@app.route('/api/tasks/<int:task_id>/attachments', methods=['GET'])
def get_attachments(task_id):
    conn = get_db_connection()
    attachments = conn.execute('''
        SELECT a.*, u.name as uploader_name 
        FROM attachments a
        LEFT JOIN users u ON a.uploaded_by = u.id
        WHERE a.task_id = ?
        ORDER BY a.created_at ASC
    ''', (task_id,)).fetchall()
    conn.close()
    return jsonify([dict(ix) for ix in attachments])

@app.route('/api/tasks/<int:task_id>/attachments', methods=['POST'])
def upload_attachment(task_id):
    user_id = request.form.get('user_id')
    is_link = request.form.get('is_link') == 'true'
    
    if is_link:
        filename = request.form.get('filename') or '無題のリンク'
        filepath = request.form.get('filepath')
        if not filepath:
            return jsonify({"error": "Path is required"}), 400
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO attachments (task_id, filename, filepath, uploaded_by, is_link)
            VALUES (?, ?, ?, ?, ?)
        ''', (task_id, filename, filepath, user_id, 1))
        conn.commit()
        att_id = cursor.lastrowid
    else:
        if 'file' not in request.files:
            return jsonify({"error": "No file part"}), 400
        file = request.files['file']
        if file.filename == '':
            return jsonify({"error": "No selected file"}), 400
            
        if file:
            filename = os.path.basename(file.filename.replace('\\', '/'))
            unique_filename = f"{uuid.uuid4().hex}_{filename}"
            save_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            file.save(save_path)
            
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO attachments (task_id, filename, filepath, uploaded_by, is_link)
                VALUES (?, ?, ?, ?, ?)
            ''', (task_id, filename, unique_filename, user_id, 0))
            conn.commit()
            att_id = cursor.lastrowid

    att = conn.execute('''
        SELECT a.*, u.name as uploader_name 
        FROM attachments a
        LEFT JOIN users u ON a.uploaded_by = u.id
        WHERE a.id = ?
    ''', (att_id,)).fetchone()
    conn.close()
    
    return jsonify(dict(att)), 201

@app.route('/api/tasks/<int:task_id>/attachments/<int:att_id>', methods=['DELETE'])
def delete_attachment(task_id, att_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    att = cursor.execute('SELECT * FROM attachments WHERE id = ? AND task_id = ?', (att_id, task_id)).fetchone()
    if not att:
        conn.close()
        return jsonify({"error": "Not found"}), 404
        
    if not att['is_link']:
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], att['filepath'])
        if os.path.exists(filepath):
            try:
                os.remove(filepath)
            except:
                pass
                
    cursor.execute('DELETE FROM attachments WHERE id = ?', (att_id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True}), 200

@app.route('/api/attachments/<int:att_id>/download', methods=['GET'])
def download_attachment(att_id):
    conn = get_db_connection()
    att = conn.execute('SELECT * FROM attachments WHERE id = ?', (att_id,)).fetchone()
    conn.close()
    if not att or att['is_link']:
        return jsonify({"error": "Not found"}), 404
        
    return send_from_directory(
        app.config['UPLOAD_FOLDER'], 
        att['filepath'],
        as_attachment=True,
        download_name=att['filename']
    )

# ---- Notifications API ----
@app.route('/api/notifications/<int:user_id>', methods=['GET'])
def get_notifications(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    from datetime import datetime
    today_str = datetime.now().strftime('%Y-%m-%d')
    has_summary = cursor.execute('''
        SELECT id FROM notifications 
        WHERE user_id = ? AND message LIKE '%本日のタスク%' 
        AND date(created_at, 'localtime') = ?
    ''', (user_id, today_str)).fetchone()
    
    if not has_summary:
        tasks = cursor.execute('''
            SELECT t.*, p.name as project_name FROM tasks t
            JOIN task_assignees ta ON t.id = ta.task_id
            LEFT JOIN projects p ON t.project_id = p.id
            WHERE ta.user_id = ? AND t.status != '完了'
        ''', (user_id,)).fetchall()
        
        from datetime import datetime, timedelta
        today_date = datetime.now().date()
        today_str = today_date.strftime('%Y-%m-%d')
        next_week_date = today_date + timedelta(days=7)
        next_week_str = next_week_date.strftime('%Y-%m-%d')
        
        project_groups = {}
        for t in tasks:
            if t['due_date']:
                p_name = t['project_name'] or '未分類'
                category = None
                if t['due_date'] == today_str:
                    category = '本日'
                elif t['due_date'] < today_str:
                    category = '期限切れ'
                elif today_str < t['due_date'] <= next_week_str:
                    category = '今週 (7日以内)'
                
                if category:
                    if p_name not in project_groups:
                        project_groups[p_name] = []
                    project_groups[p_name].append(f"  - {t['title']} ({category})")
                    
        if project_groups:
            msg = "【本日のタスク】\n\n"
            for p_name, t_list in project_groups.items():
                msg += f"**{p_name}**\n" + "\n".join(t_list) + "\n\n"
            
            existing = cursor.execute('SELECT id FROM notifications WHERE user_id = ? AND message LIKE "%%本日のタスク%%" AND date(created_at) = date("now", "localtime")', (user_id,)).fetchone()
            if not existing:
                cursor.execute('INSERT INTO notifications (user_id, message) VALUES (?, ?)', (user_id, msg.strip()))
                conn.commit()

    notifs = cursor.execute('''
        SELECT n.*, t.title as task_title, p.name as project_name
        FROM notifications n
        LEFT JOIN tasks t ON n.task_id = t.id
        LEFT JOIN projects p ON t.project_id = p.id
        WHERE n.user_id = ? 
        ORDER BY n.created_at DESC LIMIT 50
    ''', (user_id,)).fetchall()
    conn.close()
    return jsonify([dict(ix) for ix in notifs])

@app.route('/api/notifications/<int:notif_id>/read', methods=['PUT'])
def mark_notification_read(notif_id):
    conn = get_db_connection()
    conn.execute('UPDATE notifications SET is_read = 1 WHERE id = ?', (notif_id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/notifications/read_by_task/<int:task_id>/<int:user_id>', methods=['PUT'])
def mark_task_notifications_read(task_id, user_id):
    conn = get_db_connection()
    conn.execute('UPDATE notifications SET is_read = 1 WHERE task_id = ? AND user_id = ?', (task_id, user_id))
    
    # Mark all existing comments in this task as read by this user
    # ONLY insert if not exists (using INSERT OR IGNORE since we have UNIQUE constraint)
    conn.execute('''
        INSERT OR IGNORE INTO comment_reads (comment_id, user_id)
        SELECT id, ? FROM comments WHERE task_id = ? AND user_id != ?
    ''', (user_id, task_id, user_id))
    
    conn.commit()
    conn.close()
    return jsonify({"success": True})

def migrate_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # 0-100, how bad it is to leave this task undone. Defaults to 50
        # (neutral/middle) rather than 0 so existing tasks don't all pile
        # up at the "doesn't matter" end of the priority map.
        cursor.execute("ALTER TABLE tasks ADD COLUMN importance INTEGER DEFAULT 50")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE tasks ADD COLUMN progress_memo TEXT DEFAULT ''")
    except sqlite3.OperationalError:
        pass # column already exists

    try:
        cursor.execute("ALTER TABLE projects ADD COLUMN description TEXT")
        cursor.execute("ALTER TABLE projects ADD COLUMN start_date TEXT")
        cursor.execute("ALTER TABLE projects ADD COLUMN due_date TEXT")
    except sqlite3.OperationalError:
        pass # columns already exist

    try:
        cursor.execute("ALTER TABLE projects ADD COLUMN business_category_id INTEGER")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE tasks ADD COLUMN business_category_id INTEGER")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE projects ADD COLUMN order_index INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE projects ADD COLUMN status TEXT DEFAULT '進行中'")
    except sqlite3.OperationalError:
        pass
        
    try:
        cursor.execute("ALTER TABLE projects ADD COLUMN owner_id INTEGER")
    except sqlite3.OperationalError:
        pass
    try:
        cursor.execute("ALTER TABLE users ADD COLUMN avatar_url TEXT")
    except sqlite3.OperationalError:
        pass # column already exists
        
    try:
        cursor.execute("ALTER TABLE notifications ADD COLUMN task_id INTEGER")
    except sqlite3.OperationalError:
        pass # column already exists
        
    try:
        cursor.execute("ALTER TABLE attachments ADD COLUMN is_link INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass # column already exists
        
    cursor.executescript('''
        CREATE TABLE IF NOT EXISTS subtasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER,
    title TEXT NOT NULL,
    is_completed INTEGER DEFAULT 0,
    order_index INTEGER DEFAULT 0,
    FOREIGN KEY(task_id) REFERENCES tasks(id)
);
CREATE TABLE IF NOT EXISTS task_assignees (
            task_id INTEGER,
            user_id INTEGER,
            PRIMARY KEY(task_id, user_id),
            FOREIGN KEY (task_id) REFERENCES tasks(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
    ''')
    try:
        cursor.execute("ALTER TABLE task_assignees ADD COLUMN role TEXT DEFAULT 'sub'")
    except sqlite3.OperationalError:
        pass
    try:
        cursor.execute("ALTER TABLE task_assignees ADD COLUMN order_index INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass

    # Migrate existing assignees
    cursor.execute('''
        INSERT OR IGNORE INTO task_assignees (task_id, user_id)
        SELECT id, assignee_id FROM tasks WHERE assignee_id IS NOT NULL
    ''')
    
    cursor.executescript('''
        CREATE TABLE IF NOT EXISTS task_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER,
            snapshot_date TEXT,
            status TEXT,
            progress_memo TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (task_id) REFERENCES tasks(id)
        );

        CREATE TABLE IF NOT EXISTS project_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER,
            snapshot_date TEXT,
            weekly_memo TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id)
        );
    ''')

    try:
        cursor.execute("ALTER TABLE projects ADD COLUMN weekly_memo TEXT DEFAULT ''")
    except sqlite3.OperationalError:
        pass  # column already exists

    try:
        # When set, the AI report generator inserts this memo's text
        # exactly as written instead of rewriting/summarizing it.
        cursor.execute("ALTER TABLE projects ADD COLUMN weekly_memo_verbatim INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE tasks ADD COLUMN progress_memo_verbatim INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass

    cursor.executescript('''
        CREATE TABLE IF NOT EXISTS attachments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL,
            uploaded_by INTEGER,
            is_link INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            message TEXT NOT NULL,
            is_read INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS comment_reactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            comment_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            emoji TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(comment_id, user_id, emoji)
        );
        CREATE TABLE IF NOT EXISTS comment_reads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            comment_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            read_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(comment_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS task_statuses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            order_index INTEGER NOT NULL,
            is_completed INTEGER DEFAULT 0
        );
    ''')
    
    # Check if we need to seed task_statuses
    cursor.execute("SELECT COUNT(*) FROM task_statuses")
    if cursor.fetchone()[0] == 0:
        cursor.execute("INSERT INTO task_statuses (name, order_index, is_completed) VALUES ('未対応', 0, 0)")
        cursor.execute("INSERT INTO task_statuses (name, order_index, is_completed) VALUES ('処理中', 1, 0)")
        cursor.execute("INSERT INTO task_statuses (name, order_index, is_completed) VALUES ('完了', 2, 1)")
        
    conn.commit()
    conn.close()

import sys
import os
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w")

import socket
import threading
import webbrowser
import time

def get_free_port():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("",0))
    s.listen(1)
    port = s.getsockname()[1]
    s.close()
    return port


def save_port(port):
    try:
        import os
        appdata = os.environ.get('APPDATA', '')
        if appdata:
            port_file = os.path.join(appdata, f'Hakadori_port_{INSTANCE_HASH}.txt')
            with open(port_file, 'w', encoding='utf-8') as f:
                f.write(str(port))
    except Exception as e:
        print("Could not save port file:", e)

def open_browser(port):
    time.sleep(1.5)
    webbrowser.open(f'http://127.0.0.1:{port}')


@app.route('/api/projects/reorder', methods=['POST'])
def reorder_projects():
    data = request.json
    project_ids = data.get('project_ids', [])
    if not project_ids:
        return jsonify({'success': False, 'error': 'No project IDs provided'}), 400
        
    conn = get_db_connection()
    try:
        for idx, p_id in enumerate(project_ids):
            conn.execute('UPDATE projects SET order_index = ? WHERE id = ?', (idx, p_id))
        conn.commit()
    except Exception as e:
        conn.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()
        
    return jsonify({'success': True})

@app.route('/api/tasks/reorder', methods=['POST'])
def reorder_tasks():
    data = request.json
    task_ids = data.get('task_ids', [])
    if not task_ids:
        return jsonify({'success': False, 'error': 'No task IDs provided'}), 400
        
    conn = get_db_connection()
    try:
        for idx, task_id in enumerate(task_ids):
            conn.execute('UPDATE tasks SET order_index = ? WHERE id = ?', (idx, task_id))
        conn.commit()
    except Exception as e:
        conn.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()
        
    return jsonify({'success': True})


@app.route('/api/tasks/snapshot', methods=['POST'])
def create_snapshot():
    try:
        from datetime import datetime
        conn = get_db_connection()
        today = datetime.now().strftime('%Y-%m-%d')
        tasks = conn.execute('SELECT id, status, progress_memo FROM tasks').fetchall()
        for t in tasks:
            conn.execute("""
                INSERT INTO task_snapshots (task_id, snapshot_date, status, progress_memo)
                VALUES (?, ?, ?, ?)
            """, (t['id'], today, t['status'], t['progress_memo']))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/quit', methods=['POST'])
def quit_app():
    # Attempt to cleanly shut down
    import os
    import signal
    import threading
    
    def shutdown():
        time.sleep(0.5)
        os._exit(0)
        
    threading.Thread(target=shutdown).start()
    return jsonify({'status': 'success'})

@app.route('/api/config', methods=['GET', 'POST'])
def api_config():
    if request.method == 'POST':
        conf = request.json
        save_config(conf)
        return jsonify({'status': 'ok'})
    return jsonify(get_config())


def _get_week_monday(d):
    from datetime import timedelta
    return d - timedelta(days=d.weekday())


def perform_weekly_rollover_if_needed():
    """Once per week, freeze each task's current status/progress_memo as
    "last week's final state" (into task_snapshots) and clear progress_memo
    so members start the new week with a blank weekly-report memo.

    On the very first run (no history yet) we only start tracking the
    current week - we never touch existing data on first launch.
    """
    from datetime import datetime

    today = datetime.now().date()
    this_monday = _get_week_monday(today).strftime('%Y-%m-%d')

    config = get_config()
    last_rollover = config.get('last_weekly_rollover')

    if last_rollover == this_monday:
        return  # already rolled over for the current week

    conn = get_db_connection()
    cursor = conn.cursor()

    if last_rollover:
        # A new week has started since the last check: archive the state
        # tasks were left in at the end of last_rollover's week, then reset.
        tasks = cursor.execute('SELECT id, status, progress_memo FROM tasks').fetchall()
        for t in tasks:
            cursor.execute('''
                INSERT INTO task_snapshots (task_id, snapshot_date, status, progress_memo)
                VALUES (?, ?, ?, ?)
            ''', (t['id'], last_rollover, t['status'], t['progress_memo']))
            cursor.execute('UPDATE tasks SET progress_memo = ? WHERE id = ?', ('', t['id']))

        # Same treatment for each project's own weekly-report memo.
        projects = cursor.execute('SELECT id, weekly_memo FROM projects').fetchall()
        for p in projects:
            cursor.execute('''
                INSERT INTO project_snapshots (project_id, snapshot_date, weekly_memo)
                VALUES (?, ?, ?)
            ''', (p['id'], last_rollover, p['weekly_memo']))
            cursor.execute('UPDATE projects SET weekly_memo = ? WHERE id = ?', ('', p['id']))
        conn.commit()

    conn.close()

    config['last_weekly_rollover'] = this_monday
    save_config(config)


def _collect_last_week_report_data_for_projects(project_ids):
    """Returns (project_data, has_snapshot_data), or (None, error_message)
    if the projects can't be found. project_data is a list of dicts:
        {category_name, name, memo, tasks: [{title, status, memo, diff_text}]}
    where memo/status are each project's/task's frozen "last week" values
    (falling back to the current live value on the very first week this
    feature has data for), and diff_text - only present when there are at
    least two archived weeks for that task - describes what changed versus
    the week before last."""
    perform_weekly_rollover_if_needed()

    conn = get_db_connection()
    cursor = conn.cursor()

    placeholders = ','.join('?' for _ in project_ids)
    project_rows = cursor.execute(f'''
        SELECT p.id, p.name, p.weekly_memo, p.weekly_memo_verbatim, bc.name as category_name
        FROM projects p
        LEFT JOIN business_categories bc ON p.business_category_id = bc.id
        WHERE p.id IN ({placeholders})
        ORDER BY bc.id, p.id
    ''', project_ids).fetchall()
    if not project_rows:
        conn.close()
        return None, '選択されたプロジェクトが見つかりませんでした。'

    proj_snap_rows = cursor.execute(f'''
        SELECT project_id, weekly_memo
        FROM project_snapshots ps
        WHERE project_id IN ({placeholders})
          AND snapshot_date = (SELECT MAX(snapshot_date) FROM project_snapshots WHERE project_id = ps.project_id)
    ''', project_ids).fetchall()
    proj_last_memo = {r['project_id']: r['weekly_memo'] for r in proj_snap_rows}

    task_rows = cursor.execute(f'''
        SELECT id, title, status as current_status, progress_memo as current_memo, project_id, progress_memo_verbatim
        FROM tasks
        WHERE project_id IN ({placeholders})
        ORDER BY id
    ''', project_ids).fetchall()

    task_ids = [t['id'] for t in task_rows]
    snaps_by_task = {}
    if task_ids:
        tph = ','.join('?' for _ in task_ids)
        snap_rows = cursor.execute(f'''
            SELECT task_id, snapshot_date, status, progress_memo
            FROM task_snapshots
            WHERE task_id IN ({tph})
            ORDER BY task_id, snapshot_date DESC
        ''', task_ids).fetchall()
        for r in snap_rows:
            snaps_by_task.setdefault(r['task_id'], []).append(r)

    conn.close()

    has_snapshot_data = False
    project_data = []
    for p in project_rows:
        category_name = p['category_name'] or '分類なし'

        if p['id'] in proj_last_memo:
            p_memo = proj_last_memo[p['id']] or ''
            has_snapshot_data = True
        else:
            # No archived "last week" memo yet (first week using this
            # feature) - fall back to whatever is currently in progress.
            p_memo = p['weekly_memo'] or ''

        task_list = []
        for t in task_rows:
            if t['project_id'] != p['id']:
                continue
            snaps = snaps_by_task.get(t['id'], [])
            if snaps:
                status = snaps[0]['status']
                memo = snaps[0]['progress_memo'] or ''
                has_snapshot_data = True
            else:
                # No archived "last week" data yet (first week using this
                # feature) - fall back to the task's current live state,
                # same as the project-level memo fallback above.
                status = t['current_status']
                memo = t['current_memo'] or ''

            diff_text = ''
            if len(snaps) >= 2:
                prev_status = snaps[1]['status']
                prev_memo = snaps[1]['progress_memo'] or ''
                if status != prev_status or memo != prev_memo:
                    diff_text = (f"先週との比較: ステータス「{prev_status}」→「{status}」、"
                                 f"メモ「{prev_memo or '(空欄)'}」→「{memo or '(空欄)'}」")
                else:
                    diff_text = "先週から変化なし"

            task_list.append({
                'title': t['title'], 'status': status, 'memo': memo, 'diff_text': diff_text,
                'verbatim': bool(t['progress_memo_verbatim'])
            })

        project_data.append({
            'category_name': category_name, 'name': p['name'], 'memo': p_memo, 'tasks': task_list,
            'verbatim': bool(p['weekly_memo_verbatim'])
        })

    return project_data, has_snapshot_data


def _format_simple_weekly_report(project_data):
    """Deterministic (non-AI) rendering of project_data into the same
    ［業務分類］プロジェクト名／・タスクの進捗 layout the AI mode targets."""
    eq_sep = '＝' * 20
    dash_sep = '　' + 'ー' * 20
    blocks = []
    for p in project_data:
        has_progress = any(t['diff_text'] and t['diff_text'] != '先週から変化なし' for t in p['tasks'])
        if has_progress:
            status_word = '進捗あり'
        elif p['tasks']:
            status_word = '進捗中'
        else:
            status_word = '進捗なし'

        lines = [f"［{p['category_name']}］{p['name']}　{status_word}", eq_sep]
        lines.append(p['memo'] if p['memo'] else '(プロジェクトメモの記載なし)')

        if p['tasks']:
            lines.append('')
            lines.append('・タスクの進捗')
            for t in p['tasks']:
                lines.append(f"　{t['title']}　{t['status']}")
                lines.append(dash_sep)
                lines.append(f"　{t['memo'] if t['memo'] else '(進捗メモの記載なし)'}")
                if t['diff_text'] and t['diff_text'] != '先週から変化なし':
                    lines.append(f"　{t['diff_text']}")
        else:
            lines.append('')
            lines.append('（タスクなし）')
        blocks.append('\n'.join(lines))
    return '\n\n'.join(blocks)


def _ollama_rewrite_memo(model_name, text):
    """Sends one short memo to Ollama to be turned into natural report
    prose. Raises on failure; returns the raw text unchanged if the AI
    responds with nothing usable."""
    import urllib.request
    prompt = f"""以下の文章を、社内週報用に自然な文章に整えてください。
事実を追加せず、書かれている内容のみを使ってください。
文体は敬体（です・ます調）ではなく、常体（だ・である調）で統一してください。
挨拶や前置き、まとめの言葉は不要です。整えた本文のみを出力してください。

【元の文章】
{text}
"""
    req = urllib.request.Request(
        'http://localhost:11434/api/generate',
        data=json.dumps({"model": model_name, "prompt": prompt, "stream": False, "think": False}).encode('utf-8'),
        headers={'Content-Type': 'application/json'}
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        result = json.loads(resp.read().decode('utf-8'))
        out = (result.get('response') or '').strip()
    if 'channel|>' in out:
        out = out.split('channel|>')[-1].strip()
    return out or text


@app.route('/api/weekly_report', methods=['POST'])
def generate_weekly_report():
    data = request.json or {}
    project_ids = data.get('project_ids') or []
    mode = data.get('mode', 'ai')  # 'ai' (Gemma経由) or 'simple' (AIなし)
    user_id = data.get('user_id')  # optional: who to notify (via notifier.py) when AI generation finishes

    if not project_ids:
        return jsonify({'error': 'プロジェクトが選択されていません。'}), 400

    project_data, has_snapshot_data = _collect_last_week_report_data_for_projects(project_ids)
    if project_data is None:
        return jsonify({'error': has_snapshot_data}), 404  # 2nd value is the error message here

    preamble = ''
    if not has_snapshot_data:
        preamble = ('※まだ「先週分」の記録がないため、現在のタスク状況をもとに参考として生成しています。\n'
                    '来週以降は毎週分の進捗・変化点が自動集計されます。\n\n')

    if mode == 'simple':
        # No AI required: build the same layout deterministically.
        report_text = preamble + _format_simple_weekly_report(project_data)
        return jsonify({'report': report_text, 'has_last_week_data': has_snapshot_data, 'ai_used': False})

    config = get_config()
    model_name = config.get('ollama_model', 'gemma4:e4b')

    def stream_ai_report():
        # The overall layout (headers, separators, which project/task comes
        # where) is always built deterministically here - only individual
        # memo fields get sent to the AI, and only when their "verbatim"
        # checkbox is off. This guarantees a memo marked "そのまま使用する"
        # reaches the report completely unmodified, since it's never handed
        # to the model at all. Non-verbatim fields are rewritten one at a
        # time and streamed out as soon as each finishes, alongside the
        # deterministic parts, so the report builds up progressively.
        if preamble:
            yield preamble
        eq_sep = '＝' * 20
        dash_sep = '　' + 'ー' * 20
        try:
            for p in project_data:
                has_progress = any(t['diff_text'] and t['diff_text'] != '先週から変化なし' for t in p['tasks'])
                status_word = '進捗あり' if has_progress else ('進捗中' if p['tasks'] else '進捗なし')
                yield f"［{p['category_name']}］{p['name']}　{status_word}\n{eq_sep}\n"

                if not p['memo']:
                    yield '(プロジェクトメモの記載なし)'
                elif p['verbatim']:
                    yield p['memo']
                else:
                    yield _ollama_rewrite_memo(model_name, p['memo'])
                yield '\n'

                if p['tasks']:
                    yield '\n・タスクの進捗\n'
                    for t in p['tasks']:
                        yield f"　{t['title']}　{t['status']}\n{dash_sep}\n"
                        if not t['memo']:
                            yield '　(進捗メモの記載なし)'
                        elif t['verbatim']:
                            yield f"　{t['memo']}"
                        else:
                            yield f"　{_ollama_rewrite_memo(model_name, t['memo'])}"
                        if t['diff_text'] and t['diff_text'] != '先週から変化なし':
                            yield f"\n　{t['diff_text']}"
                        yield '\n\n'
                else:
                    yield '\n（タスクなし）\n'
                yield '\n'

            # Generation finished without error: let the app's own notifier
            # popup (notifier.py, polling /api/notifications) tell the user
            # it's done - useful since this can take a while and the window
            # is often minimized. Unlike a browser Notification, this doesn't
            # need permission that resets every time the app picks a new port.
            if user_id:
                try:
                    names = '、'.join(p['name'] for p in project_data)
                    nconn = get_db_connection()
                    nconn.execute(
                        'INSERT INTO notifications (user_id, message) VALUES (?, ?)',
                        (user_id, f'週報の作成が完了しました。\n対象: {names}')
                    )
                    nconn.commit()
                    nconn.close()
                except Exception:
                    pass  # notification is best-effort; never fail the report over it
        except Exception as e:
            yield (f'\n\n[エラー] ローカルAI(Ollama)との通信に失敗しました。\n'
                   f'・Ollamaが起動しているか\n'
                   f'・モデル「{model_name}」がインストール済みか（未installの場合は "ollama pull {model_name}"）\n'
                   f'をご確認ください。\n\n'
                   f'※Gemma4が未導入の場合は「簡易週報(AIなし)」ボタンをご利用ください。\n\n詳細: {e}')

    return Response(stream_with_context(stream_ai_report()), mimetype='text/plain; charset=utf-8')
@app.route('/api/tasks/<int:task_id>/dates', methods=['PUT'])
def update_task_dates(task_id):
    data = request.json
    start_date = data.get('start_date')
    due_date = data.get('due_date')
    if not start_date or not due_date:
        return jsonify({"error": "Missing dates"}), 400
    
    conn = get_db_connection()
    conn.execute('''
        UPDATE tasks SET start_date = ?, due_date = ? WHERE id = ?
    ''', (start_date, due_date, task_id))
    conn.commit()
    conn.close()
    return jsonify({"status": "ok"})




if __name__ == '__main__':
    # Ensure current working directory is the exe's folder
    if getattr(sys, 'frozen', False):
        os.chdir(os.path.dirname(sys.executable))
    else:
        os.chdir(os.path.dirname(os.path.abspath(__file__)))

    import urllib.request
    port_file = os.path.join(os.environ.get('APPDATA', ''), f'Hakadori_port_{INSTANCE_HASH}.txt')
    if os.path.exists(port_file):
        try:
            with open(port_file, 'r') as f:
                saved_port = f.read().strip()
            resp = urllib.request.urlopen(f"http://127.0.0.1:{saved_port}/", timeout=1.0)
            if resp.status == 200:
                print("App is already running. Opening browser and exiting.")
                import webbrowser
                webbrowser.open(f"http://127.0.0.1:{saved_port}/")
                sys.exit(0)
        except Exception:
            pass

    from database import get_db_connection, init_db
    init_db()
    migrate_db()
    perform_weekly_rollover_if_needed()

    config = get_config()
    if 'api_port' in config and isinstance(config['api_port'], int):
        port = config['api_port']
    else:
        port = get_free_port()
    
    # Start Flask in a daemon thread
    # threaded=True is important: without it the server can only handle one
    # request at a time, so a long-running call (e.g. the AI weekly report,
    # which can take a minute or more) blocks every other request - including
    # the UI's own 30-second auto-refresh polling - until it finishes.
    from werkzeug.serving import make_server
    server = make_server('127.0.0.1', port, app, threaded=True)
    threading.Thread(target=server.serve_forever, daemon=True).start()

    # Save port and open browser
    save_port(port)
    threading.Thread(target=open_browser, args=(port,), daemon=True).start()

    # Run Notifier in the main thread
    try:
        import notifier
        notifier.API_BASE = f"http://127.0.0.1:{port}/api"
        
        # Wait for the user to login via the Web UI
        while notifier_user_id is None:
            time.sleep(1)
            
        notifier.USER_ID = notifier_user_id
        notifier.NotifierApp()
    except Exception as e:
        import traceback
        try:
            with open('notifier_crash.log', 'w') as f:
                f.write(traceback.format_exc())
        except:
            pass
        # Keep server alive if notifier fails
        while True:
            time.sleep(1)

